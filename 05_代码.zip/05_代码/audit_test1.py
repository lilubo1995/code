# -*- coding: utf-8 -*-
"""
audit_test1.py —— 核查原始 test1.py 在 j30 上输出的调度是否真正可行

做法：不改动 test1.py。把它的函数定义加载进来（去掉末尾 input() 驱动部分，绘图库用空壳代替），
逐个算例单独开子进程运行（超时 20 秒视为卡死），解析它打印的
“活动ID / 开始 / 结束 / 工期 / 起点坐标 / 占用尺寸”表格，再用 sched3d.check() 独立检查：
工期是否被改动、紧前关系、常规资源、场地边界、同一时间三维重叠。
同时给出同一算例上 MAI 规则 + 本项目调度器（S3 论文算法 c / S4 完整候选坐标）的工期作对照。
"""
import os
import re
import sys
import csv
import time
import types
import io
import contextlib
import traceback
import multiprocessing as mp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d  # noqa: E402

TEST1 = os.path.join(HERE, '原始代码', 'test1.py')
DATA = os.path.join(sched3d.DATA_DIR, 'j30_integer')
OUT = os.path.join(sched3d.OUT_ROOT, 'test1核查')
RAW = os.path.join(OUT, '原始输出')
TIMEOUT = 20.0

ROW = re.compile(r'^\s*(\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+\(([^)]*)\)\s+\(([^)]*)\)')


def _stub_modules():
    class _Any(object):
        def __getattr__(self, k):
            return _Any()

        def __call__(self, *a, **k):
            return _Any()

    for name in ['matplotlib', 'matplotlib.pyplot', 'matplotlib.ticker', 'mpl_toolkits',
                 'mpl_toolkits.mplot3d', 'xlsxwriter']:
        m = types.ModuleType(name)
        m.__getattr__ = lambda k: _Any()
        sys.modules[name] = m
    sys.modules['matplotlib'].pyplot = sys.modules['matplotlib.pyplot']
    sys.modules['matplotlib.pyplot'].figure = _Any()
    sys.modules['matplotlib.ticker'].MultipleLocator = _Any()
    sys.modules['matplotlib.ticker'].FormatStrFormatter = _Any()
    sys.modules['mpl_toolkits.mplot3d'].Axes3D = _Any()


def child(path, out_file):
    buf = io.StringIO()
    try:
        _stub_modules()
        with open(TEST1, 'r', encoding='utf-8', errors='replace') as f:
            src = f.read()
        cut = src.find('\nlist_xlsx=[]')
        if cut < 0:
            raise RuntimeError('test1.py 结构与预期不同，找不到 list_xlsx=[]')
        ns = {'__name__': 'test1_audit'}
        exec(compile(src[:cut], TEST1, 'exec'), ns)
        ns['list_xlsx'] = [[os.path.basename(path)]]
        t0 = time.perf_counter()
        with contextlib.redirect_stdout(buf):
            ns['zz'](path)
        buf.write('\n#CPU_SECONDS %.4f\n' % (time.perf_counter() - t0))
    except Exception:
        buf.write('\n#ERROR\n' + traceback.format_exc())
    with open(out_file, 'w', encoding='utf-8') as f:
        f.write(buf.getvalue())


def parse(text):
    acts = {}
    total = None
    for ln in text.splitlines():
        m = ROW.match(ln)
        if m:
            aid = int(m.group(1))
            pos = [p.strip() for p in m.group(5).split(',')]
            pos = None if 'None' in pos else tuple(int(p) for p in pos)
            acts[aid] = (int(m.group(2)), int(m.group(3)), pos)
        elif ln.startswith('Total time:'):
            total = int(float(ln.split(':', 1)[1]))
    return acts, total


def main():
    os.makedirs(RAW, exist_ok=True)
    files = sorted([f for f in os.listdir(DATA) if f.lower().endswith('.sm')],
                   key=lambda f: tuple(int(x) for x in os.path.splitext(f)[0][3:].split('_')))
    refs = sched3d.load_refs()
    procs = max(1, mp.cpu_count() - 1)
    print('test1 audit: %d instances, %d procs' % (len(files), procs), flush=True)
    status = {}
    pending = list(files)
    running = {}
    t_start = time.time()
    while pending or running:
        while pending and len(running) < procs:
            fn = pending.pop(0)
            raw = os.path.join(RAW, os.path.splitext(fn)[0] + '.txt')
            if os.path.exists(raw):
                os.remove(raw)
            p = mp.Process(target=child, args=(os.path.join(DATA, fn), raw))
            p.start()
            running[fn] = (p, time.time(), raw)
        time.sleep(0.05)
        for fn in list(running):
            p, t0, raw = running[fn]
            if not p.is_alive():
                p.join()
                status[fn] = 'ok'
                del running[fn]
            elif time.time() - t0 > TIMEOUT:
                p.terminate()
                p.join()
                status[fn] = 'timeout'
                del running[fn]
    print('test1 runs finished in %.0fs' % (time.time() - t_start), flush=True)

    rows = []
    for fn in files:
        name = os.path.splitext(fn)[0]
        I = sched3d.load_instance(os.path.join(DATA, fn))
        rf = refs.get(name, {})
        opt = rf.get('opt')
        mine = {}
        for m in ('S3', 'S4'):
            S, F, P, _, _ = sched3d.Scheduler(I, 'MAI', m).run()
            mine[m] = max(F)
        rec = {'instance': name, 'opt': opt, 'status': status.get(fn, 'missing'),
               'mai_S3': mine['S3'], 'mai_S4': mine['S4']}
        raw = os.path.join(RAW, name + '.txt')
        text = ''
        if os.path.exists(raw):
            with open(raw, 'r', encoding='utf-8', errors='replace') as f:
                text = f.read()
        if '#ERROR' in text:
            rec['status'] = 'error'
        acts, total = parse(text)
        rec['test1_makespan'] = total
        if acts and rec['status'] == 'ok':
            S = [None] * I.n
            F = [None] * I.n
            P = [None] * I.n
            for aid, (s, f_, pos) in acts.items():
                if 0 <= aid < I.n:
                    S[aid], F[aid], P[aid] = s, f_, pos
            v = sched3d.check(I, S, F, P, space=True)
            rec.update(v)
            rec['violations'] = sum(v.values())
        rows.append(rec)

    keys = ['instance', 'status', 'opt', 'test1_makespan', 'mai_S3', 'mai_S4', 'violations',
            'missing', 'dur', 'prec', 'res', 'nopos', 'bound', 'overlap']
    with open(os.path.join(OUT, 'test1核查.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(keys)
        for r in rows:
            wr.writerow([r.get(k, '') for k in keys])

    ok = [r for r in rows if r['status'] == 'ok' and 'violations' in r]
    lines = []
    A = lines.append
    A('原始 test1.py（MAI 规则）在 j30 上的可行性核查')
    A('=' * 80)
    A('算例数 %d；正常结束 %d；超时(>%.0fs) %d；报错 %d；无输出 %d'
      % (len(rows), len(ok), TIMEOUT, sum(r['status'] == 'timeout' for r in rows),
         sum(r['status'] == 'error' for r in rows),
         sum(r['status'] == 'ok' and 'violations' not in r for r in rows)))
    if ok:
        A('至少有一项违约的算例: %d / %d' % (sum(r['violations'] > 0 for r in ok), len(ok)))
        for k, label in [('overlap', '同一时间三维重叠(箱体对数)'), ('bound', '越出场地边界'), ('dur', '工期被改动'),
                         ('prec', '违反紧前关系'), ('res', '常规资源超限(时刻×资源)'), ('missing', '活动缺失'),
                         ('nopos', '缺少坐标')]:
            A('  %-26s 涉及算例 %4d   合计 %6d' % (label, sum(r.get(k, 0) > 0 for r in ok), sum(r.get(k, 0) for r in ok)))
        both = [r for r in ok if r['test1_makespan'] and r['opt']]
        if both:
            A('')
            A('平均工期（%d 例）：test1 %.2f；本程序 MAI+S3 %.2f；MAI+S4 %.2f；PSPLIB 普通RCPSP最优 %.2f'
              % (len(both), sum(r['test1_makespan'] for r in both) / float(len(both)),
                 sum(r['mai_S3'] for r in both) / float(len(both)),
                 sum(r['mai_S4'] for r in both) / float(len(both)),
                 sum(r['opt'] for r in both) / float(len(both))))
            low = sum(1 for r in both if r['test1_makespan'] < r['opt'])
            A('test1 工期低于普通RCPSP最优值（不可能可行）的算例: %d' % low)
    A('')
    A('逐例明细见 test1核查.csv；test1 打印的原始调度表见 原始输出\\*.txt')
    with open(os.path.join(OUT, '核查报告.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    main()
