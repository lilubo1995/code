# -*- coding: utf-8 -*-
"""selftest.py —— 正式实验前的快速自检：检查函数能抓出违约、各方案在样例上可行、解析器适配 j30–j120。"""
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd  # noqa: E402

OUT = os.path.join(sd.OUT_ROOT, '自检结果.txt')
lines = []
fails = 0


def say(msg):
    lines.append(msg)
    print(msg, flush=True)


def expect(cond, msg):
    global fails
    if cond:
        say('  [通过] ' + msg)
    else:
        fails += 1
        say('  [失败] ' + msg)


def main():
    os.makedirs(sd.OUT_ROOT, exist_ok=True)
    say('自检 ' + time.strftime('%Y-%m-%d %H:%M:%S') + '  python ' + sys.version.split()[0])

    say('1. 几何判断')
    L = W = H = 10
    box = [(0, 0, 0, 5, 5, 5)]
    expect(not sd.fits(4, 4, 4, 2, 2, 2, box, L, W, H), '部分重叠的箱体判为冲突')
    expect(sd.fits(5, 0, 0, 5, 5, 5, box, L, W, H), '面贴面不算重叠')
    expect(not sd.fits(6, 0, 0, 5, 1, 1, [], L, W, H), '越出边界判为不可行')
    p = sd.find_pos_complete(5, 5, 5, box, L, W, H)
    expect(p is not None and sd.fits(p[0], p[1], p[2], 5, 5, 5, box, L, W, H), '完整候选坐标能找到合法位置 %s' % (p,))
    full = [(0, 0, 0, 10, 10, 5), (0, 0, 5, 10, 10, 5)]
    expect(sd.find_pos_complete(1, 1, 1, full, L, W, H) is None, '场地满时返回无位置')

    say('2. 读取各规模算例')
    samples = {}
    for s in sd.SETS:
        path = os.path.join(sd.DATA_DIR, s + '_integer', s + '1_1.sm')
        try:
            I = sd.load_instance(path)
            samples[s] = I
            expect(I.n in (32, 62, 92, 122), '%s: %d 个活动, 场地 %dx%dx%d, CPM=%d' % (I.name, I.n, I.L, I.W, I.H, I.cpm))
        except Exception:
            expect(False, '%s 读取失败\n%s' % (path, traceback.format_exc()))

    say('3. 检查函数能抓出人为制造的违约')
    I = samples.get('j30')
    if I is not None:
        S, F, P, _, _ = sd.Scheduler(I, 'IC', 'S4').run()
        expect(sum(sd.check(I, S, F, P).values()) == 0, 'IC+S4 原始方案无违约')
        big = [j for j in range(I.n) if I.d[j] > 0]
        a, b = big[0], big[1]
        S2, F2, P2 = list(S), list(F), list(P)
        S2[b], F2[b], P2[b] = S2[a], S2[a] + I.d[b], P2[a]   # 把 b 挪到与 a 同时同位置
        v = sd.check(I, S2, F2, P2)
        expect(v['overlap'] > 0 or v['prec'] > 0 or v['res'] > 0, '人为制造冲突后能被检出 %s' % v)
        P3 = list(P)
        P3[a] = (I.L, 0, 0)
        expect(sd.check(I, S, F, P3)['bound'] > 0, '越界能被检出')

    say('4. 各规模、各方案、部分规则可行性')
    for s, I in samples.items():
        for rule in ('IC', 'MAI', 'EFTD', 'SRCI', 'RAD'):
            res = {}
            S0, F0, P0, order, _ = sd.Scheduler(I, rule, None).run()
            res['RCPSP'] = (max(F0), sum(sd.check(I, S0, F0, P0, space=False).values()))
            for m in sd.STRATS:
                S1, F1, P1, _, _ = sd.Scheduler(I, rule, m).run()
                res[m] = (max(F1), sum(sd.check(I, S1, F1, P1).values()))
            S3, F3, P3, _ = sd.reactive(I, S0, order)
            res['REACT'] = (max(F3), sum(sd.check(I, S3, F3, P3).values()))
            ok = all(v[1] == 0 for v in res.values()) and all(v[0] >= I.cpm for v in res.values())
            expect(ok, '%s %-5s ' % (I.name, rule) + '  '.join('%s=%d' % (k, v[0]) for k, v in res.items()))

    say('')
    say('自检结束：失败 %d 项' % fails)
    with open(OUT, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return fails


if __name__ == '__main__':
    try:
        sys.exit(1 if main() else 0)
    except Exception:
        say('[FATAL]\n' + traceback.format_exc())
        os.makedirs(sd.OUT_ROOT, exist_ok=True)
        with open(OUT, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        sys.exit(2)
