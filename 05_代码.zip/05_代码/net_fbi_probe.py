# -*- coding: utf-8 -*-
"""
net_fbi_probe.py —— 深度学习放进主流程的方案检验（VM 小样本，样本同 fbi_probe）：
  net       只用网络逐道选工序
  net+FBI   再做前后向改进
  top2      网络挑前 2 个候选，只推演这 2 个
  top2+FBI  再做前后向改进
对照：act-pilot、act-pilot+FBI（读 fbi_probe 的缓存）、CP-SAT。

用法：python3 net_fbi_probe.py --part k/n [--budget 140]
      python3 net_fbi_probe.py --merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import cpsat3d as C
import fbi_probe as FB

OUT = os.path.join(C.OUT, '_fbi_net')
_model = None


def model():
    global _model
    if _model is None:
        import torch
        torch.set_num_threads(1)
        import act_net as N
        _model, _ = N.load_best(N.CKPT)
    return _model


def run_one(t):
    import act_net as N
    s_, nm, f = t
    I = sd.load_instance(f)
    m = model()
    rec = {'set': s_, 'viol': 0}
    for k, tag in ((1, 'net'), (2, 'top2')):
        t0 = time.time()
        ms, S, F, P, _ = N.run_net(m, I, k)
        rec['t_' + tag] = time.time() - t0
        rec['viol'] += sum(sd.check(I, S, F, P, space=True).values())
        t0 = time.time()
        _, best, _, v = FB.fbi(I, S, F, P)
        rec['t_' + tag + '_fbi'] = time.time() - t0
        rec[tag], rec[tag + '_fbi'] = ms, best
        rec['viol'] += v
    with open(os.path.join(OUT, nm + '.pkl'), 'wb') as fh:
        pickle.dump(rec, fh)
    return nm, rec


def run_part(part, budget):
    os.makedirs(OUT, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(OUT, '*.pkl')))
    tasks = [t for t in FB.sample()[k::n] if t[1] not in have]
    t0 = time.time()
    done = 0
    for t in tasks:
        est = {'j30': 1, 'j60': 3, 'j90': 7, 'j120': 14}[t[0]]
        if time.time() - t0 + est > budget:
            break
        nm, r = run_one(t)
        done += 1
        print('  %s net=%d→%d top2=%d→%d %.1fs viol=%d' % (nm, r['net'], r['net_fbi'], r['top2'], r['top2_fbi'],
                                                         r['t_top2'], r['viol']), flush=True)
    print('netfbi %s: 本次 %d，剩 %d，%.0fs' % (part, done, len(tasks) - done, time.time() - t0), flush=True)


def merge():
    rows = []
    for f in glob.glob(os.path.join(OUT, '*.pkl')):
        nm = os.path.splitext(os.path.basename(f))[0]
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        with open(os.path.join(FB.OUT, nm + '.pkl'), 'rb') as fh:
            a = pickle.load(fh)
        r.update({'act': a['act'], 'act_fbi': a['fbi'], 'cp': a['cp'], 't_act': a['t_act']})
        rows.append(r)
    cols = [('net', '网络', 't_net'), ('net_fbi', '网络+FBI', 't_net'), ('top2', '网络前2+推演', 't_top2'),
            ('top2_fbi', '网络前2+推演+FBI', 't_top2'), ('act', 'act-pilot', 't_act'),
            ('act_fbi', 'act-pilot+FBI', 't_act')]
    L = ['深度学习放进主流程：网络 + FBI 小样本（%d 例，每组 12 例）；数字 = 离 CP-SAT 最好解差多少（越小越好） / 平均耗时' % len(rows),
         '耗时为 VM 单线程实测，FBI 本身 <0.1 秒已含在内（量级可忽略）', '']
    L.append('%-6s' % '集合' + ''.join('%18s' % c[1] for c in cols))
    for s_ in C.SETS + ['ALL']:
        sel = [r for r in rows if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        L.append('%-6s' % s_ + ''.join('%9.2f%% %6.2fs' % (
            100 * np.mean([(r[c] - r['cp']) / r['cp'] for r in sel]), np.mean([r[t] for r in sel]))
            for c, _, t in cols))
    L.append('')
    for a_, b_ in (('top2_fbi', 'act'), ('top2_fbi', 'act_fbi'), ('net_fbi', 'net')):
        x = np.array([r[b_] - r[a_] for r in rows])
        L.append('  %s 对 %s：更短 %d / 持平 %d / 更长 %d，平均短 %.2f 天' % (a_, b_, (x > 0).sum(), (x == 0).sum(),
                                                                (x < 0).sum(), x.mean()))
    L.append('  违约数：%d' % sum(r['viol'] for r in rows))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(C.OUT, '网络加FBI_小样本.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part')
    ap.add_argument('--budget', type=float, default=140)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.part, a.budget)
    if a.merge:
        merge()
