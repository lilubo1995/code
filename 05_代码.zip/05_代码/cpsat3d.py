# -*- coding: utf-8 -*-
"""
cpsat3d.py —— 2.7 求解器对照：用 OR-Tools CP-SAT 直接求三维空间受限 RCPSP（含空间约束）的最优解或下界。

模型（与 sched3d.check 的约束一一对应）：
  变量：每道工序开工时间 s_j，和箱子坐标 x_j、y_j、z_j（不旋转，0 ≤ x_j ≤ L − l_j，其余同理）。
  紧前：s_j ≥ s_p + d_p。
  资源：每类资源一个 cumulative（任何时刻用量 ≤ 容量）。
  三维不重叠：任意两道可能同时施工的工序 i、j（彼此没有紧前/紧后路径），要么时间错开，
             要么在 x、y、z 某个方向上错开 —— 6 个“错开”里至少成立 1 个。某方向两箱之和超过场地时，这个方向不可能错开，直接不加。
  冗余约束（只帮求解器剪枝，不改变可行解）：同时施工的箱子总体积 ≤ 场地体积；工期 ≥ 普通 RCPSP 下界 LB。
  目标：总工期最短。
热启动：用 act-pilot 的方案作为初始提示（hint），所以求解器给出的工期一定不比 act-pilot 差。
输出：status（OPTIMAL = 已证最优；FEASIBLE = 时间到，给出当前最好解和下界），工期、下界，并用 sched3d.check 独立复核。

用法：python3 cpsat3d.py --set j30 --part k/n --tl 60 --workers 2 [--budget 150]   VM 分块
      python3 cpsat3d.py --set j30 --pool 4 --tl 120 --workers 8                    本机多进程（每个进程 8 线程）
      python3 cpsat3d.py --merge
"""
import os
import sys
import csv
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import act_pilot as A

ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, '06_实验结果', 'CP-SAT求解器')
CACHE = os.path.join(OUT, '_cache')
SETS = ['j30', 'j60', 'j90', 'j120']


def load_base():
    """612 例测试集的逐例结果（LB、LFT、pilot、act-pilot 工期）"""
    base = {}
    with open(os.path.join(A.OUT, '612例逐例结果.csv'), encoding='utf-8-sig') as fh:
        for row in csv.DictReader(fh):
            base[row['instance']] = row
    return base


def reach_sets(I):
    reach = [0] * I.n
    for j in reversed(I.topo):
        m = 0
        for s in I.succ[j]:
            m |= (1 << s) | reach[s]
        reach[j] = m
    return reach


def solve(I, tl=60.0, workers=8, lb=0, hint=None, ub=None, log=False, trace=None):
    """返回 dict：status, ms, bound, S, F, P, t, n_pairs。
    trace 给一个 list 时，每找到更好的解就记一条 (求解开始后的秒数, 工期)。"""
    from ortools.sat.python import cp_model
    n, d = I.n, I.d
    # 时间上界：给定 ub（热启动方案的工期）就用它，否则用所有工期之和
    H = int(ub) if ub is not None else int(sum(d))
    ES, EF, LS, LF, T = sd.cpm(I)
    m = cp_model.CpModel()
    s, iv = [None] * n, [None] * n
    for j in range(n):
        # 开工不早于最早开工；不晚于 H 减去“从 j 到终点的最长路径”
        tail = T - LS[j]                                  # j 开工后至少还要多少天才能全部完工
        s[j] = m.NewIntVar(ES[j], max(ES[j], H - tail), 's%d' % j)
        iv[j] = m.NewFixedSizeIntervalVar(s[j], d[j], 'i%d' % j)
    mk = m.NewIntVar(max(T, int(lb)), H, 'mk')
    for j in range(n):
        m.Add(mk >= s[j] + d[j])
        for p in I.pred[j]:
            m.Add(s[j] >= s[p] + d[p])
    for k in range(I.K):
        jj = [j for j in range(n) if I.r[j][k] > 0 and d[j] > 0]
        if jj:
            m.AddCumulative([iv[j] for j in jj], [I.r[j][k] for j in jj], I.R[k])
    # 空间
    box = [j for j in range(n) if d[j] > 0 and I.vol[j] > 0]
    X, Y, Z = {}, {}, {}
    for j in box:
        l, w, h = I.dim[j]
        X[j] = m.NewIntVar(0, I.L - l, 'x%d' % j)
        Y[j] = m.NewIntVar(0, I.W - w, 'y%d' % j)
        Z[j] = m.NewIntVar(0, I.H - h, 'z%d' % j)
    if box:
        m.AddCumulative([iv[j] for j in box], [I.vol[j] for j in box], I.L * I.W * I.H)   # 冗余：体积
    reach = reach_sets(I)
    npair = 0
    for a in range(len(box)):
        i = box[a]
        li, wi, hi = I.dim[i]
        for b in range(a + 1, len(box)):
            j = box[b]
            if (reach[i] >> j) & 1 or (reach[j] >> i) & 1:
                continue                                  # 有紧前路径，永远不会同时施工
            lj, wj, hj = I.dim[j]
            lits = []
            for cond in ((s[i] + d[i] <= s[j], True), (s[j] + d[j] <= s[i], True)):
                bl = m.NewBoolVar('')
                m.Add(cond[0]).OnlyEnforceIf(bl)
                lits.append(bl)
            for (P, sz_i, sz_j, cap) in ((X, li, lj, I.L), (Y, wi, wj, I.W), (Z, hi, hj, I.H)):
                if sz_i + sz_j > cap:
                    continue                              # 这个方向放不下两个箱子，不可能错开
                b1 = m.NewBoolVar('')
                m.Add(P[i] + sz_i <= P[j]).OnlyEnforceIf(b1)
                b2 = m.NewBoolVar('')
                m.Add(P[j] + sz_j <= P[i]).OnlyEnforceIf(b2)
                lits += [b1, b2]
            m.AddBoolOr(lits)
            npair += 1
    m.Minimize(mk)
    if hint is not None:
        hS, hP = hint
        for j in range(n):
            m.AddHint(s[j], int(hS[j]))
        for j in box:
            p = hP[j] if hP[j] is not None else (0, 0, 0)
            m.AddHint(X[j], int(p[0]))
            m.AddHint(Y[j], int(p[1]))
            m.AddHint(Z[j], int(p[2]))
    sol = cp_model.CpSolver()
    sol.parameters.max_time_in_seconds = float(tl)
    sol.parameters.num_workers = int(workers)
    sol.parameters.log_search_progress = bool(log)
    t0 = time.time()
    if trace is not None:
        class _CB(cp_model.CpSolverSolutionCallback):
            def on_solution_callback(self):
                trace.append((time.time() - t0, int(round(self.ObjectiveValue()))))
        st = sol.Solve(m, _CB())
    else:
        st = sol.Solve(m)
    dt = time.time() - t0
    name = sol.StatusName(st)
    r = {'status': name, 't': dt, 'n_pairs': npair, 'bound': int(round(sol.BestObjectiveBound())) if
         st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None}
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        S = [sol.Value(s[j]) for j in range(n)]
        F = [S[j] + d[j] for j in range(n)]
        P = [None] * n
        for j in box:
            P[j] = (sol.Value(X[j]), sol.Value(Y[j]), sol.Value(Z[j]))
        r.update({'ms': sol.Value(mk), 'S': S, 'F': F, 'P': P})
    else:
        r.update({'ms': None, 'S': None, 'F': None, 'P': None})
    return r


def run_one(task):
    s_, name, f, tl, workers, lb = task
    I = sd.load_instance(f)
    t0 = time.time()
    ams, aS, aF, aP, _ = A.run_act_pilot(I)               # 热启动方案
    t_act = time.time() - t0
    hint, ub = (aS, aP), ams
    old = os.path.join(CACHE, name + '.pkl')
    if os.path.exists(old):                                # 之前跑过但没证最优：从上次的最好解接着找
        with open(old, 'rb') as fh:
            o = pickle.load(fh)
        if o.get('S') is not None and o['ms'] <= ams:
            hint, ub = (o['S'], o['P']), o['ms']
    r = solve(I, tl, workers, lb=lb, hint=hint, ub=ub)
    if r['S'] is None:                                     # 时间内连提示解都没确认：退回提示解，下界用 LB
        r.update({'status': 'NO_SOLUTION', 'ms': ub, 'S': list(hint[0]), 'P': list(hint[1]), 'bound': lb})
        r['F'] = [r['S'][j] + I.d[j] for j in range(I.n)]
    if os.path.exists(old):
        r['bound'] = max(r['bound'], o.get('bound') or 0)  # 下界取历次最大（每次都是有效下界）
    viol = None
    if r['S'] is not None:
        viol = sum(sd.check(I, r['S'], r['F'], r['P'], space=True).values())
        if r['ms'] != max(r['F']):
            viol += 1
    rec = {'set': s_, 'name': name, 'status': r['status'], 'ms': r['ms'], 'bound': r['bound'], 't': r['t'],
           'act_hint': ams, 't_act': t_act, 'lb_rcpsp': lb, 'n_pairs': r['n_pairs'], 'viol': viol,
           'tl': tl, 'workers': workers, 'S': r['S'], 'P': r['P']}
    path = os.path.join(CACHE, name + '.pkl')
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(rec, fh)
    os.replace(path + '.tmp', path)
    return name, rec


def tasks_of(sets, tl, workers):
    import train_dqn as T
    base = load_base()
    have = set()
    for f in glob.glob(os.path.join(CACHE, '*.pkl')):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        # 已证最优，或已用不短于本次的时间上限跑过 → 跳过；否则（未证最优且这次给的时间更长）重跑
        if r['status'] == 'OPTIMAL' or r['tl'] >= tl:
            have.add(r['name'])
    out = []
    for s_, nm, f in T.list_instances()['test']:
        if s_ in sets and nm not in have:
            out.append((s_, nm, f, tl, workers, int(float(base[nm]['LB'])) if nm in base else 0))
    return out, len(have)


def run_part(sets, part, tl, workers, budget):
    os.makedirs(CACHE, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    tasks, nh = tasks_of(sets, tl, workers)
    tasks = tasks[k::n]
    t00 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t00 + tl + 5 > budget:
            break
        nm, r = run_one(t)
        done += 1
        print('  %s %s ms=%s bound=%s act=%d %.0fs viol=%s' % (nm, r['status'], r['ms'], r['bound'], r['act_hint'],
                                                             r['t'], r['viol']), flush=True)
    print('cpsat %s: 本次 %d 例，剩 %d 例（之前已有 %d），%.0fs' % (part, done, len(tasks) - done, nh,
                                                        time.time() - t00), flush=True)


def run_pool(sets, procs, tl, workers):
    from multiprocessing import Pool
    from progress import Bar
    os.makedirs(CACHE, exist_ok=True)
    tasks, nh = tasks_of(sets, tl, workers)
    print('CP-SAT：待跑 %d 例（已有 %d 例），%d 个进程 × %d 线程，每例上限 %.0f 秒' % (
        len(tasks), nh, procs, workers, tl), flush=True)
    bar = Bar('cp-sat', nh + len(tasks), nh)
    nopt = 0
    with Pool(procs) as pool:
        for k, (nm, r) in enumerate(pool.imap_unordered(run_one, tasks), 1):
            nopt += r['status'] == 'OPTIMAL'
            bar.update(nh + k, '已证最优 %d' % nopt)
            print('[%d/%d] %s %s ms=%s bound=%s act=%d %.0fs viol=%s' % (
                k, len(tasks), nm, r['status'], r['ms'], r['bound'], r['act_hint'], r['t'], r['viol']), flush=True)
    bar.done()


def _boot_ci(x, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return np.percentile(m, 2.5), np.percentile(m, 97.5)


def merge():
    base = load_base()
    rows = []
    for f in sorted(glob.glob(os.path.join(CACHE, '*.pkl'))):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        b = base[r['name']]
        r.update({'LB': float(b['LB']), 'LFT': float(b['LFT']), 'pilot': float(b['pilot']), 'act': float(b['act'])})
        rows.append(r)
    if not rows:
        print('没有结果')
        return
    tl = sorted(set(r['tl'] for r in rows))
    L = ['2.7 CP-SAT 求解器对照 —— 紧空间 U5S6 测试集（各参数组第 8~10 个），含三维空间约束',
         '每例时间上限 %s 秒；以 act-pilot 方案热启动，所以 CP-SAT 的工期不会比 act-pilot 差。' % '/'.join('%g' % t for t in tl),
         'LB_rcpsp = 普通 RCPSP 下界（不含空间）；CP 下界 = CP-SAT 证明的三维问题下界（含空间，真正的下界）。',
         '真实最优性差距 ≤ (方法工期 − CP 下界)/CP 下界；已证最优的算例上就是精确差距。', '',
         '一、概况']
    L.append('%-6s %5s %8s %10s %12s %12s %10s %8s' % ('集合', '例数', '已证最优', '比act更短', 'LB_rcpsp', 'CP下界', 'CP工期',
                                                    '违约'))
    for s_ in SETS + ['ALL']:
        sel = [r for r in rows if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        L.append('%-6s %5d %8d %10d %12.1f %12.1f %10.1f %8d' % (
            s_, len(sel), sum(r['status'] == 'OPTIMAL' for r in sel),
            sum(r['ms'] is not None and r['ms'] < r['act'] for r in sel),
            np.mean([r['LB'] for r in sel]), np.mean([r['bound'] for r in sel]),
            np.mean([r['ms'] for r in sel]), sum(r['viol'] or 0 for r in sel)))
    L += ['', '二、各方法相对 CP 下界的差距 (工期 − CP下界)/CP下界（真实最优性差距的上界；越小越好）',
          '   括号内为旧口径：相对不含空间的 LB_rcpsp']
    cols = ['LFT', 'pilot', 'act', 'ms']
    L.append('%-6s' % '集合' + ''.join('%22s' % c.replace('ms', 'CP-SAT') for c in cols))
    for s_ in SETS + ['ALL']:
        sel = [r for r in rows if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        L.append('%-6s' % s_ + ''.join('%11.2f%% (%6.2f%%)' % (
            100 * np.mean([(r[c] - r['bound']) / r['bound'] for r in sel]),
            100 * np.mean([(r[c] - r['LB']) / r['LB'] for r in sel])) for c in cols))
    opt = [r for r in rows if r['status'] == 'OPTIMAL']
    if opt:
        L += ['', '三、只看已证最优的 %d 例：act-pilot 离真正最优多远' % len(opt)]
        x = np.array([(r['act'] - r['ms']) / r['ms'] for r in opt])
        lo, hi = _boot_ci(x)
        L.append('  act-pilot 比最优长 %.2f%%  [%.2f%%, %.2f%%]；恰好最优 %d 例（%.0f%%）' % (
            100 * x.mean(), 100 * lo, 100 * hi, int((x <= 1e-9).sum()), 100 * (x <= 1e-9).mean()))
        for c in ('LFT', 'pilot'):
            y = np.array([(r[c] - r['ms']) / r['ms'] for r in opt])
            L.append('  %-9s 比最优长 %.2f%%；恰好最优 %d 例' % (c, 100 * y.mean(), int((y <= 1e-9).sum())))
    better = [r for r in rows if r['ms'] is not None and r['ms'] < r['act']]
    x = np.array([(r['act'] - r['ms']) / r['act'] for r in rows if r['ms'] is not None])
    L += ['', '四、CP-SAT 对 act-pilot：平均再短 %.2f%%，%d 例更短 / %d 例相同' % (100 * x.mean(), len(better),
                                                                     len(rows) - len(better))]
    L += ['', '五、耗时（秒/例）']
    for s_ in SETS:
        sel = [r for r in rows if r['set'] == s_]
        if sel:
            to = [r['t'] for r in sel if r['status'] == 'OPTIMAL']
            L.append('  %-5s CP-SAT 平均 %.1f s（已证最优的平均 %.1f s），act-pilot %.2f s，平均可同时施工的工序对 %.0f' % (
                s_, np.mean([r['t'] for r in sel]), np.mean(to) if to else float('nan'),
                np.mean([r['t_act'] for r in sel]), np.mean([r['n_pairs'] for r in sel])))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(OUT, '汇总.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    with open(os.path.join(OUT, '逐例结果.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        keys = ['set', 'status', 'ms', 'bound', 'LB', 'LFT', 'pilot', 'act', 't', 't_act', 'n_pairs', 'viol', 'tl']
        w.writerow(['instance'] + keys)
        for r in rows:
            w.writerow([r['name']] + [r[k] for k in keys])
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--set', default='j30', help='逗号分隔，如 j30,j60')
    ap.add_argument('--part')
    ap.add_argument('--pool', type=int, default=0)
    ap.add_argument('--tl', type=float, default=60)
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    sets = a.set.split(',')
    if a.part:
        run_part(sets, a.part, a.tl, a.workers, a.budget)
    if a.pool:
        run_pool(sets, a.pool, a.tl, a.workers)
    if a.merge:
        merge()
