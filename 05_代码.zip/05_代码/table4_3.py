# -*- coding: utf-8 -*-
"""
table4_3.py —— 由已有实验记录汇总第四章表4-3（612 个紧空间测试算例全量验证）。只读结果文件，不重新求解，几秒出结果。

读取：
  06_实验结果/CP-SAT求解器/FBI全量_逐例结果.csv        各方法 + 前后向改进的逐例工期与耗时（05_代码/net_fbi_full.py 生成）
  06_实验结果/紧空间_U5S6_full/runs_传统执行_LFT.csv     传统执行（LFT 纸面计划 + 放不下就等，strategy=REACT）
        这是 sched3d.py 全量实验 runs.csv（32MB）里与本表有关的行（rule=LFT，612 个测试算例）；
        如果放了完整的 runs.csv，也可以用 --runs 指定它。

列含义（FBI全量_逐例结果.csv）：
  act  = 本方案（平台致优版）：全坐标放置 + 按工序沙盒推演 act-pilot + 前后向改进
  top2 = 网络速度档（平台智速版）：网络挑前 2 个候选 + 沙盒推演 + 前后向改进
  LFTcsv = LFT 单一规则 + 全坐标放置；cp/opt = CP-SAT 工期 / 是否已证最优
  t_* = 排程耗时，tf_* = 前后向改进耗时（秒）
"""
import os
import csv
import argparse

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, '06_实验结果')


def boot_ci(x, n=2000, seed=0):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return np.percentile(m, 2.5), np.percentile(m, 97.5)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runs', default=os.path.join(RES, '紧空间_U5S6_full', 'runs_传统执行_LFT.csv'))
    a = ap.parse_args()
    with open(os.path.join(RES, 'CP-SAT求解器', 'FBI全量_逐例结果.csv'), encoding='utf-8-sig') as fh:
        rows = list(csv.DictReader(fh))
    react = {}
    with open(a.runs, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            if r['rule'] == 'LFT' and r['strategy'] == 'REACT':
                react[r['instance']] = float(r['makespan'])
    rows = [r for r in rows if r['instance'] in react]
    f = lambda r, c: float(r[c])
    print('算例数 %d（应为 612）' % len(rows))

    tr = np.array([react[r['instance']] for r in rows])
    lft = np.array([f(r, 'LFTcsv') for r in rows])
    cp = np.array([f(r, 'cp') for r in rows])
    opt = np.array([r['opt'] == 'True' for r in rows])
    sets = np.array([r['set'] for r in rows])
    print('传统执行平均工期 %.1f 天' % tr.mean())
    out = {}
    for m, nm in (('act', '本方案（平台致优版）'), ('top2', '网络速度档（平台智速版）')):
        x = np.array([f(r, m) for r in rows])
        sec = np.mean([f(r, 't_' + m) + f(r, 'tf_' + m) for r in rows])
        d = tr - x
        out[m] = x
        print('\n%s  平均工期 %.1f 天' % (nm, x.mean()))
        print('  比传统执行缩短        %.1f%%（逐例缩短比例取平均）' % (np.mean(d / tr) * 100))
        print('  按规模                ' + '，'.join('%s %.1f%%' % (s, np.mean((d / tr)[sets == s]) * 100)
                                                    for s in ('j30', 'j60', 'j90', 'j120')))
        print('  比 LFT 单一规则缩短   %.1f%%' % (np.mean((lft - x) / lft) * 100))
        print('  更短/持平/更长（例）  %d/%d/%d' % ((d > 0).sum(), (d == 0).sum(), (d < 0).sum()))
        print('  距精确最优（%d 个已证最优算例）%.2f%%' % (opt.sum(), np.mean(((x - cp) / cp)[opt]) * 100))
        print('  平均每例计算用时      %.2f 秒' % sec)
    print('\n约束违约数（各方法合计）%d' % sum(int(float(r['viol'])) for r in rows))
    g = (out['top2'] - out['act']) / out['act'] * 100
    lo, hi = boot_ci(g)
    print('速度档对本方案：工期平均长 %.2f%%（95%% 区间 %.2f%%～%.2f%%），更短/持平/更长 %d/%d/%d' % (
        g.mean(), lo, hi, (g < 0).sum(), (g == 0).sum(), (g > 0).sum()))


if __name__ == '__main__':
    main()
