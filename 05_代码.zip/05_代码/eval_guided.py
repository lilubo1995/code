# -*- coding: utf-8 -*-
"""
eval_guided.py —— DQN 引导的沙盒前瞻：每个决策点只推演 DQN 认为最好的 k 条规则（k=3），选推演工期最短的执行。
对比完整 pilot（推演 10 条），看 DQN 能省多少计算、损失多少质量。测试集同 train_dqn.py。
用法：python3 eval_guided.py --part 0/6 ... 5/6，然后 python3 eval_guided.py --merge
"""
import os
import sys
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import train_dqn as T

K_TOP = 3


def run_guided(I, agent, k=K_TOP):
    env = rl_env.Env(I)
    s = env.reset()
    while not env.done:
        q = agent.net.q(s[None, :])[0]
        cand = np.argsort(-q)[:k]
        best_a, best_v = None, None
        for a in cand:
            e = env.clone()
            while not e.done:
                e.step(int(a))
            v = e.makespan()
            if best_v is None or v < best_v:
                best_a, best_v = int(a), v
        s, _, _ = env.step(best_a)
    return env.makespan(), env.S, env.F, env.P


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--part', type=str, default=None)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        kk, n = (int(x) for x in a.part.split('/'))
        path = os.path.join(T.OUT, '_guided_p%dof%d.pkl' % (kk, n))
        rows = []
        if os.path.exists(path):
            with open(path, 'rb') as fh:
                rows = pickle.load(fh)
        done = set(r[1] for r in rows)
        with open(T.CKPT, 'rb') as fh:
            st = pickle.load(fh)
        agent = st['agent']
        agent.net.p = st['best_params']
        t00 = time.time()
        items = T.list_instances()['test'][kk::n]
        for s, name, f in items:
            if name in done:
                continue
            I = sd.load_instance(f)
            t0 = time.time()
            ms, S, F, P = run_guided(I, agent)
            dt = time.time() - t0
            v = sd.check(I, S, F, P, space=True)
            rows.append((s, name, ms, dt, sum(v.values())))
            if time.time() - t00 > 140:
                break
        with open(path, 'wb') as fh:
            pickle.dump(rows, fh)
        print('guided part %d/%d: %d/%d' % (kk, n, len(rows), len(items)))
        return
    import glob
    import pandas as pd
    rows = []
    for f in glob.glob(os.path.join(T.OUT, '_guided_p*.pkl')):
        with open(f, 'rb') as fh:
            rows += pickle.load(fh)
    g = pd.DataFrame(rows, columns=['set', 'instance', 'guided3', 'guided3_s', 'g_viol']).drop_duplicates('instance')
    d = pd.read_csv(os.path.join(T.OUT, '测试集逐例结果.csv'))
    d = d.merge(g, on=['set', 'instance'])
    assert len(d) == 612, len(d)
    d['violations'] = d['violations'] + d['g_viol']
    d = d.drop(columns=['g_viol'])
    d.to_csv(os.path.join(T.OUT, '测试集逐例结果.csv'), index=False, encoding='utf-8-sig')
    lines = ['', '=' * 100,
             'DQN 引导的沙盒前瞻（guided3）：每个决策点只推演 DQN 排名前 3 的规则，选最好的执行',
             '', '%-6s %10s %10s %10s %12s %12s %10s' % ('集合', 'LFT', 'DQN', 'guided3', 'pilot(10条)',
                                                    'guided3耗时', 'pilot耗时')]
    for s in T.SETS + ['ALL']:
        x = d if s == 'ALL' else d[d['set'] == s]
        gap = lambda c: 100 * (x[c] / x['LB'] - 1).mean()
        lines.append('%-6s %9.2f%% %9.2f%% %9.2f%% %11.2f%% %10.2fs %9.2fs' % (
            s, gap('LFT'), gap('DQN'), gap('guided3'), gap('pilot'), x['guided3_s'].mean(), x['pilot_s'].mean()))
    lines.append('')
    lines.append('相对 LFT 的工期缩短（逐例 (LFT−方法)/LFT 的平均）与胜/平/负：')
    for c in ['DQN', 'oracle10', 'guided3', 'pilot']:
        red = 100 * ((d['LFT'] - d[c]) / d['LFT']).mean()
        diff = d['LFT'] - d[c]
        lines.append('  %-9s 平均缩短 %5.2f%%   平均少 %5.1f 天   更好/持平/更差 = %d / %d / %d' % (
            c, red, diff.mean(), (diff > 0).sum(), (diff == 0).sum(), (diff < 0).sum()))
    lines.append('总违规数（全部方法、全部测试算例）：%d' % int(d['violations'].sum()))
    txt = '\n'.join(lines)
    with open(os.path.join(T.OUT, '结果报告.txt'), 'a', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)


if __name__ == '__main__':
    main()
