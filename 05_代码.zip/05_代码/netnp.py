# -*- coding: utf-8 -*-
"""netnp.py —— 选工序网络（05_代码/act_net.py 的 ActNet）的 numpy 推理版。

结构与 act_net.build_model 一一对应：
  输入层 Linear(40→h) + ReLU
  每层：自身 Linear + 4 类边各一个 Linear（按入度取平均），残差 + LayerNorm
  汇总向量 = [全部工序均值, 执行中工序均值, 此刻能开工工序均值, 20 维全局特征]
  打分头：Linear(4h+20→256) ReLU Linear(256→128) ReLU Linear(128→1)
只做推理，dropout 不起作用。权重从 06_实验结果/选工序网络/act_ckpt.pt 读取（ptload.py，不需要 torch）。
"""
import numpy as np
import rl_env
import graph_feats as GF
import act_net as N          # 只用 node_x / candidates / feasible 等不需要 torch 的函数
import act_pilot as A
import ptload

LN_EPS = 1e-5


class NetNP(object):
    def __init__(self, path):
        state = ptload.load(path)
        self.cfg = dict(state['cfg'])
        w = state['best']
        self.layers = int(self.cfg['layers'])
        self.h = int(self.cfg['h'])
        self.drop = set(self.cfg.get('drop', ()))
        f = lambda k: np.asarray(w[k], dtype=np.float32)
        self.inp = (f('inp.weight'), f('inp.bias'))
        self.self_lin = [(f('self_lin.%d.weight' % L), f('self_lin.%d.bias' % L)) for L in range(self.layers)]
        self.rel = [[f('rel_lin.%d.%d.weight' % (L, t)) for t in range(GF.N_ETYPE)] for L in range(self.layers)]
        self.norm = [(f('norm.%d.weight' % L), f('norm.%d.bias' % L)) for L in range(self.layers)]
        self.head = [(f('head.%d.weight' % i), f('head.%d.bias' % i)) for i in (0, 3, 5)]
        if self.inp[0].shape[1] != N.F_IN:
            raise ValueError('网络输入维度 %d 与代码 %d 不符' % (self.inp[0].shape[1], N.F_IN))
        self.n_params = int(sum(np.asarray(v).size for v in w.values()))
        self.epoch = state.get('best_epoch', state.get('epoch'))

    def graph(self, env):
        """每个算例只算一次：静态特征 + 每类边的 (src, dst, 1/入度)"""
        Xs, E = GF.static_graph(env)
        n = Xs.shape[0]
        edges = []
        for t in range(GF.N_ETYPE):
            e = E[t]
            if len(e) == 0 or t in self.drop:
                edges.append(None)
                continue
            src, dst = e[:, 0], e[:, 1]
            deg = np.bincount(dst, minlength=n).astype(np.float32)
            edges.append((src, dst, 1.0 / np.maximum(deg, 1.0)))
        return Xs, edges

    def score(self, g, D, G, ok, cand):
        Xs, edges = g
        n = Xs.shape[0]
        x = N.node_x(Xs, D, list(ok), cand)
        W, b = self.inp
        hh = np.maximum(x @ W.T + b, 0)
        for L in range(self.layers):
            Ws, bs = self.self_lin[L]
            m = hh @ Ws.T + bs
            for t, e in enumerate(edges):
                if e is None:
                    continue
                src, dst, dinv = e
                msg = (hh @ self.rel[L][t].T)[src]
                agg = np.zeros((n, self.h), dtype=np.float32)
                np.add.at(agg, dst, msg)
                m = m + agg * dinv[:, None]
            z = hh + np.maximum(m, 0)
            mu = z.mean(1, keepdims=True)
            var = ((z - mu) ** 2).mean(1, keepdims=True)
            g_, b_ = self.norm[L]
            hh = (z - mu) / np.sqrt(var + LN_EPS) * g_ + b_

        def mean_pool(mask):
            w = mask.astype(np.float32)
            return (hh * w[:, None]).sum(0) / max(float(w.sum()), 1.0)
        okm = np.zeros(n, dtype=bool)
        okm[list(ok)] = True
        pooled = np.concatenate([mean_pool(np.ones(n, dtype=bool)), mean_pool(D[:, 1] > 0.5),
                                 mean_pool(okm), np.asarray(G, dtype=np.float32)])
        hc = hh[np.asarray(cand, dtype=np.int64)]
        z = np.concatenate([hc, np.repeat(pooled[None], len(cand), 0)], 1)
        (W1, b1), (W2, b2), (W3, b3) = self.head
        z = np.maximum(z @ W1.T + b1, 0)
        z = np.maximum(z @ W2.T + b2, 0)
        return (z @ W3.T + b3)[:, 0]


def run_top2(net, I, topk=2, on_step=None):
    """网络打分后只推演前 topk 名候选（流程与 act_net.run_net 相同，打分器换成 numpy 版）。
    on_step(env, info)：每次真正做选择后回调，用于报告进度。返回 (工期, S, F, P, 选择次数, 推演次数)"""
    env = rl_env.Env(I)
    env.reset()
    g = net.graph(env)
    n_dec = n_roll = 0
    while not env.done:
        while True:
            ok = N.feasible(env)
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = N.candidates(env, ok)
            if len(cand) == 1:
                j = cand[0]
            else:
                s = net.score(g, GF.dyn_feats(env), env.obs().astype(np.float32), ok, cand)
                order = [cand[i] for i in np.argsort(-s)]
                best = None
                for c in order[:topk]:
                    e = env.clone()
                    e._start(c, ok[c])
                    v = min(A.rollout_from(e, a) for a in range(A.NA))
                    n_roll += A.NA
                    if best is None or v < best[1]:
                        best = (c, v)
                j = best[0]
                n_dec += 1
                if on_step:
                    on_step(env, {'n_cand': len(cand), 'kept': min(topk, len(cand))})
            env._start(j, ok[j])
        env._advance()
        env._to_decision(rl_env.ACTIONS[A.LFT])
    return env.makespan(), env.S, env.F, env.P, n_dec, n_roll
