# -*- coding: utf-8 -*-
"""
sensitivity.py —— 场地松紧敏感性实验：箱子尺寸完全相同（gen_tight 的种子只跟算例名有关），只改场地大小，
看“场地越挤，本方案优势越大”是否成立。

场地：6³（U5S6，已有）、7³、8³、10³，以及原版 R-instances（31×25×34，空间几乎不起作用）。
算例：测试集每个参数组第 8 个（204 例）。
每例记录：
  RCPSP   不考虑空间的 LFT 计划工期（纸面）
  REACT   按该计划执行、空间放不下就顺延（传统做法）
  S4      S4 + 单一 LFT 规则
  pilot   S4 + 按规则沙盒推演
  act     S4 + 按工序沙盒推演（本方案）
  并行度、空间占用、REACT 空间冲突次数、违约数
用法：python3 sensitivity.py --run U5S8 --part 0/2 --budget 150；python3 sensitivity.py --merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import sched3d as sd
import rl_env
import act_pilot as A

ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, '06_实验结果', '场地松紧敏感性')
SITES = ['U5S6', 'U5S7', 'U5S8', 'U5S10', '原版']
SETS = ['j30', 'j60', 'j90', 'j120']


def data_dir(tag):
    return sd.DATA_DIR if tag == '原版' else os.path.join(sd.DATA_DIR, '紧空间_' + tag)


def items(tag, set_name):
    fs = sorted(glob.glob(os.path.join(data_dir(tag), set_name + '_integer', '*_8.sm')))
    return [(os.path.splitext(os.path.basename(f))[0], f) for f in fs]


def conc(I, S, F):
    T = max(F)
    c = np.zeros(T)
    v = np.zeros(T)
    for j in range(I.n):
        if I.d[j] > 0 and I.vol[j] > 0:
            c[S[j]:F[j]] += 1
            v[S[j]:F[j]] += I.vol[j]
    return c.mean(), v.mean() / float(I.L * I.W * I.H)


def one(I, act_cache=None):
    S0, F0, P0, order, _ = sd.Scheduler(I, 'LFT', None).run()
    S1, F1, P1, st = sd.reactive(I, S0, order)
    S2, F2, P2, _, _ = sd.Scheduler(I, 'LFT', 'S4').run()
    c0, _ = conc(I, S0, F0)
    c2, v2 = conc(I, S2, F2)
    viol = sum(sd.check(I, S1, F1, P1, space=True).values()) + sum(sd.check(I, S2, F2, P2, space=True).values())
    r = {'n': I.n, 'cpm': I.cpm, 'rcpsp': max(F0), 'react': max(F1), 's4': max(F2),
         'conf': st['space_conf'], 'conc_rcpsp': c0, 'conc_s4': c2, 'occ_s4': v2}
    if act_cache is not None:                     # U5S6 已在 act_pilot 上限测试里算过
        r['pilot'], r['act'] = act_cache['pilot'], act_cache['act']
        r['t_pilot'], r['t_act'] = act_cache['t_pilot'], act_cache['t_act']
    else:
        t0 = time.time()
        p = rl_env.run_pilot(I)
        t1 = time.time()
        ms, S3, F3, P3, _ = A.run_act_pilot(I)
        t2 = time.time()
        viol += sum(sd.check(I, p[1], p[2], p[3], space=True).values()) if len(p) >= 4 else 0
        viol += sum(sd.check(I, S3, F3, P3, space=True).values())
        r.update({'pilot': p[0], 'act': ms, 't_pilot': t1 - t0, 't_act': t2 - t1})
    r['viol'] = viol
    return r


def run_part(tag, part, budget):
    os.makedirs(OUT, exist_ok=True)
    kk, n = (int(x) for x in part.split('/'))
    path = os.path.join(OUT, '_cache_%s_p%dof%d.pkl' % (tag, kk, n))
    cache = {}
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            cache = pickle.load(fh)
    old = {}
    if tag == 'U5S6':
        for f in glob.glob(os.path.join(A.OUT, '_cache_*.pkl')):
            with open(f, 'rb') as fh:
                old.update({k: v for k, v in pickle.load(fh).items() if 'pilot' in v})
    todo = [(s, nm, f) for s in SETS for nm, f in items(tag, s)][kk::n]
    todo.sort(key=lambda x: int(x[0][1:]))
    t00 = time.time()
    for s, nm, f in todo:
        if nm in cache:
            continue
        if time.time() - t00 > budget:
            break
        I = sd.load_instance(f)
        r = one(I, old.get(nm))
        r['set'] = s
        cache[nm] = r
        with open(path + '.tmp', 'wb') as fh:
            pickle.dump(cache, fh, protocol=4)
        os.replace(path + '.tmp', path)
    print('%s part %s: %d/%d，用时 %.0fs' % (tag, part, sum(1 for x in todo if x[1] in cache), len(todo),
                                         time.time() - t00), flush=True)


def _one_task(task):
    tag, s, nm, f = task
    r = one(sd.load_instance(f))
    r['set'] = s
    return tag, nm, r


def run_pool(workers):
    """Windows 本机多进程：所有场地里还没跑的算例（VM 已跑的自动跳过）"""
    from multiprocessing import Pool, cpu_count
    os.makedirs(OUT, exist_ok=True)
    have = load()
    tasks = [(tag, s, nm, f) for tag in SITES if tag != 'U5S6' for s in SETS for nm, f in items(tag, s)
             if nm not in have[tag]]
    tasks.sort(key=lambda x: -int(x[1][1:]))
    workers = workers or max(1, cpu_count() - 1)
    print('场地敏感性：待跑 %d 例，进程数 %d' % (len(tasks), workers), flush=True)
    caches = {}
    t00 = time.time()
    from progress import Bar
    bar = Bar('site', len(tasks))
    bar.update(0)
    with Pool(workers) as pool:
        for k, (tag, nm, r) in enumerate(pool.imap_unordered(_one_task, tasks), 1):
            bar.update(k, tag)
            path = os.path.join(OUT, '_cache_%s_win.pkl' % tag)
            if tag not in caches:
                caches[tag] = pickle.load(open(path, 'rb')) if os.path.exists(path) else {}
            caches[tag][nm] = r
            with open(path + '.tmp', 'wb') as fh:
                pickle.dump(caches[tag], fh, protocol=4)
            os.replace(path + '.tmp', path)
            if k % 20 == 0 or k == len(tasks):
                print('[%d/%d] 累计 %.1f 分钟' % (k, len(tasks), (time.time() - t00) / 60), flush=True)
    bar.done()


def load():
    rec = {}
    for tag in SITES:
        d = {}
        for f in glob.glob(os.path.join(OUT, '_cache_%s_*.pkl' % tag)):
            with open(f, 'rb') as fh:
                d.update(pickle.load(fh))
        rec[tag] = d
    return rec


def merge():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for fp in ('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 'C:/Windows/Fonts/msyh.ttc'):
        if os.path.exists(fp):
            font_manager.fontManager.addfont(fp)
            plt.rcParams['font.family'] = font_manager.FontProperties(fname=fp).get_name()
            break
    rec = load()
    label = {'U5S6': '6×6×6', 'U5S7': '7×7×7', 'U5S8': '8×8×8', 'U5S10': '10×10×10', '原版': '原版 31×25×34'}
    L = ['场地松紧敏感性：箱子尺寸相同（边长 1~5 随机，与 U5S6 同一批），只改场地大小。测试集各参数组第 8 个算例。',
         '缩短% 均为逐例 (对照−方法)/对照 的平均。并行度 = 平均每天同时施工的工序数（S4+LFT 方案）。', '']
    hdr = '%-16s %4s %8s %8s %8s %9s %9s %9s %9s %10s %10s %10s %6s'
    L.append(hdr % ('场地', '例数', '只看资源', '加空间', '空间占用', 'REACT冲突', 'REACT比计划', 'S4比REACT',
                    'act比REACT', 'pilot比S4', 'act比S4', 'act比pilot', '违约'))
    summ = {}
    for s in SETS + ['ALL']:
        L.append('-- %s' % s)
        for tag in SITES:
            r = [x for x in rec[tag].values() if s == 'ALL' or x['set'] == s]
            if not r:
                continue
            m = lambda k: np.mean([x[k] for x in r])
            red = lambda a, b: 100 * np.mean([1 - x[a] / float(x[b]) for x in r])
            row = (label[tag], len(r), m('conc_rcpsp'), m('conc_s4'), 100 * m('occ_s4'), m('conf'),
                   -red('react', 'rcpsp'), red('s4', 'react'), red('act', 'react'), red('pilot', 's4'),
                   red('act', 's4'), red('act', 'pilot'), sum(x['viol'] for x in r))
            L.append('%-16s %4d %8.2f %8.2f %7.0f%% %9.1f %8.1f%% %8.1f%% %8.1f%% %9.1f%% %9.1f%% %9.1f%% %6d' % row)
            summ[(s, tag)] = row
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '汇总.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)

    tags = [t for t in SITES if ('ALL', t) in summ]
    if not tags:
        return
    x = np.arange(len(tags))
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.2))
    ax = axs[0]
    for s, mk in zip(SETS, 'osD^'):
        y = [summ[(s, t)][8] if (s, t) in summ else np.nan for t in tags]
        ax.plot(x, y, marker=mk, label=s)
    ax.set_xticks(x)
    ax.set_xticklabels([label[t] for t in tags], fontsize=12)
    ax.set_ylabel('本方案比传统顺延缩短（%）')
    ax.set_title('场地越挤，本方案相对传统做法的优势越大', loc='left', fontsize=12)
    ax.axhline(0, color='k', lw=0.6)
    ax.legend(fontsize=12)
    ax = axs[1]
    ax.plot(x, [summ[('ALL', t)][2] for t in tags], marker='o', color='#9aa5b1', label='只看资源')
    ax.plot(x, [summ[('ALL', t)][3] for t in tags], marker='o', color='#2b7bb9', label='加上空间')
    ax.set_xticks(x)
    ax.set_xticklabels([label[t] for t in tags], fontsize=12)
    ax.set_ylabel('平均每天同时施工的工序数')
    ax.set_title('空间对并行度的压缩（204 例平均）', loc='left', fontsize=12)
    ax.legend(fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, '场地松紧曲线.png'), dpi=160)
    plt.close(fig)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', type=str)
    ap.add_argument('--part', type=str, default='0/1')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    ap.add_argument('--pool', action='store_true')
    ap.add_argument('--workers', type=int, default=0)
    a = ap.parse_args()
    if a.run:
        run_part(a.run, a.part, a.budget)
    if a.pool:
        run_pool(a.workers)
    if a.merge:
        merge()
