# -*- coding: utf-8 -*-
"""
fbi_probe.py —— 自查：act-pilot 和 CP-SAT 之间 9% 的差距，有多少是“逐道开工(并行 SGS)”框架本身造成的？
做法：对 act-pilot 的方案做“前后向改进”（FBI / justification，Valls 等 2005 EJOR）：
  后向：把工程倒过来（紧前紧后互换），按 act-pilot 的完工时间从晚到早，用串行 SGS 逐道排（S4 找位置）；
  前向：再按后向方案的开工先后，用串行 SGS 正着排一遍。重复 ROUNDS 次，取最短。
串行 SGS 允许“故意等待、往前插空”，正是并行 SGS（act-pilot 所在框架）做不到的。
时间倒过来后，资源和三维不重叠约束不变，所以后向方案翻转回来同样可行；每个方案都用 sched3d.check 复核。

用法：python3 fbi_probe.py --part k/n [--budget 150]   （缓存 06_实验结果\CP-SAT求解器\_fbi）
      python3 fbi_probe.py --merge
"""
import os
import sys
import glob
import time
import pickle
import heapq
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import act_pilot as A
import cpsat3d as C

OUT = os.path.join(C.OUT, '_fbi')
ROUNDS = 3
PER_SET = 12


class _Rev:
    """紧前紧后互换的“倒过来”的算例（其余属性照搬）"""
    def __init__(self, I):
        self.__dict__.update(I.__dict__)
        self.pred, self.succ = I.succ, I.pred
        self.topo = list(reversed(I.topo))


def serial(I, prio):
    """串行 SGS（同 cp_probe.serial，但返回整个方案）：prio 越小越先排，只从紧前都已排好的工序里挑"""
    n, d = I.n, I.d
    tp = {j: k for k, j in enumerate(I.topo)}
    npred = [len(I.pred[j]) for j in range(n)]
    hq = [(prio[j], tp[j], j) for j in range(n) if npred[j] == 0]
    heapq.heapify(hq)
    order = []
    while hq:
        _, _, j = heapq.heappop(hq)
        order.append(j)
        for s in I.succ[j]:
            npred[s] -= 1
            if npred[s] == 0:
                heapq.heappush(hq, (prio[s], tp[s], s))
    S, F, P = [None] * n, [None] * n, [None] * n
    done = []
    for j in order:
        est = max([F[p] for p in I.pred[j]] or [0])
        if d[j] == 0:
            S[j] = F[j] = est
            continue
        ts = sorted(set([est] + [F[i] for i in done if F[i] > est]))
        l, w, h = I.dim[j]
        for t in ts:
            e = t + d[j]
            ov = [i for i in done if S[i] < e and t < F[i]]
            pts = [t] + [S[i] for i in ov if S[i] > t]
            ok = True
            for tau in pts:
                for k in range(I.K):
                    if I.r[j][k] and I.r[j][k] + sum(I.r[i][k] for i in ov if S[i] <= tau < F[i]) > I.R[k]:
                        ok = False
                        break
                if not ok:
                    break
            if not ok:
                continue
            pos = None
            if I.vol[j] > 0:
                boxes = [(P[i][0], P[i][1], P[i][2]) + tuple(I.dim[i]) for i in ov if P[i] is not None]
                pos = sd.find_pos_complete(l, w, h, boxes, I.L, I.W, I.H)
                if pos is None:
                    continue
            S[j], F[j], P[j] = t, e, pos
            done.append(j)
            break
        if S[j] is None:
            raise RuntimeError('serial: %d 排不下' % j)
    return S, F, P


def fbi(I, S, F, P):
    """返回 (仅前向串行一次的工期, FBI 后最好工期, 最好方案, 违约数)"""
    R = _Rev(I)
    viol = 0
    S1, F1, P1 = serial(I, S)                       # 只做一次前向串行（同顺序，允许插空）
    viol += sum(sd.check(I, S1, F1, P1, space=True).values())
    ser1 = max(F1)
    best = (max(F), S, F, P)
    if ser1 < best[0]:
        best = (ser1, S1, F1, P1)
    cS, cF = S, F
    for _ in range(ROUNDS):
        bS, bF, bP = serial(R, [-x for x in cF])     # 后向：完工晚的先排
        M = max(bF)
        rS = [M - bF[j] for j in range(I.n)]         # 翻回正向时间
        rF = [rS[j] + I.d[j] for j in range(I.n)]
        viol += sum(sd.check(I, rS, rF, bP, space=True).values())
        if M < best[0]:
            best = (M, rS, rF, bP)
        fS, fF, fP = serial(I, rS)                   # 前向：按翻回后的开工先后
        viol += sum(sd.check(I, fS, fF, fP, space=True).values())
        if max(fF) < best[0]:
            best = (max(fF), fS, fF, fP)
        cS, cF = fS, fF
    return ser1, best[0], best, viol


def sample():
    import train_dqn as T
    te = T.list_instances()['test']
    out = []
    for s_ in C.SETS:
        sel = [t for t in te if t[0] == s_]
        out += sel[::max(1, len(sel) // PER_SET)][:PER_SET]
    return out


def run_one(t):
    s_, nm, f = t
    I = sd.load_instance(f)
    t0 = time.time()
    ams, aS, aF, aP, _ = A.run_act_pilot(I)
    ta = time.time() - t0
    t0 = time.time()
    ser1, best, _, viol = fbi(I, aS, aF, aP)
    tf = time.time() - t0
    with open(os.path.join(C.CACHE, nm + '.pkl'), 'rb') as fh:
        cp = pickle.load(fh)
    rec = {'set': s_, 'act': ams, 'ser1': ser1, 'fbi': best, 'cp': cp['ms'], 'cp_status': cp['status'],
           'cp_bound': cp['bound'], 't_act': ta, 't_fbi': tf, 'viol': viol}
    with open(os.path.join(OUT, nm + '.pkl'), 'wb') as fh:
        pickle.dump(rec, fh)
    return nm, rec


def run_part(part, budget):
    os.makedirs(OUT, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(OUT, '*.pkl')))
    tasks = [t for t in sample()[k::n] if t[1] not in have]
    t0 = time.time()
    done = 0
    for t in tasks:
        est = {'j30': 2, 'j60': 6, 'j90': 15, 'j120': 25}[t[0]]
        if time.time() - t0 + est > budget:
            break
        nm, r = run_one(t)
        done += 1
        print('  %s act=%d 串行=%d FBI=%d CP=%d(%s) %.1fs+%.1fs viol=%d' % (
            nm, r['act'], r['ser1'], r['fbi'], r['cp'], r['cp_status'][:3], r['t_act'], r['t_fbi'], r['viol']),
            flush=True)
    print('fbi %s: 本次 %d，剩 %d，%.0fs' % (part, done, len(tasks) - done, time.time() - t0), flush=True)


def merge():
    rows = []
    for f in glob.glob(os.path.join(OUT, '*.pkl')):
        with open(f, 'rb') as fh:
            rows.append(pickle.load(fh))
    L = ['act-pilot + 前后向改进(FBI) 小样本（每组 %d 例，共 %d 例），数字 = 比 act-pilot 再短多少 / 离 CP-SAT 还差多少' % (
        PER_SET, len(rows)), '']
    L.append('%-6s %4s %12s %12s %16s %16s %10s %8s' % ('集合', '例数', '串行一次', 'FBI', 'act离CP', 'FBI离CP',
                                                    '差距缩小', 'FBI耗时'))
    for s_ in C.SETS + ['ALL']:
        sel = [r for r in rows if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        a = np.array([r['act'] for r in sel], float)
        s1 = np.array([r['ser1'] for r in sel], float)
        fb = np.array([r['fbi'] for r in sel], float)
        cp = np.array([r['cp'] for r in sel], float)
        g0, g1 = (a - cp) / cp, (fb - cp) / cp
        L.append('%-6s %4d %11.2f%% %11.2f%% %15.2f%% %15.2f%% %9.0f%% %7.2fs' % (
            s_, len(sel), 100 * np.mean((a - s1) / a), 100 * np.mean((a - fb) / a), 100 * g0.mean(),
            100 * g1.mean(), 100 * (1 - g1.mean() / g0.mean()) if g0.mean() > 0 else 0,
            np.mean([r['t_fbi'] for r in sel])))
    fb = np.array([r['fbi'] for r in rows])
    a = np.array([r['act'] for r in rows])
    L.append('')
    L.append('FBI 比 act-pilot 更短 %d 例 / 相同 %d 例 / 更长 0 例（取最好，不会更长）；违约 %d' % (
        (fb < a).sum(), (fb == a).sum(), sum(r['viol'] for r in rows)))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(C.OUT, 'FBI前后向改进_小样本.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.part, a.budget)
    if a.merge:
        merge()
