# -*- coding: utf-8 -*-
"""
rl_env.py —— 把 S4 调度器拆成“逐决策点”的强化学习环境

每到一个决策时刻 t，智能体从 ACTIONS 里选一条优先规则；环境按这条规则给可开工活动排队，
再用 S4（完整候选坐标）逐个找位置开工，然后推进到下一个有活动完工的时刻。
所以无论智能体怎么选，排出来的方案都满足紧前、资源、三维不重叠——网络只负责“排序”。

只有“至少两个活动资源上都能开工”的时刻才需要智能体做选择，其余时刻规则不影响结果，自动跳过。
奖励 = -(下一个决策时刻 - 当前时刻) / CPM，整局奖励之和 = -(工期 - 常数)/CPM。
"""
import numpy as np
import sched3d as sd

# 动作 = 10 条静态规则（动态 *D 规则每步要重算关键路径，太慢，且与 LST/LFT 结果高度重合）
ACTIONS = ['LFT', 'LST', 'GRPW*', 'MTS', 'TIMROS', 'TIMRES', 'ACTRES', 'SRCI', 'CI-a', 'IC']
N_FEAT = 20


class Env(object):
    def __init__(self, I):
        self.I = I
        n, K = I.n, I.K
        self.LF = I.pv['LFT']
        self.TF = I.pv['TF']
        self.maxtf = float(max(self.TF)) or 1.0
        self.maxd = float(max(I.d)) or 1.0
        self.sumd = float(sum(I.d)) or 1.0
        real = [j for j in range(n) if I.d[j] > 0]
        self.maxvol = float(max(I.vol[j] for j in real)) or 1.0
        self.rr = [sum(I.r[j][k] / float(I.R[k]) for k in range(K) if I.R[k] > 0) / K for j in range(n)]
        self.cpm = float(I.cpm) or 1.0
        # 预先算好每条规则的排序键，决策时直接排序
        self.keys = {}
        for a in ACTIONS:
            v = I.pv[a]
            if a in sd.MIN_RULES:
                self.keys[a] = [(v[j], j) for j in range(n)]
            else:
                self.keys[a] = [(-v[j], j) for j in range(n)]
        self.static = [n / 120.0,
                       sum(I.vol[j] for j in real) / float(I.V) / 15.0,
                       float(np.mean([self.rr[j] for j in real])),
                       float(np.mean([len(I.succ[j]) for j in real])) / 3.0]

    # ------------------------------------------------------------------ 基本操作
    def reset(self):
        I = self.I
        n = I.n
        self.t = 0
        self.S = [None] * n
        self.F = [None] * n
        self.P = [None] * n
        self.npred = [len(p) for p in I.pred]
        self.elig = set(j for j in range(n) if self.npred[j] == 0)
        self.active = []
        self.used = [0] * I.K
        self.boxes = {}
        self.remaining = n
        self.left_d = self.sumd
        self.n_dec = 0
        self._zero()
        self.done = False
        self._to_decision(ACTIONS[0])
        return None if self.done else self.obs()

    def _start(self, j, pos):
        I = self.I
        t = self.t
        self.S[j], self.F[j], self.P[j] = t, t + I.d[j], pos
        self.elig.discard(j)
        self.remaining -= 1
        self.left_d -= I.d[j]
        if I.d[j] > 0:
            self.active.append(j)
            for k in range(I.K):
                self.used[k] += I.r[j][k]
            if pos is not None:
                l, w, h = I.dim[j]
                self.boxes[j] = (pos[0], pos[1], pos[2], l, w, h)
        else:
            for s in I.succ[j]:
                self.npred[s] -= 1
                if self.npred[s] == 0:
                    self.elig.add(s)

    def _zero(self):
        I = self.I
        zs = [j for j in self.elig if I.d[j] == 0]
        while zs:
            for j in sorted(zs):
                self._start(j, None)
            zs = [j for j in self.elig if I.d[j] == 0]

    def _res_ok(self, j):
        I = self.I
        rj = I.r[j]
        for k in range(I.K):
            if self.used[k] + rj[k] > I.R[k]:
                return False
        return True

    def _pass(self, rule):
        """按 rule 排队，资源够且 S4 找得到位置就开工（与 sched3d.Scheduler 的 S4 分支一致）"""
        key = self.keys[rule]
        self._pass_order(sorted(self.elig, key=lambda j: key[j]))

    def _pass_order(self, cand):
        """按给定顺序逐个尝试开工"""
        I = self.I
        failed = []
        for j in cand:
            if not self._res_ok(j):
                continue
            pos = None
            if I.d[j] > 0 and I.vol[j] > 0:
                l, w, h = I.dim[j]
                if any(l >= a and w >= b and h >= c for a, b, c in failed):
                    continue
                pos = sd.find_pos_complete(l, w, h, list(self.boxes.values()), I.L, I.W, I.H)
                if pos is None:
                    failed.append((l, w, h))
                    continue
            self._start(j, pos)
        if not self.active and self.elig:
            raise RuntimeError('空场地仍无法开工')

    def _advance(self):
        I = self.I
        if self.remaining == 0:
            self.done = True
            return
        self.t = min(self.F[j] for j in self.active)
        keep = []
        for j in self.active:
            if self.F[j] <= self.t:
                for k in range(I.K):
                    self.used[k] -= I.r[j][k]
                self.boxes.pop(j, None)
                for s in I.succ[j]:
                    self.npred[s] -= 1
                    if self.npred[s] == 0:
                        self.elig.add(s)
            else:
                keep.append(j)
        self.active = keep
        self._zero()
        if self.remaining == 0:
            self.done = True

    def _trivial(self):
        return sum(1 for j in self.elig if self._res_ok(j)) <= 1

    def _to_decision(self, rule):
        """自动推进，直到遇到需要选择的时刻或结束"""
        while not self.done and (not self.elig or self._trivial()):
            if self.elig:
                self._pass(rule)
            self._advance()

    def step(self, a):
        rule = ACTIONS[a]
        t0 = self.t
        self.n_dec += 1
        self._pass(rule)
        self._advance()
        self._to_decision(rule)
        t1 = self.makespan() if self.done else self.t
        r = -(t1 - t0) / self.cpm
        return (None if self.done else self.obs()), r, self.done

    def step_scores(self, scores):
        """不选规则，直接按网络给每个活动打的分数（越大越先）排队开工"""
        t0 = self.t
        self.n_dec += 1
        self._pass_order(sorted(self.elig, key=lambda j: (-scores[j], j)))
        self._advance()
        self._to_decision(ACTIONS[0])     # 平凡时刻至多一个活动可开工，顺序无影响
        t1 = self.makespan() if self.done else self.t
        return (None if self.done else self.obs()), -(t1 - t0) / self.cpm, self.done

    def makespan(self):
        return max(f for f in self.F if f is not None)

    # ------------------------------------------------------------------ 仿真沙盒：复制当前状态
    def clone(self):
        e = Env.__new__(Env)
        e.__dict__.update(self.__dict__)          # 静态数据共享
        e.S, e.F, e.P = self.S[:], self.F[:], self.P[:]
        e.npred = self.npred[:]
        e.elig = set(self.elig)
        e.active = self.active[:]
        e.used = self.used[:]
        e.boxes = dict(self.boxes)
        return e

    def rollout_values(self):
        """对每个动作 a：在副本里从此刻起一直用规则 a 排到底，返回各动作的工期（向量）"""
        out = np.zeros(len(ACTIONS))
        for a in range(len(ACTIONS)):
            e = self.clone()
            while not e.done:
                e.step(a)
            out[a] = e.makespan()
        return out

    # ------------------------------------------------------------------ 状态特征
    def obs(self):
        I = self.I
        t = self.t
        el = list(self.elig)
        feas = [j for j in el if self._res_ok(j)]
        ur = [self.used[k] / float(I.R[k]) for k in range(I.K) if I.R[k] > 0]
        vol_act = sum(I.vol[j] for j in self.active) / float(I.V)
        lf = [(self.LF[j] - t) / self.cpm for j in el]
        tf = [self.TF[j] / self.maxtf for j in el]
        vo = [I.vol[j] / self.maxvol for j in el]
        rr = [self.rr[j] for j in el]
        du = [I.d[j] / self.maxd for j in el]
        f = [t / (2.0 * self.cpm),
             1.0 - self.remaining / float(I.n),
             self.left_d / self.sumd,
             float(np.mean(ur)), float(np.max(ur)),
             vol_act,
             min(len(el) / 10.0, 2.0),
             len(feas) / float(len(el)),
             len(self.active) / 10.0,
             float(np.mean(lf)), float(np.min(lf)),
             float(np.mean(tf)), float(np.min(tf)),
             float(np.mean(vo)), float(np.max(vo)),
             float(np.mean(rr)),
             float(np.mean(du)),
             ] + self.static[:3]
        return np.array(f, dtype=np.float64)


def run_pilot(I, record=None):
    """前瞻仿真（pilot）策略：每个决策点把 10 条规则各推演到底，选工期最短的那条执行一步。
    因为“继续用当前最好的规则”总是候选之一，最终工期一定 ≤ 10 条规则各跑一次的最好值。
    record 不为 None 时把 (状态, 各动作推演工期/CPM) 存进去，作为 Q 网络的训练目标。"""
    env = Env(I)
    s = env.reset()
    while not env.done:
        v = env.rollout_values()
        if record is not None:
            record.append((s, v / env.cpm))
        s, _, _ = env.step(int(np.argmin(v)))
    return env.makespan(), env.S, env.F, env.P, env.n_dec


def run_policy(I, choose):
    """choose(obs)->动作下标；返回 (工期, S, F, P, 决策次数)"""
    env = Env(I)
    s = env.reset()
    while not env.done:
        s, _, _ = env.step(choose(s))
    return env.makespan(), env.S, env.F, env.P, env.n_dec
