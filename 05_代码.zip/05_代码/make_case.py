# -*- coding: utf-8 -*-
"""
make_case.py —— 框架 4.1 案例（1.5）+ 甘特图 / 空间占用图 / 三维布局图（5.1、5.2）

三个方案（同一算例）：
  传统计划 ：不考虑空间的 LFT 计划（CPM 思路），纸面工期
  传统执行 ：按传统计划执行，空间放不下就往后推（REACT），实际工期
  本方案   ：S4 完整候选坐标 + 按工序沙盒推演（act-pilot）
用法：python3 make_case.py [--name j6041_8]
输出：06_实验结果/案例_<name>/  案例数字.txt、逐工序排程.csv、甘特图对比.png、空间占用.png、三维布局_*.png
"""
import os
import sys
import csv
import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import act_pilot as A
import disturb as D

ROOT = os.path.dirname(HERE)
for fp in ('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 'C:/Windows/Fonts/msyh.ttc'):
    if os.path.exists(fp):
        font_manager.fontManager.addfont(fp)
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=fp).get_name()
        break
plt.rcParams['axes.unicode_minus'] = False

C_PLAN, C_REACT, C_OURS, C_LATE = '#9aa5b1', '#d9822b', '#2b7bb9', '#c23b22'


def occupancy(I, S, F):
    """每天正在施工的箱子总体积 / 场地体积"""
    T = max(F)
    occ = np.zeros(T + 1)
    for j in range(I.n):
        if I.d[j] > 0 and I.vol[j] > 0:
            occ[S[j]:F[j]] += I.vol[j]
    return occ / float(I.L * I.W * I.H)


def gantt(ax, I, S, F, order, color, title, T, late=None, ghost=None, mark=None):
    real = [j for j in order if I.d[j] > 0]
    for y, j in enumerate(real):
        if ghost is not None:
            ax.barh(y, I.d[j], left=ghost[j], height=0.8, color='none', edgecolor='#b0b0b0', lw=0.6)
        c = C_LATE if (late is not None and late[j]) else color
        ax.barh(y, F[j] - S[j], left=S[j], height=0.6, color=c, edgecolor='none')
    ax.set_xlim(0, T)
    ax.set_ylim(len(real) - 0.5, -0.5)
    ax.set_yticks([])
    ax.set_ylabel('工序（按计划开工顺序）')
    ms = max(F)
    ax.axvline(ms, color='k', lw=1, ls='--')
    ax.text(ms + 1, 2, '%d 天' % ms, va='top', fontsize=12)
    if mark is not None:
        ax.axvline(mark, color=C_LATE, lw=1.2)
        ax.text(mark + 1, len(real) - 2, '第 %d 天\n首次空间拥堵' % mark, color=C_LATE, fontsize=12, va='bottom')
    ax.set_title(title, loc='left', fontsize=12)


def box_faces(x, y, z, l, w, h):
    v = np.array([[x, y, z], [x + l, y, z], [x + l, y + w, z], [x, y + w, z],
                  [x, y, z + h], [x + l, y, z + h], [x + l, y + w, z + h], [x, y + w, z + h]])
    idx = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [2, 3, 7, 6], [1, 2, 6, 5], [0, 3, 7, 4]]
    return [[v[i] for i in f] for f in idx]


def layout3d(path, I, S, F, P, t, title, blocked=()):
    fig = plt.figure(figsize=(6, 5.4))
    ax = fig.add_subplot(111, projection='3d')
    act = [j for j in range(I.n) if I.d[j] > 0 and I.vol[j] > 0 and S[j] <= t < F[j]]
    cmap = plt.get_cmap('tab20')
    for k, j in enumerate(act):
        x, y, z = P[j]
        l, w, h = I.dim[j]
        pc = Poly3DCollection(box_faces(x, y, z, l, w, h), facecolor=cmap(k % 20), edgecolor='k', lw=0.5, alpha=0.55)
        ax.add_collection3d(pc)
        ax.text(x + l / 2, y + w / 2, z + h / 2, str(j), fontsize=12, ha='center')
    ax.set_xlim(0, I.L)
    ax.set_ylim(0, I.W)
    ax.set_zlim(0, I.H)
    ax.set_box_aspect((1, 1, 1))
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    used = sum(I.vol[j] for j in act) / float(I.L * I.W * I.H)
    tl = '%s\n第 %d 天：%d 道工序同时施工，占场地 %.0f%%' % (title, t, len(act), 100 * used)
    if blocked:
        tl += '\n计划此时开工但放不下：' + '、'.join('工序%d（%d×%d×%d）' % ((j,) + tuple(I.dim[j])) for j in blocked)
    ax.set_title(tl, fontsize=12)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return act


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', default='j6041_8')
    ap.add_argument('--fbi', action='store_true', help='本方案再做前后向改进（FBI），输出到 案例_<name>_FBI')
    a = ap.parse_args()
    set_name = a.name.split('_')[0][:3]
    f = dict(D.list_items(set_name))[a.name]
    I = sd.load_instance(f)
    out = os.path.join(ROOT, '06_实验结果', '案例_' + a.name + ('_FBI' if a.fbi else ''))
    os.makedirs(out, exist_ok=True)

    # 1. 传统计划（不考虑空间）与传统执行（空间放不下就顺延）
    S0, F0, P0, order, _ = sd.Scheduler(I, 'LFT', None).run()
    S1, F1, P1, st1 = sd.reactive(I, S0, order)
    # 2. 本方案
    ms2, S2, F2, P2, nsub = A.run_act_pilot(I)
    ms_act = ms2
    if a.fbi:
        import fbi_probe as FB
        _, ms2, best, _ = FB.fbi(I, S2, F2, P2)
        S2, F2, P2 = list(best[1]), list(best[2]), list(best[3])
    TAG = 'S4 + 按工序沙盒推演 + 前后向改进' if a.fbi else 'S4 + 按工序沙盒推演'
    # 对照：S4 单一规则、按规则 pilot
    s4 = max(sd.Scheduler(I, 'LFT', 'S4').run()[1])
    pilot = A.rl_env.run_pilot(I)[0]
    v1 = sum(sd.check(I, S1, F1, P1, space=True).values())
    v2 = sum(sd.check(I, S2, F2, P2, space=True).values())

    occ0, occ1, occ2 = occupancy(I, S0, F0), occupancy(I, S1, F1), occupancy(I, S2, F2)
    over = int((occ0 > 1).sum())
    late = [S1[j] > S0[j] for j in range(I.n)]
    n_real = sum(1 for j in range(I.n) if I.d[j] > 0)
    T = int(max(max(F0), max(F1), max(F2)) * 1.08)
    first = st1.get('first_conf')

    # 案例数字
    L = ['案例 %s（U5S6 紧空间，%d 道实际工序，场地 %d×%d×%d，关键路径 %d 天）' % (a.name, n_real, I.L, I.W, I.H, I.cpm), '',
         '传统计划（不考虑空间的 LFT 计划）纸面工期：%d 天' % max(F0),
         '  该计划中同时施工的箱子总体积超过场地体积的天数：%d 天；峰值为场地的 %.0f%%' % (over, 100 * occ0.max()),
         '传统执行（空间放不下就顺延）：第 %d 天首次出现空间拥堵（%s 计划开工但场地里放不下）；'
         '共 %d 次因空间放不下而顺延，%d 道工序被推迟' %
         (first, '、'.join('工序%d（%d×%d×%d）' % ((j,) + tuple(I.dim[j])) for j in st1.get('first_conf_jobs', [])),
          st1['space_conf'], st1['delayed']),
         '  实际工期：%d 天（比纸面计划多 %d 天）' % (max(F1), max(F1) - max(F0)),
         '本方案（%s）：%d 天，比传统实际工期缩短 %d 天（%.1f%%）' %
         (TAG, ms2, max(F1) - ms2, 100.0 * (max(F1) - ms2) / max(F1)),
         '  其中只做沙盒推演（不做前后向改进）：%d 天' % ms_act,
         '对照：S4 + 单一 LFT 规则 %d 天；S4 + 按规则 pilot %d 天' % (s4, pilot),
         '可行性检查违约数：传统执行 %d，本方案 %d' % (v1, v2)]
    txt = '\n'.join(L)
    with open(os.path.join(out, '案例数字.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)

    with open(os.path.join(out, '逐工序排程.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(['工序', '工期', '长', '宽', '高', '计划开工', '计划完工', '传统执行开工', '传统执行完工',
                    '传统x', '传统y', '传统z', '本方案开工', '本方案完工', '本方案x', '本方案y', '本方案z'])
        for j in range(I.n):
            p1 = P1[j] or ('', '', '')
            p2 = P2[j] or ('', '', '')
            w.writerow([j, I.d[j]] + list(I.dim[j]) + [S0[j], F0[j], S1[j], F1[j]] + list(p1) +
                       [S2[j], F2[j]] + list(p2))

    # # 甘特图对比
    # fig, axs = plt.subplots(3, 1, figsize=(11, 12), sharex=True)
    # gantt(axs[0], I, S0, F0, order, C_PLAN, '① 传统计划（不考虑空间）：纸面 %d 天，但有 %d 天场地放不下' % (max(F0), over), T)
    # gantt(axs[1], I, S1, F1, order, C_REACT, '② 传统执行（空间不够就顺延）：实际 %d 天；红色 = 被推迟的工序，灰框 = 原计划时段' % max(F1),
    #       T, late=late, ghost=S0, mark=first)
    # order2 = sorted(range(I.n), key=lambda j: (S2[j], j))
    # gantt(axs[2], I, S2, F2, order2, C_OURS, ('③ 本方案（S4 定位置 + 按工序沙盒推演 + 前后向改进）：%d 天，比②短 %.1f%%' if a.fbi else '③ 本方案（S4 定位置 + 按工序沙盒推演）：%d 天，比②短 %.1f%%') %
    #       (ms2, 100.0 * (max(F1) - ms2) / max(F1)), T)
    # axs[2].set_xlabel('时间（天）')
    # fig.tight_layout()
    # fig.savefig(os.path.join(out, '甘特图对比.png'), dpi=180)
    # # plt.close(fig)

    # ================= 字体调大设置 =================
    plt.rcParams.update({
        'font.size': 14,  # 全局基础字号
        'axes.titlesize': 16,  # 子图标题（① 传统计划...）
        'axes.labelsize': 14,  # 坐标轴标签（时间（天）、工序...）
        'xtick.labelsize': 13,  # X轴刻度数字
        'ytick.labelsize': 13  # Y轴刻度数字
    })
    # ================================================

    # 甘特图对比
    fig, axs = plt.subplots(3, 1, figsize=(11, 12), sharex=True)
    gantt(axs[0], I, S0, F0, order, C_PLAN, '① 传统计划（不考虑空间）：%d 天，但有 %d 天场地放不下' % (max(F0), over),
          T)
    gantt(axs[1], I, S1, F1, order, C_REACT,
          '② 传统执行（空间不够就顺延）：实际 %d 天；红色 = 被推迟的工序，灰框 = 原计划时段' % max(F1),
          T, late=late, ghost=S0, mark=first)
    order2 = sorted(range(I.n), key=lambda j: (S2[j], j))
    gantt(axs[2], I, S2, F2, order2, C_OURS, (
        '③ 本方案（S4 定位置 + 按工序沙盒推演 + 前后向改进）：%d 天，比②短 %.1f%%' if a.fbi else '③ 本方案（S4 定位置 + 按工序沙盒推演）：%d 天，比②短 %.1f%%') %
          (ms2, 100.0 * (max(F1) - ms2) / max(F1)), T)

    # 专门针对 X 轴标签再确认一下字号
    axs[2].set_xlabel('时间（天）', fontsize=14)

    # 👇 加上 pad=2.0 增加子图间距，防止标题变大后和上一张图重叠
    fig.tight_layout(pad=2.0)

    # 👇 加上 bbox_inches='tight'，防止最右侧的超长标题被切掉
    fig.savefig(os.path.join(out, '甘特图对比.png'), dpi=180, bbox_inches='tight')
    # plt.close(fig)

    # 空间占用
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(occ0 * 100, color=C_PLAN, lw=1, label='① 传统计划（不考虑空间）')
    ax.plot(occ1 * 100, color=C_REACT, lw=1, label='② 传统执行（空间不够就顺延）')
    ax.plot(occ2 * 100, color=C_OURS, lw=1, label='③ 本方案')
    ax.axhline(100, color='k', ls='--', lw=1)
    ax.text(T * 0.99, 103, '体积', ha='right', fontsize=10)
    ax.fill_between(range(len(occ0)), 100, occ0 * 100, where=occ0 > 1, color=C_LATE, alpha=0.2, label='传统计划放不下')
    if first is not None:
        ax.axvline(first, color=C_LATE, lw=1)
    ax.set_xlim(0, T)
    ax.set_xlabel('时间（天）')
    ax.set_ylabel('占用率（%）')
    ax.legend(loc='upper right', fontsize=10, ncol=2)
    ax.set_title('空间占用随时间变化（%s）' % a.name, loc='left', fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(out, '空间占用.png'), dpi=160)
    # plt.close(fig)

    # 三维布局：首次拥堵那天的传统执行 vs 本方案；以及本方案占用最高的一天
    tt = first if first is not None else 0
    layout3d(os.path.join(out, '三维布局_第%d天_传统执行.png' % tt), I, S1, F1, P1, tt, '② 传统执行',
             blocked=st1.get('first_conf_jobs', []))
    layout3d(os.path.join(out, '三维布局_第%d天_本方案.png' % tt), I, S2, F2, P2, tt, '③ 本方案')
    tp = int(np.argmax(occ2))
    layout3d(os.path.join(out, '三维布局_第%d天_本方案占用最高.png' % tp), I, S2, F2, P2, tp, '③ 本方案（占用最高的一天）')
    print('图已保存到', out)


if __name__ == '__main__':
    main()
