# -*- coding: utf-8 -*-
"""
cp_probe.py —— “能不能学 CP-SAT”的可学性探针（不训练网络，只回放 CP-SAT 的解）。

问题：网络是在“逐道开工 + 不故意等待 + S4 放角落”的框架里做决策。CP-SAT 的好解能不能在这个框架里走出来？
做法：把每例 CP-SAT 解的开工时间当优先序（越早越先），在 act-pilot 同样的逐道决策框架里回放：
  full  = 每次从“此刻能开的全部工序”里开 CP 最早的那道 → 框架能表达 CP 解到什么程度（学 CP-SAT 的天花板）
  cand  = 只能从 act-pilot 的候选（10 条规则各自首选）里开 CP 最早的那道 → 不改动作空间时，完美模仿 CP 的天花板
另统计：CP 最想开的那道落在 act-pilot 候选里的比例。

用法：python3 cp_probe.py --part k/n [--budget 150]    VM 分块（缓存 06_实验结果\CP-SAT求解器\_probe）
      python3 cp_probe.py --merge
"""
import os
import sys
import csv
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A
import cpsat3d as C

NA = len(rl_env.ACTIONS)
PCACHE = os.path.join(C.OUT, '_probe')
SETS = C.SETS


def replay(I, pr, mode):
    env = rl_env.Env(I)
    env.reset()
    dec = in_cand = 0
    while not env.done:
        while True:
            ok = {}
            for j in env.elig:
                f, pos = A.place(env, j)
                if f:
                    ok[j] = pos
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = []
            for a in range(NA):
                key = env.keys[rl_env.ACTIONS[a]]
                j = min(ok, key=lambda x: key[x])
                if j not in cand:
                    cand.append(j)
            jcp = min(ok, key=lambda x: (pr[x], x))
            dec += 1
            in_cand += jcp in cand
            j = jcp if mode == 'full' else min(cand, key=lambda x: (pr[x], x))
            env._start(j, ok[j])
        env._advance()
        env._to_decision('LFT')
    viol = sum(sd.check(I, env.S, env.F, env.P, space=True).values())
    return env.makespan(), dec, in_cand, viol


def serial(I, Scp, Pcp=None):
    """串行 SGS：按 CP-SAT 开工先后，逐道排在“紧前完工后、资源够、放得下”的最早时刻（允许故意等待、插空）。
    Pcp=None 时位置用 S4 现找；给 Pcp 时用 CP-SAT 的位置（理论上不会比 CP-SAT 长，作自检）。"""
    n, d = I.n, I.d
    import heapq
    tp = {j: k for k, j in enumerate(I.topo)}
    # 优先序可能不满足紧前（例如加了噪声）：每次只从“紧前都已排”的工序里取优先值最小的
    npred = [len(I.pred[j]) for j in range(n)]
    hq = [(Scp[j], tp[j], j) for j in range(n) if npred[j] == 0]
    heapq.heapify(hq)
    order = []
    while hq:
        _, _, j = heapq.heappop(hq)
        order.append(j)
        for s in I.succ[j]:
            npred[s] -= 1
            if npred[s] == 0:
                heapq.heappush(hq, (Scp[s], tp[s], s))
    S, F, P = [None] * n, [None] * n, [None] * n
    done = []
    for j in order:
        est = max([F[p] for p in I.pred[j]] or [0])
        if d[j] == 0:
            S[j] = F[j] = est
            continue
        ts = sorted(set([est] + [F[i] for i in done if F[i] > est]))
        l, w, h = I.dim[j]
        for t in ts:
            e = t + d[j]
            ov = [i for i in done if S[i] < e and t < F[i]]
            pts = [t] + [S[i] for i in ov if S[i] > t]
            ok = True
            for tau in pts:
                for k in range(I.K):
                    if I.r[j][k] and I.r[j][k] + sum(I.r[i][k] for i in ov if S[i] <= tau < F[i]) > I.R[k]:
                        ok = False
                        break
                if not ok:
                    break
            if not ok:
                continue
            pos = None
            if I.vol[j] > 0:
                boxes = [(P[i][0], P[i][1], P[i][2]) + tuple(I.dim[i]) for i in ov if P[i] is not None]
                if Pcp is not None:
                    pos = tuple(Pcp[j]) if sd.fits(Pcp[j][0], Pcp[j][1], Pcp[j][2], l, w, h, boxes,
                                                   I.L, I.W, I.H) else None
                else:
                    pos = sd.find_pos_complete(l, w, h, boxes, I.L, I.W, I.H)
                if pos is None:
                    continue
            S[j], F[j], P[j] = t, e, pos
            done.append(j)
            break
        if S[j] is None:
            raise RuntimeError('serial: %d 排不下' % j)
    viol = sum(sd.check(I, S, F, P, space=True).values())
    return max(F), viol


def run_one(task):
    s_, nm, f = task
    with open(os.path.join(C.CACHE, nm + '.pkl'), 'rb') as fh:
        cp = pickle.load(fh)
    I = sd.load_instance(f)
    r = {'set': s_, 'cp': cp['ms'], 'cp_status': cp['status']}
    for mode in ('full', 'cand'):
        ms, dec, inc, v = replay(I, cp['S'], mode)
        r[mode], r[mode + '_dec'], r[mode + '_in'], r[mode + '_viol'] = ms, dec, inc, v
    r['ser_s4'], r['ser_s4_viol'] = serial(I, cp['S'])
    r['ser_cp'], r['ser_cp_viol'] = serial(I, cp['S'], cp['P'])
    with open(os.path.join(PCACHE, nm + '.pkl'), 'wb') as fh:
        pickle.dump(r, fh)


def run_part(part, budget):
    import train_dqn as T
    os.makedirs(PCACHE, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    have = set()
    for f in glob.glob(os.path.join(PCACHE, '*.pkl')):
        with open(f, 'rb') as fh:
            if 'ser_s4' in pickle.load(fh):
                have.add(os.path.splitext(os.path.basename(f))[0])
    cpd = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(C.CACHE, '*.pkl')))
    tasks = [t for t in T.list_instances()['test'] if t[1] in cpd and t[1] not in have][k::n]
    t0 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t0 > budget:
            break
        run_one(t)
        done += 1
    print('probe %s: 本次 %d，剩 %d，%.0fs' % (part, done, len(tasks) - done, time.time() - t0), flush=True)


def merge():
    base = C.load_base()
    rows = {}
    for f in glob.glob(os.path.join(PCACHE, '*.pkl')):
        nm = os.path.splitext(os.path.basename(f))[0]
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        b = base[nm]
        r.update({'LB': float(b['LB']), 'LFT': float(b['LFT']), 'act': float(b['act']), 'pilot': float(b['pilot'])})
        rows[nm] = r
    names = sorted(rows)
    cols = ['LFT', 'pilot', 'act', 'cand', 'full', 'ser_s4', 'ser_cp', 'cp']
    lab = {'cand': 'CP回放(候选内)', 'full': 'CP回放(全部)', 'ser_s4': '串行+S4', 'ser_cp': '串行+CP位置',
           'cp': 'CP-SAT'}
    L = ['CP-SAT 可学性探针 —— 测试集 %d 例（有 CP-SAT 解的）' % len(names),
         'CP回放(全部) = 在逐道开工+S4 框架里，按 CP-SAT 开工先后开工 → 学 CP-SAT 的天花板',
         'CP回放(候选内) = 只能在 act-pilot 的候选里选，按 CP-SAT 先后 → 不改动作空间时完美模仿 CP 的天花板',
         '串行+S4 = 按 CP-SAT 先后逐道排到最早可行时刻（允许等待、插空），位置用 S4 现找',
         '串行+CP位置 = 同上但位置用 CP-SAT 的（自检：应与 CP-SAT 一致或更短）', '',
         '一、相对 LFT 的平均缩短（逐例 (LFT−方法)/LFT），越大越好']
    L.append('%-6s' % '集合' + ''.join('%16s' % lab.get(c, c) for c in cols[1:]))
    for s_ in SETS + ['ALL']:
        sel = [n for n in names if s_ == 'ALL' or rows[n]['set'] == s_]
        if sel:
            L.append('%-6s' % s_ + ''.join('%15.2f%%' % (100 * np.mean([(rows[n]['LFT'] - rows[n][c]) / rows[n]['LFT']
                                                                          for n in sel])) for c in cols[1:]))
    L += ['', '二、回放对 act-pilot：平均缩短、更好/持平/更差；CP 首选落在 act-pilot 候选里的比例']
    for s_ in SETS + ['ALL']:
        sel = [n for n in names if s_ == 'ALL' or rows[n]['set'] == s_]
        if not sel:
            continue
        line = '%-6s' % s_
        for c in ('full', 'cand'):
            x = np.array([(rows[n]['act'] - rows[n][c]) / rows[n]['act'] for n in sel])
            line += '  %s %6.2f%% (%d/%d/%d)' % (lab[c], 100 * x.mean(), (x > 1e-9).sum(), (abs(x) <= 1e-9).sum(),
                                               (x < -1e-9).sum())
        inr = sum(rows[n]['full_in'] for n in sel) / float(max(1, sum(rows[n]['full_dec'] for n in sel)))
        line += '  候选覆盖 %.1f%%' % (100 * inr)
        L.append(line)
    g = np.array([(rows[n]['full'] - rows[n]['cp']) / rows[n]['cp'] for n in names])
    L += ['', '三、框架损失：CP回放(全部) 比 CP-SAT 本身长 %.2f%%；回放恰好等于 CP-SAT 的 %d / %d 例' % (
        100 * g.mean(), int((g <= 1e-9).sum()), len(names)),
          '   违约数：%d' % sum(rows[n]['full_viol'] + rows[n]['cand_viol'] + rows[n]['ser_s4_viol'] +
                             rows[n]['ser_cp_viol'] for n in names)]
    for c in ('ser_s4', 'ser_cp'):
        g = np.array([(rows[n][c] - rows[n]['cp']) / rows[n]['cp'] for n in names])
        L.append('   %s 比 CP-SAT 长 %.2f%%；等于或更短 %d / %d 例' % (lab[c], 100 * g.mean(), int((g <= 1e-9).sum()),
                                                            len(names)))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(C.OUT, '可学性探针.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.part, a.budget)
    if a.merge:
        merge()
