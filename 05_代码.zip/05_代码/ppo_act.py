# -*- coding: utf-8 -*-
"""
ppo_act.py —— 3.9 先模仿、再强化：以 3.8 模仿 act-pilot 得到的选工序网络为起点，用 PPO 微调。

策略：同 act_net —— 每次逐道决策，网络给候选工序打分，softmax 后按概率抽一道开工（位置仍由 S4 找，始终可行）。
奖励：整局 −工期/CPM（等于每步 −Δt/CPM 之和，与 rl_env 的逐步奖励一致）。
优势：同一算例采样 K 条轨迹，优势 = (这 K 条的平均工期 − 本条工期)/CPM，再在整批上标准化。
      用“同组平均”当基线，不另训价值网络（POMO / GRPO 的做法；工期只在整局结束才知道，价值网络很难学准）。
更新：PPO 截断目标（ratio 截在 [1−ε, 1+ε]）+ 小的熵奖励 + 对模仿网络的 KL 约束（防止忘掉老师）。
      每轮：B 个训练算例 × K 条轨迹 → 若干遍小批量更新。每 VAL_EVERY 轮在验证集半集上只用网络（贪心）评估，保留最好参数。
采样在多进程 CPU 上做，更新在 GPU 上做。

用法：python3 ppo_act.py --iters 150 --workers 12 [--inst 16 --k 8]
      之后 python3 act_net.py --eval-pool --tag ppo 测试，python3 act_net.py --merge 汇总
"""
import os
import sys
import io
import time
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import graph_feats as GF
import act_net as N
from progress import Bar

PPO_CKPT = N.ckpt_of('ppo')
VAL_EVERY = 5


# ----------------------------------------------------------------------------------------------
# 采样（子进程，CPU）
# ----------------------------------------------------------------------------------------------
def policy_run(model, I, rng=None, static=None):
    """rng 为 None：贪心；否则按 softmax 概率抽样。返回 (工期, 决策记录, 违约数)"""
    torch = N.T_()
    env = rl_env.Env(I)
    if static is not None:
        env._g = static
    env.reset()
    sc = N.Scorer(model, env, torch.device('cpu'))
    rec = []
    while not env.done:
        while True:
            ok = N.feasible(env)
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = N.candidates(env, ok)
            if len(cand) == 1:
                j = cand[0]
            else:
                D = GF.dyn_feats(env)
                G = env.obs().astype(np.float32)
                s = sc.score(D, G, ok, cand).astype(np.float64)
                p = np.exp(s - s.max())
                p /= p.sum()
                a = int(np.argmax(p)) if rng is None else int(rng.choice(len(cand), p=p))
                if rng is not None:
                    rec.append({'D': D.astype(np.float16), 'G': G, 'ok': np.array(sorted(ok), dtype=np.int16),
                                'cand': np.array(cand, dtype=np.int16), 'a': a, 'logp': float(np.log(p[a] + 1e-12))})
                j = cand[a]
            env._start(j, ok[j])
        env._advance()
        env._to_decision(rl_env.ACTIONS[N.LFT])
    viol = 0
    if rng is None:
        viol = sum(sd.check(I, env.S, env.F, env.P, space=True).values())
    return env.makespan(), rec, viol


_m, _ver, _inst = None, None, {}


def _winit(cfg):
    global _m
    torch = N.T_()
    torch.set_num_threads(1)
    _m = N.build_model(cfg['h'], cfg['layers'], cfg.get('dropout', 0.1))
    _m.eval()


def _get(f):
    if f not in _inst:
        I = sd.load_instance(f)
        _inst[f] = (I, GF.static_graph(rl_env.Env(I)))
    return _inst[f]


def _work(task):
    global _ver
    torch = N.T_()
    ver, blob, mode, name, f, K, seed = task
    if _ver != ver:
        _m.load_state_dict(torch.load(io.BytesIO(blob), map_location='cpu', weights_only=False))
        _ver = ver
    I, st = _get(f)
    if mode == 'greedy':
        ms, _, viol = policy_run(_m, I, None, st)
        return name, I.cpm, ms, viol
    rng = np.random.default_rng(seed)
    return name, I.cpm, [policy_run(_m, I, rng, st)[:2] for _ in range(K)]


# ----------------------------------------------------------------------------------------------
# 主进程：PPO 更新（GPU）
# ----------------------------------------------------------------------------------------------
def run(iters, workers, n_inst=16, K=8, lr=1e-4, clip=0.2, ent=0.01, kl=0.05, epochs=3, batch=256, seed=0):
    from multiprocessing import Pool
    torch = N.T_()
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('设备:', dev, torch.cuda.get_device_name(0) if dev.type == 'cuda' else '', flush=True)
    if os.path.exists(PPO_CKPT):
        st = torch.load(PPO_CKPT, map_location='cpu', weights_only=False)
        print('从 PPO 第 %d 轮续训' % st['iter'], flush=True)
    else:
        bc = torch.load(N.CKPT, map_location='cpu', weights_only=False)
        st = {'cfg': bc['cfg'], 'model': bc['best'], 'best': bc['best'], 'best_val': None, 'iter': 0,
              'curve': [], 'opt': None, 'bc_val': bc['best_val']}
        print('从 3.8 模仿网络出发（其验证值 %.4f）' % bc['best_val'], flush=True)
    cfg = st['cfg']
    model = N.build_model(cfg['h'], cfg['layers'], 0.0).to(dev)        # 微调时关掉 dropout，保证 ratio 准确
    model.load_state_dict(st['model'])
    ref = N.build_model(cfg['h'], cfg['layers'], 0.0).to(dev)          # 模仿网络，作 KL 约束
    ref.load_state_dict(torch.load(N.CKPT, map_location='cpu', weights_only=False)['best'])
    ref.eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    if st['opt'] is not None:
        opt.load_state_dict(st['opt'])
    inst = N.list_instances()
    train = inst['train']
    val = inst['val'][::2]
    statics = {}

    def static_of(f):
        if f not in statics:
            statics[f] = GF.static_graph(rl_env.Env(sd.load_instance(f)))
        return statics[f]

    def blob():
        b = io.BytesIO()
        torch.save({k: v.detach().cpu() for k, v in model.state_dict().items()}, b)
        return b.getvalue()

    def validate(pool, ver, bb):
        res = pool.map(_work, [(ver, bb, 'greedy', nm, f, 0, 0) for s, nm, f in val])
        return float(np.mean([ms / float(c) for _, c, ms, _ in res])), sum(v for *_, v in res)

    rng = np.random.default_rng(seed + st['iter'])
    t00 = time.time()
    with Pool(workers, initializer=_winit, initargs=(cfg,)) as pool:
        if st['best_val'] is None:
            v, viol = validate(pool, -1, blob())
            st['best_val'] = v
            st['curve'].append((0, float('nan'), v))
            print('起点验证 ms/CPM %.4f（违约 %d）' % (v, viol), flush=True)
        bar = Bar('ppo', iters, st['iter'])
        bar.update(st['iter'], 'best %.4f' % st['best_val'])
        while st['iter'] < iters:
            t0 = time.time()
            ver = st['iter']
            bb = blob()
            pick = rng.choice(len(train), n_inst, replace=False)
            tasks = [(ver, bb, 'sample', train[i][1], train[i][2], K, int(rng.integers(1 << 30))) for i in pick]
            out = pool.map(_work, tasks)
            # 组织样本
            S, adv, ms_all = [], [], []
            for (name, cpm, trajs), i in zip(out, pick):
                f = train[i][2]
                mss = np.array([m for m, _ in trajs], dtype=np.float64)
                ms_all += list(mss / cpm)
                base = mss.mean()
                for m, rec in trajs:
                    A = (base - m) / cpm
                    for x in rec:
                        S.append((f, x))
                        adv.append(A)
            adv = np.array(adv, dtype=np.float32)
            if adv.std() > 1e-8:
                adv = adv / (adv.std() + 1e-8)
            ts = time.time() - t0
            # PPO 更新
            model.train()
            stats = []
            idx = np.arange(len(S))
            for _ in range(epochs):
                rng.shuffle(idx)
                for p0 in range(0, len(idx), batch):
                    bi = idx[p0:p0 + batch]
                    its = []
                    for k in bi:
                        f, x = S[k]
                        Xs, E = static_of(f)
                        its.append((Xs, E, x['D'], x['G'], x['ok'], x['cand']))
                    inp = N.collate(its, dev)
                    lp = torch.log_softmax(model(*inp), 1)
                    with torch.no_grad():
                        lr_ = torch.log_softmax(ref(*inp), 1)
                    a = torch.tensor([S[k][1]['a'] for k in bi], device=dev)
                    old = torch.tensor([S[k][1]['logp'] for k in bi], device=dev, dtype=torch.float32)
                    A_ = torch.from_numpy(adv[bi]).to(dev)
                    new = lp.gather(1, a[:, None]).squeeze(1)
                    ratio = torch.exp(new - old)
                    pg = -torch.min(ratio * A_, torch.clamp(ratio, 1 - clip, 1 + clip) * A_).mean()
                    pr = torch.exp(lp)
                    valid = inp[-1]
                    lpz = torch.where(valid, lp, torch.zeros_like(lp))
                    entropy = -(pr * lpz).sum(1).mean()
                    lrz = torch.where(valid, lr_, torch.zeros_like(lr_))
                    kld = (pr * (lpz - lrz)).sum(1).mean()
                    loss = pg - ent * entropy + kl * kld
                    opt.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    opt.step()
                    stats.append((pg.item(), entropy.item(), kld.item(),
                                  ((ratio - 1).abs() > clip).float().mean().item()))
            st['iter'] += 1
            v = None
            msg = ''
            if st['iter'] % VAL_EVERY == 0 or st['iter'] == iters:
                v, viol = validate(pool, st['iter'] + 10 ** 6, blob())
                if v < st['best_val']:
                    st['best_val'] = v
                    st['best'] = {k: x.detach().cpu().clone() for k, x in model.state_dict().items()}
                msg = '  验证 %.4f（best %.4f，违约 %d）' % (v, st['best_val'], viol)
            st['curve'].append((st['iter'], float(np.mean(ms_all)), v))
            st['model'] = {k: x.detach().cpu().clone() for k, x in model.state_dict().items()}
            st['opt'] = opt.state_dict()
            torch.save(st, PPO_CKPT + '.tmp')
            os.replace(PPO_CKPT + '.tmp', PPO_CKPT)
            s_ = np.mean(stats, 0)
            print('iter %3d/%d  样本 %5d  采样平均 ms/CPM %.4f  pg %.3f  熵 %.3f  KL %.4f  截断 %.0f%%  '
                  '采样 %.0fs 更新 %.0fs%s' % (st['iter'], iters, len(S), np.mean(ms_all), s_[0], s_[1], s_[2],
                                             100 * s_[3], ts, time.time() - t0 - ts, msg), flush=True)
            bar.update(st['iter'], 'best %.4f' % st['best_val'])
        bar.done('best %.4f' % st['best_val'])
    print('PPO 完成，最优验证 %.4f（模仿网络 %.4f），总用时 %.1f 分钟' % (
        st['best_val'], st.get('bc_val', float('nan')), (time.time() - t00) / 60), flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--iters', type=int, default=150)
    ap.add_argument('--workers', type=int, default=12)
    ap.add_argument('--inst', type=int, default=16)
    ap.add_argument('--k', type=int, default=8)
    ap.add_argument('--lr', type=float, default=1e-4)
    ap.add_argument('--kl', type=float, default=0.05)
    a = ap.parse_args()
    run(a.iters, a.workers, a.inst, a.k, a.lr, kl=a.kl)
