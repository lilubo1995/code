# -*- coding: utf-8 -*-
"""audit_test1_seg.py —— 按“分段”核查 test1.py：它每个决策点重置放置点并重新放置所有在执行的活动，
所以一个活动可能在执行中途被“搬家”。这里记录每次 append 的 (开始, 位置)，还原真实执行过程。"""
import os, sys, io, csv, contextlib, multiprocessing as mp
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import sched3d, audit_test1 as A
OUT = os.path.join(sched3d.OUT_ROOT, 'test1核查')
MARK = '        # ===== 结尾：按 activity_id 去重后打印 32 个活动 ====='
HOOK = '        for _a in scheduleList: print("#SEG", _a.activity_id, _a.start_time, getattr(_a,"f_time",_a.start_time), *tuple(_a.pos))'

def run_one(path):
    A._stub_modules()
    src = open(A.TEST1, encoding='utf-8', errors='replace').read()
    src = src[:src.find('\nlist_xlsx=[]')]
    assert MARK in src
    ns = {'__name__': 'x'}; exec(compile(src.replace(MARK, HOOK), A.TEST1, 'exec'), ns)
    ns['list_xlsx'] = [['a']]
    b = io.StringIO()
    with contextlib.redirect_stdout(b): ns['zz'](path)
    seg = [tuple(map(int, l.split()[1:])) for l in b.getvalue().splitlines() if l.startswith('#SEG')]
    I = sched3d.load_instance(path)
    by = {}
    for aid, s, f, x, y, z in seg: by.setdefault(aid, []).append((s, f, (x, y, z)))
    S = [None]*I.n; F = [None]*I.n; P = [None]*I.n
    pieces = []          # (j, t0, t1, pos) 实际占用的分段
    moved = 0; dur_bad = 0; fin_change = 0
    for j, lst in by.items():
        lst.sort(key=lambda r: r[0])
        S[j] = lst[0][0]; F[j] = lst[-1][1]; P[j] = lst[0][2]
        if len(set(r[1] for r in lst)) > 1: fin_change += 1
        if F[j] - S[j] != I.d[j]: dur_bad += 1
        if I.d[j] > 0 and len(set(r[2] for r in lst)) > 1: moved += 1
        for k, (s, f, p) in enumerate(lst):
            t1 = lst[k+1][0] if k+1 < len(lst) else F[j]
            if t1 > s and I.d[j] > 0: pieces.append((j, s, t1, p))
    ov = 0; bound = 0
    for a in range(len(pieces)):
        j, s, e, p = pieces[a]; l, w, h = I.dim[j]
        if p[0]+l > I.L or p[1]+w > I.W or p[2]+h > I.H: bound += 1
        for b2 in range(a+1, len(pieces)):
            k, s2, e2, q = pieces[b2]
            if k == j or not (s < e2 and s2 < e): continue
            l2, w2, h2 = I.dim[k]
            if p[0] < q[0]+l2 and q[0] < p[0]+l and p[1] < q[1]+w2 and q[1] < p[1]+w and p[2] < q[2]+h2 and q[2] < p[2]+h:
                ov += 1
    v = sched3d.check(I, S, F, P, space=False)   # 时间/资源/紧前按真实首次开工检查
    real = sum(1 for j in range(I.n) if I.d[j] > 0)
    return dict(instance=I.name, makespan=max(F[j] for j in range(I.n) if F[j] is not None),
                acts_moved=moved, real_acts=real, seg_overlap=ov, seg_bound=bound,
                dur_bad=dur_bad, prec=v['prec'], res=v['res'], missing=v['missing'])

def main():
    D = os.path.join(sched3d.DATA_DIR, 'j30_integer')
    files = sorted(f for f in os.listdir(D) if f.endswith('.sm'))
    with mp.Pool(max(1, mp.cpu_count())) as pool:
        rows = pool.map(run_one, [os.path.join(D, f) for f in files])
    old = {r['instance']: r for r in csv.DictReader(open(os.path.join(OUT, 'test1核查.csv'), encoding='utf-8-sig'))}
    keys = list(rows[0].keys()) + ['opt', 'mai_S4']
    with open(os.path.join(OUT, 'test1分段核查.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f); w.writerow(keys)
        for r in rows:
            r['opt'] = old.get(r['instance'], {}).get('opt', ''); r['mai_S4'] = old.get(r['instance'], {}).get('mai_S4', '')
            w.writerow([r[k] for k in keys])
    n = len(rows); m = lambda k: sum(r[k] for r in rows)
    c = lambda k: sum(r[k] > 0 for r in rows)
    L = ['test1.py 分段核查（还原每次重新放置，j30 共 %d 例）' % n, '=' * 70,
         '执行中途被搬动位置的活动：涉及 %d 例，合计 %d 个活动（占真实活动 %.1f%%）' % (c('acts_moved'), m('acts_moved'), 100.0*m('acts_moved')/m('real_acts')),
         '按分段看同一时刻三维重叠：涉及 %d 例，合计 %d 对' % (c('seg_overlap'), m('seg_overlap')),
         '越界分段：%d；首次开工到完工≠工期：%d 个活动；紧前违约 %d；资源超限 %d；缺失 %d'
         % (m('seg_bound'), m('dur_bad'), m('prec'), m('res'), m('missing')),
         '可行（不搬动且不重叠）的算例：%d / %d' % (sum(r['acts_moved'] == 0 and r['seg_overlap'] == 0 for r in rows), n),
         '', '结论：test1 的时间与资源部分是对的；空间部分每个决策点把放置点重置为 (0,0,0)，',
         '重新给所有在执行的活动找位置，相当于施工中途把工位搬走，这与“执行期间位置固定”的模型不符；',
         '原先 核查报告.txt 里的“工期被改动”是只看最后一段造成的假象，真实问题是位置搬动。']
    open(os.path.join(OUT, '分段核查报告.txt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('\n'.join(L))

if __name__ == '__main__':
    main()
