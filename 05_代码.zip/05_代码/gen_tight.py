# -*- coding: utf-8 -*-
"""gen_tight.py —— 生成“紧空间”变体算例。
R-instances 的场地很空（峰值并发体积只占 2% 左右），空间约束几乎不起作用。
这里保持工期、资源、紧前关系完全不变（所以 PSPLIB 的普通 RCPSP 参考值仍是合法的放松下界），
只重设空间：场地 S×S×S，每个真实活动的箱体三边各在 1..U 内随机取整（种子 = crc32(算例名)，可复现）。
这是本项目自建的变体，思路类似论文的 S-instances，但不是论文原数据。
用法: python gen_tight.py 5 6   -> 03_算例/紧空间_U5S6/j30_integer/...
"""
import os, sys, random, zlib
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import sched3d as sd


def make(U, S, suffix='.sm'):
    """suffix='_8.sm' 时只生成各参数组第 8 个算例（敏感性实验用的测试集）"""
    tag = 'U%dS%d' % (U, S)
    root = os.path.join(sd.DATA_DIR, '紧空间_' + tag)
    cnt = 0
    for s in sd.SETS:
        src = os.path.join(sd.DATA_DIR, s + '_integer')
        dst = os.path.join(root, s + '_integer'); os.makedirs(dst, exist_ok=True)
        for fn in sorted(os.listdir(src)):
            if not fn.endswith(suffix):
                continue
            I = sd.load_instance(os.path.join(src, fn))
            dpath = os.path.join(dst, fn)
            if os.path.exists(dpath):            # 断点续跑：已生成且校验通过的跳过
                try:
                    J = sd.load_instance(dpath)
                    if (J.L, J.W, J.H) == (S, S, S) and J.d == I.d and J.succ == I.succ:
                        cnt += 1
                        continue
                except Exception:
                    pass
            rnd = random.Random(zlib.crc32(I.name.encode()))
            dims = [(0, 0, 0) if I.d[j] == 0 else tuple(rnd.randint(1, U) for _ in range(3)) for j in range(I.n)]
            lines = open(os.path.join(src, fn), encoding='utf-8', errors='replace').read().splitlines()
            low = [x.strip().lower() for x in lines]
            i0 = low.index('space'); m0 = low.index('maxspace')
            out = lines[:i0 + 1] + ['%d %d %d %d %d' % (j + 1, a, b, c, a * b * c) for j, (a, b, c) in enumerate(dims)]
            out += lines[i0 + 1 + I.n:m0 + 1] + ['%d %d %d' % (S, S, S), '%d' % (S ** 3)]
            # maxspace 后原有两行数据，之后若还有内容（分隔线）原样保留
            out += lines[m0 + 3:]
            open(os.path.join(dst, fn), 'w', encoding='utf-8', newline='\n').write('\n'.join(out) + '\n')
            J = sd.load_instance(os.path.join(dst, fn))      # 回读校验
            assert J.dim == dims and (J.L, J.W, J.H) == (S, S, S) and J.d == I.d and J.r == I.r and J.succ == I.succ
            cnt += 1
    print('%s: %d 个算例写入 %s' % (tag, cnt, root))


if __name__ == '__main__':
    make(int(sys.argv[1]), int(sys.argv[2]), sys.argv[3] if len(sys.argv) > 3 else '.sm')
