# -*- coding: utf-8 -*-
"""ptload.py —— 不装 torch 也能读 PyTorch 保存的 .pt 检查点（zip 格式）。

.pt 文件是一个 zip：archive/data.pkl 是 pickle，里面的张量只记了“存储块编号 + 形状 + 步长”，
真正的数字放在 archive/data/<编号> 里。这里自己解 pickle：遇到张量就用 numpy 从对应文件拼出数组。
只放行检查点里会出现的少数几个类（白名单），其余一律拒绝，避免 pickle 执行任意代码。
"""
import io
import pickle
import zipfile
import collections
import numpy as np

_DTYPES = {
    'FloatStorage': np.float32, 'DoubleStorage': np.float64, 'HalfStorage': np.float16,
    'LongStorage': np.int64, 'IntStorage': np.int32, 'ShortStorage': np.int16,
    'CharStorage': np.int8, 'ByteStorage': np.uint8, 'BoolStorage': np.bool_,
}


class _StorageType(object):
    def __init__(self, name):
        self.dtype = _DTYPES[name]


def _rebuild_tensor_v2(storage, offset, size, stride, requires_grad=False, hooks=None, metadata=None):
    if len(size) == 0:
        return storage[offset].copy()
    it = storage.itemsize
    arr = np.lib.stride_tricks.as_strided(storage[offset:], shape=tuple(size),
                                          strides=tuple(s * it for s in stride))
    return np.array(arr)


def _rebuild_parameter(data, requires_grad=False, hooks=None):
    return data


def _numpy_attr(mod, name):
    import importlib
    for m in (mod, mod.replace('numpy._core', 'numpy.core'), mod.replace('numpy.core', 'numpy._core')):
        try:
            return getattr(importlib.import_module(m), name)
        except (ImportError, AttributeError):
            continue
    raise pickle.UnpicklingError('无法解析 %s.%s' % (mod, name))


class _Unpickler(pickle.Unpickler):
    def __init__(self, fh, zf, prefix):
        super().__init__(fh)
        self.zf, self.prefix = zf, prefix
        self.cache = {}

    def find_class(self, mod, name):
        if mod == 'collections' and name == 'OrderedDict':
            return collections.OrderedDict
        if mod == 'torch._utils' and name == '_rebuild_tensor_v2':
            return _rebuild_tensor_v2
        if mod == 'torch._utils' and name == '_rebuild_parameter':
            return _rebuild_parameter
        if mod == 'torch' and name in _DTYPES:
            return _StorageType(name)
        if mod == '_codecs' and name == 'encode':
            import codecs
            return codecs.encode
        if mod.startswith('numpy') and name in ('dtype', 'scalar', '_reconstruct', 'ndarray'):
            return _numpy_attr(mod, name)
        raise pickle.UnpicklingError('检查点里有不认识的对象：%s.%s' % (mod, name))

    def persistent_load(self, pid):
        # ('storage', 存储类型, 编号, 设备, 元素个数)
        kind, st, key, _loc, _numel = pid
        if kind != 'storage':
            raise pickle.UnpicklingError('未知持久化对象 %r' % (kind,))
        if key not in self.cache:
            raw = self.zf.read('%s/data/%s' % (self.prefix, key))
            self.cache[key] = np.frombuffer(raw, dtype=st.dtype)
        return self.cache[key]


def load(path):
    """返回检查点里的整个对象（字典），张量都变成 numpy 数组"""
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        pk = [x for x in names if x.endswith('/data.pkl')]
        if not pk:
            raise ValueError('不是 PyTorch zip 格式的检查点：%s' % path)
        prefix = pk[0][:-len('/data.pkl')]
        bo = '%s/byteorder' % prefix
        if bo in names and zf.read(bo).strip() not in (b'little', b''):
            raise ValueError('检查点是大端字节序，暂不支持')
        with zf.open(pk[0]) as fh:
            return _Unpickler(io.BytesIO(fh.read()), zf, prefix).load()
