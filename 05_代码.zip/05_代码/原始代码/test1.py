#! /usr/bin/python
# -*- coding: utf-8 -*-
import os
import random
import sys
import math
from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
import xlsxwriter
import time

def zz(filename):
    # 定义全局变量
    n = 32
    num_resources = 4
    pred_list = []
    succ_list = []
    duration = []
    res_req_list = []
    max_resources = []
    space_list = []
    maxspace_list = []
    volume1 = []
    # 生成空列表
    for i in range(0, n):
        pred_list.append([])
        succ_list.append([])
        res_req_list.append([])
        duration.append(0)
        space_list.append([])
        volume1.append([])

    # 设置图表刻度等格式
    def box(ax, x, y, z, dx, dy, dz, color='red'):
        xx = [x, x, x + dx, x + dx, x]
        yy = [y, y + dy, y + dy, y, y]
        kwargs = {'alpha': 1, 'color': color}
        ax.plot3D(xx, yy, [z] * 5, **kwargs)  # 下底
        ax.plot3D(xx, yy, [z + dz] * 5, **kwargs)  # 上底
        ax.plot3D([x, x], [y, y], [z, z + dz], **kwargs)
        ax.plot3D([x, x], [y + dy, y + dy], [z, z + dz], **kwargs)
        ax.plot3D([x + dx, x + dx], [y + dy, y + dy], [z, z + dz], **kwargs)
        ax.plot3D([x + dx, x + dx], [y, y], [z, z + dz], **kwargs)
        return ax


    # make_pic内置函数
    # 显示图形的函数：Items = [[num[0],num[1],num[3],num[3],num[4],num[5],num[6]],]
    def make_pic(Items):
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.xaxis.set_major_locator(MultipleLocator(1))
        ax.yaxis.set_major_locator(MultipleLocator(1))
        ax.zaxis.set_major_locator(MultipleLocator(1))
        for num in Items:
            box(ax, num[0], num[1], num[2], num[3], num[4], num[5], num[6])
        plt.title('maxspace_listube')
        plt.show()
        # print(plt.show())


    # 把尺寸数据生成绘图数据
    def make(O, maxspace_list , color):
        # print("数据1",O)
        # print("数据2",maxspace_list)
        data = [O[0], O[1], O[2], maxspace_list[0], maxspace_list[1], maxspace_list[2], color]
        # print(1)
        return data


    # 可用点的生成方法
    def newsite(O, space_list_i):
        # 在X轴方向上生成
        O1 = (O[0] + space_list_i[0], O[1], O[2])
        # 在Y轴方向上生成
        O2 = (O[0], O[1] + space_list_i[1], O[2])
        # 在Z轴方向上生成
        O3 = (O[0], O[1], O[2] + space_list_i[2])
        return [O1, O2, O3]




    # 定义活动的类
    class Activity:
        def __init__(self):
            self.activity_id = 0
            self.start_time = 0
            self.duration = 0
            self.f_time = 0
            self.pos = None      # ===== 新增：空间起点坐标 (x, y, z) =====
            self.space = None    # ===== 新增：占用尺寸 (dx, dy, dz) =====

    # 读文件
    def read_file(filename):
        f = open(filename, 'r')
        i = 0
        for line in f:
            i += 1
            if i in range(19, n + 19):
                numbers = list(map(int, line.split()))
                activity_id = numbers[0] - 1
                successors = numbers[2]
                # Updating successor list
                for x in numbers[3:]:
                    succ_list[activity_id].append(x - 1)
                # Updating predecessor list
                for x in numbers[3:]:
                    pred_list[x - 1].append(activity_id)
            # Updating duration and resource list
            if i in range(n + 19 + 4, n + 19 + 4 + n):
                numbers = list(map(int, line.split()))
                activity_id = numbers[0] - 1
                duration[activity_id] = numbers[2]
                for x in numbers[3:]:
                    res_req_list[activity_id].append(x)
            # Storing maximum resources available
            if i == 2 * n + 19 + 4 + 3:
                # global max_resources
                # max_resources = list(map(int, line.split()))
                max_resources.append(list(map(int, line.split()))[0])
                max_resources.append(list(map(int, line.split()))[1])
                max_resources.append(list(map(int, line.split()))[2])
                max_resources.append(list(map(int, line.split()))[3])
                # Storing space resources
            if i in range(2 * n + 19 + 4 + 3 + 3, 3 * n + 19 + 4 + 3 + 3):
                numbers = list(map(int, line.split()))
                activity_id = numbers[0] - 1
                for x in numbers[1:4]:
                    space_list[activity_id].append(x)
                    volume1[activity_id] = numbers[4]
            if i == 3 * n + 19 + 4 + 3 + 3 + 2:

                maxspace_list.append(list(map(int, line.split()))[0])
                maxspace_list.append(list(map(int, line.split()))[1])
                maxspace_list.append(list(map(int, line.split()))[2])
                #print("max",maxspace_list)
            if i == 3 * n + 19 + 4 + 3 + 3 + 3:
                global maxvolume
                maxvolume = list(map(int, line.split()))
        # print(activity_id)
        # print(succ_list)
        # print(duration)
        # print(res_req_list)
        # print(pred_list)
        # print(space_list)
        # print(volume1)
        # print(maxspace_list)
        # print(maxvolume)


    # 调度
    def execute_on_file(filename):
        scheduled = [False for x in range(0, n)]
        finished = [False for x in range(0, n)]
        scheduleList = []
        feasible_activities1 = []
        feasible_activities2 = []
        O_pop=[]
        scheduling = []
        scheduling1=[]
        c_time = {}
        c1_time={}
        s_time={}
        s1_time={}
        time = 0
        duration1={}
        a0 = Activity()
        a0.activity_id = 0
        a0.start_time = 0
        a0.duration = 0
        a0.pre_list=0
        a0.pos = (0, 0, 0)      # ===== 新增：虚拟起点坐标 =====
        a0.space = (0, 0, 0)    # ===== 新增：虚拟起点尺寸 =====


        # Adding the activity to the schedule list
        scheduleList.append(a0)
        scheduled[0] = True

        finished_activity = 0
        resources_left = max_resources
        completed_preds = [0 for x in range(n)]#完成的紧前活动列表


        def get_feasible_activities2(finished, scheduled, completed_preds):
            feasible_activities = []

            for x in range(0, n):
                if completed_preds[x] == len(pred_list[x]):
                    if not scheduled[x]:
                        feasible_activities.append(x)
            return feasible_activities


        while 1:

            if finished_activity != 0:
                if finished_activity in feasible_activities1:
                    feasible_activities1.remove(finished_activity)
                    for i in feasible_activities1:
                        if i not in scheduling1:
                            scheduling.append(i)
            if finished_activity in scheduling1:
                scheduling1.remove(finished_activity)

            if not finished[finished_activity]:
                resources_left = [x + y for x, y in zip(resources_left, res_req_list[finished_activity])]
                finished[finished_activity] = True
                for x in succ_list[finished_activity]:
                    completed_preds[x] = completed_preds[x] + 1


            feasible_activities = get_feasible_activities2(finished, scheduled, completed_preds)

            # def priority(activity_id):
            #     return duration[activity_id]
            def priority(activity_id):
                return activity_id

            feasible_activities = sorted(feasible_activities, key=priority, reverse=False)
            # def priority(activity_id):
            #     return volume1[activity_id]
            # #
            # feasible_activities = sorted(feasible_activities, key=priority, reverse=True)


            O = (0, 0, 0)
            O_items = [O]
            color = 'red'  # 箱体颜色
            #make_pic([make(O, color)])  # 这个为直接显示箱体看下效果
            show_num = [make(O,maxspace_list, color)]
            color2 = 'blue'
            #show_num.append(make(O, space_list[0], color2))
            #make_pic(show_num)

            for activity in feasible_activities:
                flag_new=0
                for x, y in zip(resources_left, res_req_list[activity]):
                    if x < y:
                        flag_new = 1
                if flag_new == 0:
                    if activity not in feasible_activities1:
                        feasible_activities1.append(activity)

                    resources_left = [w - z for w, z in zip(resources_left, res_req_list[activity])]

            #feasible_activities1 = sorted(feasible_activities1, key=priority, reverse=True)
            for activity in feasible_activities1:
                w1=feasible_activities1.index(activity)
                flag_new = 0
                if (O_items[w1][0] + space_list[activity][0] > maxspace_list[0] or O_items[w1][1] +
                    space_list[activity][1] > maxspace_list[1] or O_items[w1][2] + space_list[activity][2] >
                    maxspace_list[2]):
                    flag_new = 1  # Resource requirement not satisfied.
                if flag_new == 0:
                    a1 = Activity()
                    a1.activity_id = activity
                    a1.start_time = time

                    if activity in scheduling:
                        a1.duration=duration[activity]-(a1.start_time-c_time[a1.activity_id])
                        a1.f_time = a1.start_time + a1.duration
                        s_time[a1.activity_id] = a1.start_time
                        s1_time[a1.activity_id] = a1.f_time
                        duration1[a1.activity_id]=a1.duration
                        scheduling.remove(activity)
                        scheduling1.append(activity)

                    if activity in scheduling1:
                        a1.duration=duration1[a1.activity_id]-(a1.start_time-s_time[a1.activity_id])
                        a1.f_time=a1.start_time + a1.duration

                    else:
                        a1.duration = duration[activity]
                        a1.f_time = a1.start_time + a1.duration
                    c_time[a1.activity_id] = a1.start_time
                    c1_time[a1.activity_id] = a1.f_time
                    #print(c_time,c1_time)
                    a1.pos = O_items[w1]                    # ===== 新增：记录起点坐标 =====
                    a1.space = list(space_list[activity])   # ===== 新增：记录占用尺寸 =====
                    new_show = make(O_items[w1], space_list[activity], color)
                    if new_show not in show_num:
                        show_num.append(make(O_items[w1], space_list[activity], color2))
                    # 把堆叠后产生的新的点，加入放置点列表
                    for new_O in newsite(O_items[w1], space_list[activity]):
                        # 保证放入的可用点是不重复的
                        if new_O not in O_items:
                            O_items.append(new_O)
                    scheduleList.append(a1)
                    scheduled[activity] = True
                else:
                    O_pop.append(O_items.pop(w1))
                    # 当可用点一直不可用时
                    while O_items[w1][0] + space_list[activity][0] > maxspace_list[0] or \
                            O_items[w1][1] + space_list[activity][1] > maxspace_list[1] or \
                            O_items[w1][2] + space_list[activity][2] > maxspace_list[2]:
                        # 一直把可用点弹出弃用
                        O_pop.append(O_items.pop(w1))
                        # 如果弹出后货物次序超出剩余可用点，则认为无法继续放置
                        if feasible_activities1!=0:
                            if len(O_items) == w1:
                                #feasible_activities1.remove(activity)
                                for i in feasible_activities1[w1: ]:
                                    resources_left = [w + z for w, z in zip(resources_left, res_req_list[i])]
                                del feasible_activities1[w1:]
                                break
                    # if feasible_activities1 != 0:
                    #     if len(O_items) == w1:
                    #         break
                    # 货物次序应小于等于剩余可用点数量
                    if len(O_items) > w1:
                        if O_items[w1][0] + space_list[activity][0] <= maxspace_list[0] and \
                        O_items[w1][1] + space_list[activity][1] <= maxspace_list[1] and \
                        O_items[w1][2] + space_list[activity][2] <= maxspace_list[2]:
                            # 如果不再超出限制，在这个可用点上堆叠
                            new_show = make(O_items[w1], space_list[activity], color)
                            if new_show not in show_num:
                                show_num.append(make(O_items[w1], space_list[activity], color))
                            # 把堆叠后产生的新的点，加入放置点列表
                            for new_O in newsite(O_items[w1], space_list[activity]):
                                # 保证放入的可用点是不重复的
                                if new_O not in O_items:
                                    O_items.append(new_O)
                            a1 = Activity()
                            a1.activity_id = activity
                            a1.start_time = time
                            if activity in scheduling:
                                a1.duration = duration[activity] - (a1.start_time - c_time[a1.activity_id])
                                a1.f_time = a1.start_time + a1.duration
                                s_time[a1.activity_id] = a1.start_time
                                s1_time[a1.activity_id] = a1.f_time
                                duration1[a1.activity_id] = a1.duration
                                scheduling.remove(activity)
                                scheduling1.append(activity)

                            if activity in scheduling1:
                                a1.duration = duration1[a1.activity_id] - (a1.start_time - s_time[a1.activity_id])
                                a1.f_time = a1.start_time + a1.duration

                            else:
                                a1.duration = duration[activity]
                            a1.f_time = a1.start_time + a1.duration
                            c_time[a1.activity_id] = a1.start_time
                            c1_time[a1.activity_id] = a1.f_time
                            a1.pos = O_items[w1]                    # ===== 新增：记录起点坐标 =====
                            a1.space = list(space_list[activity])   # ===== 新增：记录占用尺寸 =====
                            scheduleList.append(a1)
                            scheduled[activity] = True
                            if activity not in feasible_activities2:
                                feasible_activities2.append(activity)

            # make_pic(show_num)
            def finishTime(a):
                if not finished[a.activity_id]:
                    return a.f_time
                return sys.maxsize

            activity_with_min_finish_time = min(scheduleList, key=finishTime)
            finish_time = activity_with_min_finish_time.f_time
            if finish_time != sys.maxsize and finished_activity != activity_with_min_finish_time:
                time=finish_time
                finished_activity = activity_with_min_finish_time.activity_id
            if len(c_time) == n-1:
                break
            # if len(feasible_activities1) == 0:
            #     break

        # ===== 结尾：按 activity_id 去重后打印 32 个活动 =====
        time = 0
        final = {}
        for activity in scheduleList:
            final[activity.activity_id] = activity   # 后出现的覆盖先出现的
            time = max(time, activity.f_time)

        print("=" * 90)
        print("活动ID\t开始时间\t结束时间\t工期\t起点坐标(x,y,z)\t\t占用尺寸(dx,dy,dz)")
        print("-" * 90)
        for aid in sorted(final.keys()):
            a = final[aid]
            pos = a.pos if a.pos is not None else (None, None, None)
            sp  = a.space if a.space is not None else (None, None, None)
            print(f"{aid}\t{a.start_time}\t\t{a.f_time}\t\t{a.f_time - a.start_time}\t"
                  f"({pos[0]}, {pos[1]}, {pos[2]})\t\t({sp[0]}, {sp[1]}, {sp[2]})")
        print("=" * 90)

        real_ids = [k for k in final.keys() if k != 0]
        print(f"真实活动数（不含0号虚拟起点）: {len(real_ids)}")
        print(f"调度记录总条数（含重复append）: {len(scheduleList)}")
        print(f"去重后活动数（含0号）: {len(final)}")

        list_xlsx[-1].append(time)
        print("Total time: ", time)
        # ===== 打印结束 =====

    read_file(filename)
    execute_on_file(filename)

list_xlsx=[]
psplib=input("请输入算例文件夹名称")
def file_name(file_dir):
    for root, dirs, files in os.walk(file_dir):
        pass
    return files

# if __name__ == '__main__':
kkk = file_name(os.getcwd() + "\\" + psplib)
print(kkk)
kkk.sort(key=lambda i:(int(i[1:-3:].replace("_","").replace("10","9")),len(i)))
jj=1


for i in kkk:
    list_xlsx.append([])
    print(f"第{jj}个算例")
    print(psplib+"\\"+i)
    list_xlsx[-1].append(i)
    t_start = time.time()
    zz(psplib+"\\"+i)
    t_end = time.time()
    t_computation = t_end - t_start
    list_xlsx[-1].append(t_computation)
    print("t_computation = " + str(t_computation))
    jj+=1

print(list_xlsx)

wk = xlsxwriter.Workbook("result.xlsx")  # 新建一个空的excel
ws = wk.add_worksheet("sheet")  # 新建一个sheet
ws.write_row(0, 0, ["算例名称", "工期", "运行时间"])  # 从左上角开始写
j = 1  # 用来计数的
for i in list_xlsx:  # 要写进去的内容
    ws.write_row(j, 0, i)  # write_row(行,列,要写进去的列表)
    j = j + 1
wk.close()
print("完成")