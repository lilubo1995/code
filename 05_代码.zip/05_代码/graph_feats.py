# -*- coding: utf-8 -*-
"""
graph_feats.py —— 时空结构图的节点特征与边（不依赖 torch，多进程打标签时子进程不必加载 torch）。
gnn_rule.py（选规则的图网络）和 act_net.py（选工序的图网络）共用。

节点 = 工序。静态特征 27 维：工期、4 类资源占比、箱体长宽高与体积、关键路径时间参数、后继/紧前数、
         是否虚工序、10 条候选规则下的优先名次。
动态特征 11 维：已完工/执行中/可开工/未就绪、此刻资源是否够、剩余工期、距最晚开始/完成的余量、执行中工序的箱体坐标。
边 4 类：紧前→紧后、紧后→紧前、空间不相容（三个轴上都无法并排放下）、资源不相容（某类资源需求之和超过容量）。
"""
import numpy as np
import rl_env

NA = len(rl_env.ACTIONS)
F_STATIC = 1 + 4 + 4 + 4 + 3 + 1 + NA      # 27
F_DYN = 11
N_ETYPE = 4


def static_graph(env):
    """每个算例只算一次：静态节点特征 + 4 类边"""
    I = env.I
    n, K = I.n, I.K
    if hasattr(env, '_g'):
        return env._g
    ES, LS, LF, TF = I.pv['EST'], I.pv['LST'], I.pv['LFT'], I.pv['TF']
    c = env.cpm
    X = np.zeros((n, F_STATIC), dtype=np.float32)
    for j in range(n):
        l, w, h = I.dim[j]
        X[j, 0] = I.d[j] / env.maxd
        for k in range(min(K, 4)):
            X[j, 1 + k] = I.r[j][k] / float(I.R[k]) if I.R[k] > 0 else 0
        X[j, 5:9] = [l / float(I.L), w / float(I.W), h / float(I.H), I.vol[j] / env.maxvol]
        X[j, 9:13] = [ES[j] / c, LS[j] / c, LF[j] / c, TF[j] / env.maxtf]
        X[j, 13:16] = [I.pv['MTS'][j] / float(n), len(I.succ[j]) / 3.0, len(I.pred[j]) / 3.0]
        X[j, 16] = 1.0 if I.d[j] == 0 else 0.0
    for a, rule in enumerate(rl_env.ACTIONS):
        order = sorted(range(n), key=lambda j: env.keys[rule][j])
        for rk, j in enumerate(order):
            X[j, 17 + a] = rk / float(n - 1)
    # 可达关系（有紧前/紧后路径的两道工序永远不会同时执行，不连空间/资源边）
    reach = [0] * n
    for j in reversed(I.topo):
        m = 0
        for s in I.succ[j]:
            m |= (1 << s) | reach[s]
        reach[j] = m
    real = [j for j in range(n) if I.d[j] > 0]
    sp, rs = [], []
    for ai in range(len(real)):
        i = real[ai]
        li, wi, hi = I.dim[i]
        for bj in range(ai + 1, len(real)):
            j = real[bj]
            if (reach[i] >> j) & 1 or (reach[j] >> i) & 1:
                continue
            lj, wj, hj = I.dim[j]
            if li + lj > I.L and wi + wj > I.W and hi + hj > I.H:
                sp += [(i, j), (j, i)]
            if any(I.r[i][k] + I.r[j][k] > I.R[k] for k in range(K)):
                rs += [(i, j), (j, i)]
    fw = [(i, s) for i in range(n) for s in I.succ[i]]
    bw = [(s, i) for i, s in fw]
    E = [np.array(e, dtype=np.int64).reshape(-1, 2) for e in (fw, bw, sp, rs)]
    env._g = (X, E)
    return env._g


def dyn_feats(env):
    """当前决策时刻的动态节点特征"""
    I = env.I
    n = I.n
    t = env.t
    c = env.cpm
    D = np.zeros((n, F_DYN), dtype=np.float32)
    act = set(env.active)
    LS, LF = I.pv['LST'], I.pv['LFT']
    for j in range(n):
        if j in act:
            D[j, 1] = 1
            D[j, 5] = (env.F[j] - t) / env.maxd
            p = env.P[j]
            if p is not None:
                D[j, 8:11] = [p[0] / float(I.L), p[1] / float(I.W), p[2] / float(I.H)]
        elif env.S[j] is not None:
            D[j, 0] = 1
        elif j in env.elig:
            D[j, 2] = 1
            D[j, 4] = 1.0 if env._res_ok(j) else 0.0
        else:
            D[j, 3] = 1
        D[j, 6] = (LS[j] - t) / c
        D[j, 7] = (LF[j] - t) / c
    return D
