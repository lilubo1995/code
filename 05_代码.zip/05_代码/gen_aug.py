# -*- coding: utf-8 -*-
"""
gen_aug.py —— 1.6 扩充训练算例：给训练用的算例（各参数组第 1~6 个）换种子重抽箱子。

和 gen_tight.py 的做法完全一样（场地 6×6×6、箱子三边各在 1..5 内随机取整，工期 / 资源 / 紧前不变），
只是随机种子换成 crc32(新名字)，所以箱子尺寸和原 U5S6 不同。
新名字 = 原名 + 'r' + 副本号，例如 j3010_1 → j3010_1r1。名字里带 'r' 的一律算训练集。
验证集（第 7 个）和测试集（第 8~10 个）不生成、不改动。

用法：python gen_aug.py [--copies 1]   → 03_算例/紧空间_U5S6_aug/<集合>_integer/j3010_1r1.sm ...
已生成且校验通过的文件跳过，可以重复运行。
"""
import os
import sys
import random
import zlib
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd

U, S = 5, 6
AUG_DIR = os.path.join(sd.DATA_DIR, '紧空间_U5S6_aug')


def aug_name(name, r):
    return '%sr%d' % (name, r)


def write_one(src_file, dst_file):
    I = sd.load_instance(src_file)
    new = os.path.splitext(os.path.basename(dst_file))[0]
    if os.path.exists(dst_file):
        try:
            J = sd.load_instance(dst_file)
            if (J.L, J.W, J.H) == (S, S, S) and J.d == I.d and J.succ == I.succ:
                return False
        except Exception:
            pass
    rnd = random.Random(zlib.crc32(new.encode()))
    dims = [(0, 0, 0) if I.d[j] == 0 else tuple(rnd.randint(1, U) for _ in range(3)) for j in range(I.n)]
    lines = open(src_file, encoding='utf-8', errors='replace').read().splitlines()
    low = [x.strip().lower() for x in lines]
    i0 = low.index('space')
    m0 = low.index('maxspace')
    out = lines[:i0 + 1] + ['%d %d %d %d %d' % (j + 1, a, b, c, a * b * c) for j, (a, b, c) in enumerate(dims)]
    out += lines[i0 + 1 + I.n:m0 + 1] + ['%d %d %d' % (S, S, S), '%d' % (S ** 3)]
    out += lines[m0 + 3:]
    with open(dst_file + '.tmp', 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('\n'.join(out) + '\n')
    os.replace(dst_file + '.tmp', dst_file)
    J = sd.load_instance(dst_file)                       # 回读校验
    assert J.dim == dims and (J.L, J.W, J.H) == (S, S, S) and J.d == I.d and J.r == I.r and J.succ == I.succ
    return True


def make(copies=1):
    n_new = n_all = 0
    for s in sd.SETS:
        src = os.path.join(sd.DATA_DIR, s + '_integer')         # 原版 R-instances（工期/资源/紧前的来源）
        dst = os.path.join(AUG_DIR, s + '_integer')
        os.makedirs(dst, exist_ok=True)
        for fn in sorted(os.listdir(src)):
            if not fn.endswith('.sm'):
                continue
            name = os.path.splitext(fn)[0]
            if int(name.split('_')[1]) > 6:                    # 只扩充训练集
                continue
            for r in range(1, copies + 1):
                n_all += 1
                n_new += write_one(os.path.join(src, fn), os.path.join(dst, aug_name(name, r) + '.sm'))
    print('扩充训练算例：共 %d 个（本次新写 %d 个），目录 %s' % (n_all, n_new, AUG_DIR), flush=True)


def list_aug():
    """[(集合, 名字, 路径)]，按名字排序"""
    out = []
    for s in sd.SETS:
        d = os.path.join(AUG_DIR, s + '_integer')
        if os.path.isdir(d):
            for fn in sorted(os.listdir(d)):
                if fn.endswith('.sm'):
                    out.append((s, os.path.splitext(fn)[0], os.path.join(d, fn)))
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--copies', type=int, default=1)
    make(ap.parse_args().copies)
