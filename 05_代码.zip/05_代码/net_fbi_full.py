# -*- coding: utf-8 -*-
"""
net_fbi_full.py —— 2.8 / 2.8b 全量验证：612 例测试集，每例跑 5 种方法，每种都在最后做 FBI（前后向改进）。
  LFT+FBI / 网络+FBI / act-1+FBI / act-pilot+FBI / 网络挑前2+推演+FBI（拟定新主方法）
同一算例的 5 种方法在同一个进程里接连跑，耗时互相可比（比快慢看比值）；绝对秒数以 VM 单进程为准。
判断标准事先定好（见 merge 输出的“三、结论”）。

用法：本机 python net_fbi_full.py --pool 12        （run_net_fbi.bat）
      VM   python3 net_fbi_full.py --part k/n --budget 150
      python3 net_fbi_full.py --merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A
import act1 as A1
import cpsat3d as C
import fbi_probe as FB

OUT = os.path.join(C.OUT, '_fbi_full')
METH = ['lft', 'net', 'act1', 'act', 'top2']
LAB = {'lft': 'LFT+FBI', 'net': '网络+FBI', 'act1': 'act-1+FBI', 'act': 'act-pilot+FBI', 'top2': '网络前2+推演+FBI'}
_model = None


def model():
    global _model
    if _model is None:
        import torch
        torch.set_num_threads(1)
        import act_net as N
        _model, _ = N.load_best(N.CKPT)
    return _model


def base_sol(m, I):
    if m == 'lft':
        lft = rl_env.ACTIONS.index('LFT')
        return rl_env.run_policy(I, lambda s: lft)[:4]
    if m == 'act1':
        return A1.run_act1(I)[:4]
    if m == 'act':
        return A.run_act_pilot(I)[:4]
    import act_net as N
    return N.run_net(model(), I, 1 if m == 'net' else 2)[:4]


def run_one(task):
    s_, nm, f = task
    I = sd.load_instance(f)
    model()                                            # 先加载，不计入耗时
    rec = {'set': s_, 'name': nm, 'viol': 0}
    for m in METH:
        t0 = time.time()
        ms, S, F, P = base_sol(m, I)
        t1 = time.time()
        _, best, _, v = FB.fbi(I, S, F, P)
        t2 = time.time()
        rec['viol'] += sum(sd.check(I, S, F, P, space=True).values()) + v
        rec[m + '_raw'], rec[m], rec['t_' + m], rec['tf_' + m] = ms, best, t1 - t0, t2 - t1
    path = os.path.join(OUT, nm + '.pkl')
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(rec, fh)
    os.replace(path + '.tmp', path)
    return nm, rec


def tasks():
    import train_dqn as T
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(OUT, '*.pkl')))
    te = T.list_instances()['test']
    return [t for t in te if t[1] not in have], len(have), len(te)


def line(nm, r):
    return '%s ' % nm + ' '.join('%s=%d→%d' % (m, r[m + '_raw'], r[m]) for m in METH) + \
        ' t_top2=%.1fs t_act=%.1fs viol=%d' % (r['t_top2'], r['t_act'], r['viol'])


def run_part(part, budget):
    os.makedirs(OUT, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    ts, nh, _ = tasks()
    ts = ts[k::n]
    t0 = time.time()
    done = 0
    for t in ts:
        est = {'j30': 2, 'j60': 8, 'j90': 20, 'j120': 35}[t[0]]
        if time.time() - t0 + est > budget:
            break
        nm, r = run_one(t)
        done += 1
        print('  ' + line(nm, r), flush=True)
    print('full %s: 本次 %d，剩 %d，%.0fs' % (part, done, len(ts) - done, time.time() - t0), flush=True)


def _init():
    os.environ.setdefault('OMP_NUM_THREADS', '1')
    model()


def run_pool(procs):
    from multiprocessing import Pool
    from progress import Bar
    os.makedirs(OUT, exist_ok=True)
    ts, nh, tot = tasks()
    ts.sort(key=lambda t: -{'j30': 1, 'j60': 2, 'j90': 3, 'j120': 4}[t[0]])   # 大算例先跑，尾部更整齐
    print('网络+FBI 全量：待跑 %d 例（已有 %d 例），%d 个进程' % (len(ts), nh, procs), flush=True)
    bar = Bar('net+fbi', tot, nh)
    nv = 0
    with Pool(procs, initializer=_init) as pool:
        for k, (nm, r) in enumerate(pool.imap_unordered(run_one, ts), 1):
            nv += r['viol']
            bar.update(nh + k, 'viol %d' % nv)
            print('[%d/%d] %s' % (k, len(ts), line(nm, r)), flush=True)
    bar.done()


def _ci(x, n=2000, seed=0):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return x.mean(), np.percentile(m, 2.5), np.percentile(m, 97.5)


def merge():
    base = C.load_base()
    cp = {}
    for f in glob.glob(os.path.join(C.CACHE, '*.pkl')):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        cp[r['name']] = r
    rows = []
    for f in glob.glob(os.path.join(OUT, '*.pkl')):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        r['LFTcsv'] = float(base[r['name']]['LFT'])
        r['cp'] = cp[r['name']]['ms']
        r['opt'] = cp[r['name']]['status'] == 'OPTIMAL'
        rows.append(r)
    if not rows:
        print('没有结果')
        return
    red = lambda r, m: (r['LFTcsv'] - r[m]) / r['LFTcsv']
    L = ['2.8 / 2.8b 全量：各方法 + FBI（前后向改进）—— U5S6 测试集 %d 例；0 违约才有效' % len(rows),
         '数字 = 比 LFT 短多少（越大越好）；括号内 = 不做 FBI 时；耗时为同进程实测（比值可比，绝对值以 VM 单进程为准）', '']
    L.append('一、各方法')
    L.append('%-6s %4s' % ('集合', '例数') + ''.join('%26s' % LAB[m] for m in METH) + '%14s' % 'CP-SAT')
    for s_ in C.SETS + ['ALL']:
        sel = [r for r in rows if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        L.append('%-6s %4d' % (s_, len(sel)) + ''.join('%8.2f%%(%6.2f%%)%7.2fs' % (
            100 * np.mean([red(r, m) for r in sel]), 100 * np.mean([red(r, m + '_raw') for r in sel]),
            np.mean([r['t_' + m] + r['tf_' + m] for r in sel])) for m in METH) +
            '%13.2f%%' % (100 * np.mean([red(r, 'cp') for r in sel])))
    opt = [r for r in rows if r['opt']]
    L += ['', '二、只看 CP-SAT 已证最优的 %d 例：比真正最优长多少' % len(opt)]
    for m in METH:
        x = [(r[m] - r['cp']) / r['cp'] for r in opt]
        L.append('  %-20s %.2f%%（不做 FBI %.2f%%）' % (LAB[m], 100 * np.mean(x),
                                                    100 * np.mean([(r[m + '_raw'] - r['cp']) / r['cp'] for r in opt])))
    L += ['', '三、结论（判断标准事先定好）']
    T = lambda m: np.array([r['t_' + m] + r['tf_' + m] for r in rows])

    def cmp(a, b):
        d = [(r[b] - r[a]) / r[b] for r in rows]           # >0 表示 a 更短
        mu, lo, hi = _ci(d)
        x = np.array([r[b] - r[a] for r in rows])
        return mu, lo, hi, (x > 0).sum(), (x == 0).sum(), (x < 0).sum()

    mu, lo, hi, w, t, l = cmp('top2', 'act')
    save = 1 - T('top2').sum() / T('act').sum()
    ok1 = lo <= 0 <= hi or lo > 0
    L.append('  1) 新主方法 对 act-pilot+FBI：工期 %+.2f%% [%+.2f%%, %+.2f%%]，%d 好 / %d 平 / %d 差；省时 %.0f%%' % (
        100 * mu, 100 * lo, 100 * hi, w, t, l, 100 * save))
    L.append('     标准：区间含 0 或整体偏好，且省时 ≥20%% → %s' % ('通过' if ok1 and save >= 0.2 else '不通过'))
    mu, lo, hi, w, t, l = cmp('net', 'lft')
    L.append('  2) 网络+FBI 对 LFT+FBI：%+.2f%% [%+.2f%%, %+.2f%%]，%d / %d / %d → %s（标准：区间不含 0 且为正）' % (
        100 * mu, 100 * lo, 100 * hi, w, t, l, '通过' if lo > 0 else '不通过'))
    mu, lo, hi, w, t, l = cmp('top2', 'act1')
    L.append('  3) 新主方法 对 act-1+FBI：%+.2f%% [%+.2f%%, %+.2f%%]，%d / %d / %d；耗时 %.2f s 对 %.2f s' % (
        100 * mu, 100 * lo, 100 * hi, w, t, l, T('top2').mean(), T('act1').mean()))
    mu, lo, hi, w, t, l = cmp('net', 'act1')
    L.append('     网络+FBI 对 act-1+FBI：%+.2f%% [%+.2f%%, %+.2f%%]，%d / %d / %d；耗时 %.2f s 对 %.2f s' % (
        100 * mu, 100 * lo, 100 * hi, w, t, l, T('net').mean(), T('act1').mean()))
    L.append('     （回答“不用网络行不行”：如实呈现速度–质量关系）')
    L += ['', '四、FBI 本身：平均耗时 %.3f s，各方法 FBI 后更短的例数：' % np.mean(
        [r['tf_' + m] for r in rows for m in METH]) + '  '.join(
        '%s %d' % (LAB[m], sum(r[m] < r[m + '_raw'] for r in rows)) for m in METH)]
    L.append('违约数：%d' % sum(r['viol'] for r in rows))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(C.OUT, 'FBI全量_612例.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    import csv
    with open(os.path.join(C.OUT, 'FBI全量_逐例结果.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        keys = ['set', 'LFTcsv', 'cp', 'opt'] + [m + s for m in METH for s in ('_raw', '')] + \
               ['t_' + m for m in METH] + ['tf_' + m for m in METH] + ['viol']
        w.writerow(['instance'] + keys)
        for r in sorted(rows, key=lambda r: r['name']):
            w.writerow([r['name']] + [r[k] for k in keys])
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part')
    ap.add_argument('--pool', type=int, default=0)
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.part, a.budget)
    if a.pool:
        run_pool(a.pool)
    if a.merge:
        merge()
