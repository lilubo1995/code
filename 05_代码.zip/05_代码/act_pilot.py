# -*- coding: utf-8 -*-
"""
act_pilot.py —— 3.8 上限测试：“按工序”的沙盒推演，看它比“按规则”的 pilot 能好多少

现在的 pilot：每个决策点选一条规则，这条规则决定此刻所有工序的开工顺序。
按工序的推演（act-pilot）：此刻每开一道工序都单独决策一次——
  候选 = 10 条规则各自的“首选可开工工序”（去重）；
  对每个候选 j：在沙盒里先开 j，再把 10 条规则各推演到底，取最短工期作为 j 的评分；
  开评分最好的那道，然后在同一时刻继续选下一道，直到此刻再没有两道以上能开工，才推进时间。
因为“规则 a 的首选工序 + 之后一直用 a”就是候选之一，这个方法的搜索范围包含了 pilot 的第一步选择。
它是 3.8“网络直接选工序”能学到的老师；它不比 pilot 明显好，3.8 就没有必要做。

用法：python3 act_pilot.py --run j30 --part 0/2 [--budget 150]；python3 act_pilot.py --merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import disturb as D

ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, '06_实验结果', '按工序推演_上限测试')
NA = len(rl_env.ACTIONS)
LFT = rl_env.ACTIONS.index('LFT')


def place(env, j):
    """j 此刻能否开工：资源够且 S4 找得到位置。返回 (能否, 位置)"""
    I = env.I
    if not env._res_ok(j):
        return False, None
    if I.d[j] > 0 and I.vol[j] > 0:
        l, w, h = I.dim[j]
        pos = sd.find_pos_complete(l, w, h, list(env.boxes.values()), I.L, I.W, I.H)
        return pos is not None, pos
    return True, None


def rollout_from(env, a):
    """从“时刻中间”的状态出发：先用规则 a 把此刻剩下的排完，再一直用 a 排到底"""
    e = env.clone()
    e._pass(rl_env.ACTIONS[a])
    e._advance()
    e._to_decision(rl_env.ACTIONS[a])
    while not e.done:
        e.step(a)
    return e.makespan()


def run_act_pilot(I):
    env = rl_env.Env(I)
    env.reset()
    n_sub = act_loop(env)
    return env.makespan(), env.S, env.F, env.P, n_sub


def act_loop(env, hook=None):
    """在已 reset/setup 好的环境上执行 act-pilot 直到完工（扰动环境 DEnv 也可用：
    clone() 只带已知信息，所以推演看不到未来的延误和中断）。返回逐道决策次数。
    hook(env, ok, cand, vals)：每次逐道决策前调用一次（选工序网络 act_net.py 用它采集老师标签）。"""
    n_sub = 0
    while not env.done:
        # 同一时刻内逐道决策
        while True:
            ok = {}
            for j in env.elig:
                f, pos = place(env, j)
                if f:
                    ok[j] = pos
            if len(ok) == 0:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = []
            for a in range(NA):
                key = env.keys[rl_env.ACTIONS[a]]
                j = min(ok, key=lambda x: key[x])
                if j not in cand:
                    cand.append(j)
            best_j, best_v = None, None
            vals = []
            for j in cand:
                e = env.clone()
                e._start(j, ok[j])
                v = min(rollout_from(e, a) for a in range(NA))
                vals.append(v)
                if best_v is None or v < best_v:
                    best_j, best_v = j, v
            if hook is not None:
                hook(env, ok, cand, vals)
            env._start(best_j, ok[best_j])
            n_sub += 1
        env._advance()
        env._to_decision(rl_env.ACTIONS[LFT])
    return n_sub


def lft_ms(I):
    return rl_env.run_policy(I, lambda s: LFT)[0]


def run_part(set_name, part, budget):
    os.makedirs(OUT, exist_ok=True)
    kk, n = (int(x) for x in part.split('/'))
    path = os.path.join(OUT, '_cache_%s_p%dof%d.pkl' % (set_name, kk, n))
    cache = {}
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            cache = pickle.load(fh)
    t00 = time.time()
    items = D.list_items(set_name)[kk::n]
    for name, f in items:
        if name in cache:
            continue
        if time.time() - t00 > budget:
            break
        I = sd.load_instance(f)
        t0 = time.time()
        p_ms = rl_env.run_pilot(I)[0]
        t1 = time.time()
        ms, S, F, P, nsub = run_act_pilot(I)
        t2 = time.time()
        v = sd.check(I, S, F, P, space=True)
        cache[name] = {'set': set_name, 'cpm': I.cpm, 'lft': lft_ms(I), 'pilot': p_ms, 'act': ms,
                       'viol': sum(v.values()), 't_pilot': t1 - t0, 't_act': t2 - t1, 'nsub': nsub}
        with open(path + '.tmp', 'wb') as fh:
            pickle.dump(cache, fh, protocol=4)
        os.replace(path + '.tmp', path)
    print('%s part %s: %d/%d 例，用时 %.0fs' % (set_name, part, sum(1 for nm, _ in items if nm in cache),
                                            len(items), time.time() - t00))


def _one(task):
    """多进程用：一个测试算例只跑 act-pilot（LFT、pilot 的结果已在 DQN 测试集逐例结果里）"""
    s, name, f = task
    I = sd.load_instance(f)
    t0 = time.time()
    ms, S, F, P, nsub = run_act_pilot(I)
    dt = time.time() - t0
    v = sd.check(I, S, F, P, space=True)
    return name, {'set': s, 'cpm': I.cpm, 'act': ms, 'viol': sum(v.values()), 't_act': dt, 'nsub': nsub}


def run_pool(workers):
    """Windows 本机多进程：612 个测试算例（各参数组第 8~10 个）全部跑 act-pilot，已有的跳过"""
    from multiprocessing import Pool, cpu_count
    import train_dqn as T
    os.makedirs(OUT, exist_ok=True)
    have = set()
    for f in glob.glob(os.path.join(OUT, '_cache_*.pkl')):
        with open(f, 'rb') as fh:
            have |= set(pickle.load(fh).keys())
    tasks = [x for x in T.list_instances()['test'] if x[1] not in have]
    tasks.sort(key=lambda x: -int(x[0][1:]))
    path = os.path.join(OUT, '_cache_win.pkl')
    cache = {}
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            cache = pickle.load(fh)
    workers = workers or max(1, cpu_count() - 1)
    print('act-pilot 静态测试：待跑 %d 例（已有 %d 例），进程数 %d' % (len(tasks), len(have), workers), flush=True)
    t00 = time.time()
    from progress import Bar
    nh = len(have)
    bar = Bar('act-pilot', nh + len(tasks), nh)
    bar.update(nh)
    with Pool(workers) as pool:
        for k, (nm, r) in enumerate(pool.imap_unordered(_one, tasks), 1):
            cache[nm] = r
            with open(path + '.tmp', 'wb') as fh:
                pickle.dump(cache, fh, protocol=4)
            os.replace(path + '.tmp', path)
            bar.update(nh + k)
            if k % 20 == 0 or k == len(tasks):
                print('[%d/%d] 累计 %.1f 分钟' % (k, len(tasks), (time.time() - t00) / 60), flush=True)
    bar.done()


def merge612():
    """612 个测试算例：act-pilot 与 LFT / DQN / guided3 / pilot 放在同一张表（相对 LB 的差距）"""
    import pandas as pd
    import train_dqn as T
    rec = {}
    for f in glob.glob(os.path.join(OUT, '_cache_*.pkl')):
        with open(f, 'rb') as fh:
            rec.update(pickle.load(fh))
    d = pd.read_csv(os.path.join(T.OUT, '测试集逐例结果.csv'))
    a = pd.DataFrame([{'instance': k, 'act': v['act'], 'act_s': v['t_act'], 'act_viol': v['viol']}
                      for k, v in rec.items()])
    d = d.merge(a, on='instance', how='inner')
    L = ['', '=' * 100, '612 个测试算例：按工序沙盒推演（act-pilot）与其他方法（相对 LB 的差距，越小越好）',
         '（共 %d 例%s）' % (len(d), '' if len(d) == 612 else '，还没跑全'), '',
         '%-6s %9s %9s %9s %9s %9s %10s %10s' % ('集合', 'LFT', 'DQN', 'guided3', 'pilot', 'act', 'pilot秒', 'act秒')]
    for s in T.SETS + ['ALL']:
        x = d if s == 'ALL' else d[d['set'] == s]
        if len(x) == 0:
            continue
        gap = lambda c: 100 * (x[c] / x['LB'] - 1).mean()
        L.append('%-6s %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2f%% %9.2fs %9.2fs' % (
            s, gap('LFT'), gap('DQN'), gap('guided3'), gap('pilot'), gap('act'), x['pilot_s'].mean(), x['act_s'].mean()))
    L.append('')
    for c, base in (('pilot', 'LFT'), ('act', 'LFT'), ('act', 'pilot')):
        diff = d[base] - d[c]
        L.append('%s 相对 %s：平均缩短 %.2f%%，平均少 %.1f 天，更好/持平/更差 = %d / %d / %d' % (
            c, base, 100 * (diff / d[base]).mean(), diff.mean(), (diff > 0).sum(), (diff == 0).sum(), (diff < 0).sum()))
    L.append('act-pilot 违约数：%d' % int(d['act_viol'].sum()))
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '612例对比.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    d.to_csv(os.path.join(OUT, '612例逐例结果.csv'), index=False, encoding='utf-8-sig')
    print(txt)


def merge():
    rec = {}
    for f in glob.glob(os.path.join(OUT, '_cache_*.pkl')):
        with open(f, 'rb') as fh:
            rec.update({k: v for k, v in pickle.load(fh).items() if 'pilot' in v})   # 上限测试只用带 pilot 的 204 例
    L = ['按工序沙盒推演（act-pilot）上限测试：U5S6 测试集各参数组第 8 个算例', '']
    L.append('%-6s %4s %9s %9s %9s %12s %12s %10s %10s %6s' % (
        '集合', '例数', 'LFT', 'pilot', 'act', 'pilot比LFT', 'act比pilot', 'act胜/平/负', '秒(act)', '违约'))
    for s in ('j30', 'j60', 'j90', 'j120'):
        r = [x for x in rec.values() if x['set'] == s]
        if not r:
            continue
        g = lambda k: np.mean([x[k] for x in r])
        red1 = np.mean([1 - x['pilot'] / x['lft'] for x in r]) * 100
        red2 = np.mean([1 - x['act'] / x['pilot'] for x in r]) * 100
        w = sum(x['act'] < x['pilot'] for x in r)
        t = sum(x['act'] == x['pilot'] for x in r)
        L.append('%-6s %4d %9.2f %9.2f %9.2f %11.2f%% %11.2f%% %4d/%d/%d %10.2f %6d' % (
            s, len(r), g('lft'), g('pilot'), g('act'), red1, red2, w, t, len(r) - w - t, g('t_act'),
            sum(x['viol'] for x in r)))
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '汇总.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', type=str)
    ap.add_argument('--part', type=str, default='0/1')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    ap.add_argument('--pool', action='store_true', help='Windows 多进程跑 612 个测试算例')
    ap.add_argument('--workers', type=int, default=0)
    ap.add_argument('--merge612', action='store_true')
    a = ap.parse_args()
    if a.run:
        run_part(a.run, a.part, a.budget)
    if a.pool:
        run_pool(a.workers)
    if a.merge:
        merge()
    if a.merge612:
        merge612()
