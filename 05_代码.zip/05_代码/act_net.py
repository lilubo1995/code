# -*- coding: utf-8 -*-
"""
act_net.py —— 3.8 选工序的图网络：模仿 act-pilot（按工序沙盒推演）的每一次“先开哪道工序”。

动作：同一时刻里，候选 = 10 条规则各自的首选可开工工序（去重，和 act-pilot 完全一样）。
      网络给每个候选打一个分，开分最高的那道；然后在同一时刻继续选下一道。
      位置仍由 S4 找，所以网络怎么选，方案都可行。
老师：act-pilot 对每个候选“先开它、再 10 条规则推演到底”的最短工期 v。
      训练目标 = 软标签交叉熵：p(候选) ∝ exp(−(v − v_min)/τ)，τ = 1 天（并列最好的候选平分概率）。
网络：关系图卷积（4 类边：紧前正/反、空间不相容、资源不相容），节点特征 = 27 静态 + 11 动态 + 2（是否候选、
      此刻是否放得下），读出 = [候选节点向量, 全图均值, 执行中均值, 放得下节点均值, 20 维全局状态] → MLP → 分数。
测试：greedy（只用网络，不推演）和 top2（只推演网络排前 2 的候选，选推演最好的）。

用法：
  python3 act_net.py --label k/n [--budget 150]   VM 分块打标签（训练集+验证集），每例一个文件
  python3 act_net.py --label-pool --workers 24    Windows 多进程打标签（已有的跳过）
  python3 act_net.py --epochs 30                  训练（GPU，每轮在验证集半集上贪心评估，保留最好参数）
  python3 act_net.py --eval-pool --workers 8      测试集 612 例评估（已有的跳过）；--eval k/n 为 VM 分块版
  python3 act_net.py --merge                      汇总（不需要 pandas）
"""
import os
import sys
import csv
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A
import graph_feats as GF
from progress import Bar

ROOT = os.path.dirname(HERE)
OUT = os.environ.get('ACT_OUT', os.path.join(ROOT, '06_实验结果', '选工序网络'))   # 自检时指到临时目录
LAB = os.path.join(OUT, '_label')                 # 标签所有变体共用
EVD = os.path.join(OUT, '_eval')
CKPT = os.environ.get('ACT_CKPT', os.path.join(OUT, 'act_ckpt.pt'))
# 1.6 / 3.6 的变体（variants.py 调用）：ACT_RUN=名字 时检查点和评估结果放到 OUT/runs/<名字>/，互不覆盖
RUN = os.environ.get('ACT_RUN', '')
if RUN:
    RUN_DIR = os.path.join(OUT, 'runs', RUN)
    CKPT = os.path.join(RUN_DIR, 'act_ckpt.pt')
    EVD = os.path.join(RUN_DIR, '_eval')
ETYPES = {'fwd': 0, 'bwd': 1, 'sp': 2, 'rs': 3}   # 紧前正向 / 紧前反向 / 空间不相容 / 资源不相容
SETS = ['j30', 'j60', 'j90', 'j120']
NA = len(rl_env.ACTIONS)
LFT = rl_env.ACTIONS.index('LFT')
F_IN = GF.F_STATIC + GF.F_DYN + 2
F_G = rl_env.N_FEAT
TAU = 1.0
MAXC = NA


def list_instances():
    import train_dqn as T          # 只用它的划分（各参数组第 1~6 训练、第 7 验证、第 8~10 测试）
    return T.list_instances()


# ----------------------------------------------------------------------------------------------
# 候选与打标签（不需要 torch）
# ----------------------------------------------------------------------------------------------
def feasible(env):
    ok = {}
    for j in env.elig:
        f, pos = A.place(env, j)
        if f:
            ok[j] = pos
    return ok


def candidates(env, ok):
    cand = []
    for a in range(NA):
        key = env.keys[rl_env.ACTIONS[a]]
        j = min(ok, key=lambda x: key[x])
        if j not in cand:
            cand.append(j)
    return cand


def label_one(task):
    s, name, f = task
    I = sd.load_instance(f)
    env = rl_env.Env(I)
    env.reset()
    Xs, E = GF.static_graph(env)
    samples = []

    def hook(e, ok, cand, vals):
        if len(cand) < 2:
            return
        samples.append({'D': GF.dyn_feats(e).astype(np.float16), 'G': e.obs().astype(np.float32),
                        'ok': np.array(sorted(ok), dtype=np.int16), 'cand': np.array(cand, dtype=np.int16),
                        'v': np.array(vals, dtype=np.float32)})
    t0 = time.time()
    A.act_loop(env, hook)
    ms = env.makespan()
    viol = sum(sd.check(I, env.S, env.F, env.P, space=True).values())
    rec = {'name': name, 'set': s, 'split': name_split(name), 'cpm': I.cpm, 'Xs': Xs, 'E': E,
           'S': samples, 'ms': ms, 'viol': viol, 't': time.time() - t0}
    path = os.path.join(LAB, name + '.pkl')
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(rec, fh, protocol=4)
    os.replace(path + '.tmp', path)
    return name, len(samples), ms, viol


def is_aug(name):
    """1.6 扩充算例（gen_aug.py 生成，名字形如 j3010_1r1），只用于训练"""
    return 'r' in name.split('_')[1]


def name_split(name):
    if is_aug(name):
        return 'train'
    k = int(name.split('_')[1])
    return 'train' if k <= 6 else ('val' if k == 7 else 'test')


def label_tasks(aug=False):
    inst = list_instances()
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(LAB, '*.pkl')))
    pool = inst['train'] + inst['val']
    if aug:
        import gen_aug
        pool = pool + gen_aug.list_aug()
    tasks = [x for x in pool if x[1] not in have]
    tasks.sort(key=lambda x: -int(x[0][1:]))          # 大算例先跑，进程池收尾更均匀
    return tasks, len(have)


def label_part(part, budget, aug=False):
    os.makedirs(LAB, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    tasks, nh = label_tasks(aug)
    tasks = tasks[k::n]
    t00 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t00 > budget:
            break
        label_one(t)
        done += 1
    print('label %s: 本次 %d 例，剩 %d 例（之前已有 %d），%.0fs' % (part, done, len(tasks) - done, nh,
                                                         time.time() - t00), flush=True)


def label_pool(workers, aug=False):
    from multiprocessing import Pool, cpu_count
    os.makedirs(LAB, exist_ok=True)
    tasks, nh = label_tasks(aug)
    workers = workers or max(1, cpu_count() - 1)
    print('打标签：待跑 %d 例（已有 %d 例），进程数 %d' % (len(tasks), nh, workers), flush=True)
    t00 = time.time()
    ns = 0
    bar = Bar('label', nh + len(tasks), nh)
    with Pool(workers) as pool:
        for k, (nm, m, ms, viol) in enumerate(pool.imap_unordered(label_one, tasks), 1):
            ns += m
            bar.update(nh + k)
            if viol:
                print('!! %s 违约 %d' % (nm, viol), flush=True)
            if k % 50 == 0 or k == len(tasks):
                print('[%d/%d] 样本 %d，累计 %.1f 分钟' % (k, len(tasks), ns, (time.time() - t00) / 60), flush=True)
    bar.done()


def load_labels(split=None, aug=False):
    """aug=False 时不含 1.6 扩充算例（保证和 3.8 的原始训练集完全一样）"""
    out = []
    for f in sorted(glob.glob(os.path.join(LAB, '*.pkl'))):
        nm = os.path.splitext(os.path.basename(f))[0]
        if is_aug(nm) and not aug:
            continue
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        if split is None or name_split(nm) == split:
            out.append(r)
    return out


# ----------------------------------------------------------------------------------------------
# 网络（torch 只在这里以后才需要）
# ----------------------------------------------------------------------------------------------
_torch = None


def T_():
    global _torch
    if _torch is None:
        import torch
        _torch = torch
    return _torch


def build_model(h=128, layers=4, dropout=0.1, drop=()):
    """drop：消融时不用的边类型下标（见 ETYPES），这些边上不传消息"""
    torch = T_()
    nn = torch.nn
    drop = set(drop)

    class ActNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.inp = nn.Linear(F_IN, h)
            self.self_lin = nn.ModuleList([nn.Linear(h, h) for _ in range(layers)])
            self.rel_lin = nn.ModuleList([nn.ModuleList([nn.Linear(h, h, bias=False) for _ in range(GF.N_ETYPE)])
                                          for _ in range(layers)])
            self.norm = nn.ModuleList([nn.LayerNorm(h) for _ in range(layers)])
            self.drop = nn.Dropout(dropout)
            self.head = nn.Sequential(nn.Linear(4 * h + F_G, 256), nn.ReLU(), nn.Dropout(dropout),
                                      nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, 1))
            self.h = h

        def forward(self, x, edges, gid, ng, actv, okm, g, cidx, cmask):
            """cidx: B×C 候选节点的全局下标；返回 B×C 分数（无效位置为 −1e9）"""
            hh = torch.relu(self.inp(x))
            N = hh.shape[0]
            dv = hh.device
            for L in range(len(self.self_lin)):
                m = self.self_lin[L](hh)
                for t, (src, dst, dinv) in enumerate(edges):
                    if src.numel() == 0 or t in drop:
                        continue
                    msg = self.rel_lin[L][t](hh)[src]
                    agg = torch.zeros(N, self.h, device=dv).index_add_(0, dst, msg)
                    m = m + agg * dinv[:, None]
                hh = self.norm[L](hh + self.drop(torch.relu(m)))

            def mean_pool(mask):
                w = mask.float()
                s = torch.zeros(ng, self.h, device=dv).index_add_(0, gid, hh * w[:, None])
                c = torch.zeros(ng, device=dv).index_add_(0, gid, w).clamp(min=1.0)
                return s / c[:, None]
            pooled = torch.cat([mean_pool(torch.ones_like(actv)), mean_pool(actv), mean_pool(okm), g], 1)  # B×(3h+fg)
            B, C = cidx.shape
            hc = hh[cidx.reshape(-1)].reshape(B, C, self.h)
            z = torch.cat([hc, pooled[:, None, :].expand(B, C, pooled.shape[1])], 2)
            sc = self.head(z).squeeze(2)
            return torch.where(cmask, sc, torch.full_like(sc, -1e9))

    return ActNet()


def node_x(Xs, D, ok, cand):
    n = Xs.shape[0]
    ex = np.zeros((n, 2), dtype=np.float32)
    ex[np.asarray(cand, dtype=np.int64), 0] = 1
    ex[np.asarray(ok, dtype=np.int64), 1] = 1
    return np.concatenate([Xs, D.astype(np.float32), ex], 1)


def edge_tensors(Es, N, dev):
    """Es: 每类边的 [k×2] 数组列表（已加偏移）→ [(src, dst, 1/入度)]"""
    torch = T_()
    out = []
    for t in range(GF.N_ETYPE):
        e = Es[t]
        if len(e):
            e = torch.from_numpy(np.ascontiguousarray(e))
            src, dst = e[:, 0], e[:, 1]
            deg = torch.zeros(N).index_add_(0, dst, torch.ones(len(dst)))
            out.append((src.to(dev), dst.to(dev), (1.0 / deg.clamp(min=1.0)).to(dev)))
        else:
            out.append((torch.zeros(0, dtype=torch.long, device=dev),) * 2 + (torch.zeros(N, device=dev),))
    return out


def collate(items, dev):
    """items: [(Xs, E, D, G, ok, cand)] → 模型输入"""
    torch = T_()
    xs, gid, ac, okm, gg = [], [], [], [], []
    es = [[] for _ in range(GF.N_ETYPE)]
    cidx = np.zeros((len(items), MAXC), dtype=np.int64)
    cm = np.zeros((len(items), MAXC), dtype=bool)
    off = 0
    for b, (Xs, E, D, G, ok, cand) in enumerate(items):
        n = Xs.shape[0]
        xs.append(node_x(Xs, D, ok, cand))
        gid.append(np.full(n, b, dtype=np.int64))
        ac.append(D[:, 1] > 0.5)
        m = np.zeros(n, dtype=bool)
        m[np.asarray(ok, dtype=np.int64)] = True
        okm.append(m)
        gg.append(G)
        for t in range(GF.N_ETYPE):
            if len(E[t]):
                es[t].append(E[t] + off)
        c = np.asarray(cand, dtype=np.int64)
        cidx[b, :len(c)] = c + off
        cidx[b, len(c):] = off
        cm[b, :len(c)] = True
        off += n
    Es = [np.concatenate(e) if e else np.zeros((0, 2), dtype=np.int64) for e in es]
    f = lambda a: torch.from_numpy(a).to(dev)
    return (f(np.concatenate(xs)), edge_tensors(Es, off, dev), f(np.concatenate(gid)), len(items),
            f(np.concatenate(ac)), f(np.concatenate(okm)), f(np.stack(gg).astype(np.float32)), f(cidx), f(cm))


class Scorer(object):
    """单个算例推理用：边张量只建一次"""

    def __init__(self, model, env, dev):
        self.model, self.dev = model, dev
        self.Xs, E = GF.static_graph(env)
        self.n = self.Xs.shape[0]
        self.edges = edge_tensors(E, self.n, dev)
        torch = T_()
        self.gid = torch.zeros(self.n, dtype=torch.long, device=dev)

    def __call__(self, env, ok, cand):
        return self.score(GF.dyn_feats(env), env.obs().astype(np.float32), ok, cand)

    def score(self, D, G, ok, cand):
        torch = T_()
        x = torch.from_numpy(node_x(self.Xs, D, list(ok), cand)).to(self.dev)
        m = np.zeros(self.n, dtype=bool)
        m[list(ok)] = True
        c = np.zeros((1, MAXC), dtype=np.int64)
        c[0, :len(cand)] = cand
        cm = np.zeros((1, MAXC), dtype=bool)
        cm[0, :len(cand)] = True
        f = lambda a: torch.from_numpy(a).to(self.dev)
        g = f(np.asarray(G, dtype=np.float32)[None])
        with torch.no_grad():
            sc = self.model(x, self.edges, self.gid, 1, f(D[:, 1] > 0.5), f(m), g, f(c), f(cm))
        return sc[0, :len(cand)].cpu().numpy()


def run_net(model, I, topk=1, dev=None):
    """topk=1：只用网络；topk=2：推演网络排前 2 的候选（每个候选 10 条规则推演到底），选最好的"""
    torch = T_()
    dev = dev or torch.device('cpu')
    env = rl_env.Env(I)
    env.reset()
    sc = Scorer(model, env, dev)
    n_dec = 0
    while not env.done:
        while True:
            ok = feasible(env)
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = candidates(env, ok)
            if len(cand) == 1:
                j = cand[0]
            else:
                s = sc(env, ok, cand)
                order = [cand[i] for i in np.argsort(-s)]
                if topk == 1:
                    j = order[0]
                else:
                    best = None
                    for c in order[:topk]:
                        e = env.clone()
                        e._start(c, ok[c])
                        v = min(A.rollout_from(e, a) for a in range(NA))
                        if best is None or v < best[1]:
                            best = (c, v)
                    j = best[0]
                n_dec += 1
            env._start(j, ok[j])
        env._advance()
        env._to_decision(rl_env.ACTIONS[LFT])
    return env.makespan(), env.S, env.F, env.P, n_dec


# ----------------------------------------------------------------------------------------------
# 训练
# ----------------------------------------------------------------------------------------------
def soft_target(v):
    p = np.exp(-(v - v.min()) / TAU)
    return p / p.sum()


def val_score(model, items, dev):
    model.eval()
    r = [run_net(model, I, 1, dev)[0] / float(I.cpm) for I in items]
    model.train()
    return float(np.mean(r))


def train_epochs(epochs, hidden=128, layers=4, batch=128, lr=1e-3, dropout=0.1, limit=0, aug=False, drop=(),
                 seed=None):
    """aug：训练集加入 1.6 扩充算例；drop：消融时去掉的边类型下标；seed：网络初始化和打乱顺序的种子"""
    torch = T_()
    nn = torch.nn
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if dev.type == 'cpu':
        torch.set_num_threads(2)
    print('设备:', dev, torch.cuda.get_device_name(0) if dev.type == 'cuda' else '', flush=True)
    os.makedirs(os.path.dirname(CKPT), exist_ok=True)
    data = load_labels('train', aug)
    if limit:
        data = data[:limit]
    n_aug = sum(1 for d in data if is_aug(d['name']))
    print('训练算例 %d 个（其中 1.6 扩充 %d 个）；去掉的边：%s' % (
        len(data), n_aug, ','.join(k for k, v in ETYPES.items() if v in drop) or '无'), flush=True)
    samples = [(gi, i) for gi, d in enumerate(data) for i in range(len(d['S']))]
    cfg = {'h': hidden, 'layers': layers, 'dropout': dropout}
    if drop:
        cfg['drop'] = sorted(drop)
    if seed is not None:
        cfg['seed'] = seed
        torch.manual_seed(seed)
    model = build_model(hidden, layers, dropout, drop).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    steps_per = (len(samples) + batch - 1) // batch
    total = max(1, epochs * steps_per)
    warm = max(1, total // 20)

    def lr_lambda(step):
        if step < warm:
            return (step + 1) / float(warm)
        p = min(1.0, (step - warm) / float(max(1, total - warm)))
        return 0.05 + 0.95 * 0.5 * (1 + np.cos(np.pi * p))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda)
    state = {'epoch': 0, 'best_val': None, 'best': None, 'curve': [], 'cfg': cfg}
    if os.path.exists(CKPT):
        old = torch.load(CKPT, map_location=dev, weights_only=False)
        if old.get('cfg') == cfg and old.get('epochs_total') == epochs and old.get('n_samples') == len(samples):
            state = old
            model.load_state_dict(old['model'])
            opt.load_state_dict(old['opt'])
            sched.load_state_dict(old['sched'])
            print('从 epoch %d 续训' % state['epoch'], flush=True)
    state['epochs_total'], state['n_samples'] = epochs, len(samples)
    print('训练样本 %d（%d 个算例），参数量 %.3fM，每轮 %d 步' % (
        len(samples), len(data), sum(p.numel() for p in model.parameters()) / 1e6, steps_per), flush=True)
    # 参照：候选里常有并列最好的，所以“选中老师最优”要和这两个基线比
    hl, hr = [], []
    for d in data:
        for x in d['S']:
            best = x['v'] <= x['v'].min() + 1e-6
            hl.append(best[0])                      # cand[0] = LFT 规则的首选工序
            hr.append(best.mean())                  # 随机选的期望命中率
    state['ref_hit'] = (float(np.mean(hl)), float(np.mean(hr)))
    print('参照：总选 LFT 首选 命中 %.1f%%，随机选 命中 %.1f%%，平均候选数 %.2f' % (
        100 * state['ref_hit'][0], 100 * state['ref_hit'][1],
        np.mean([len(x['v']) for d in data for x in d['S']])), flush=True)
    val_items = [sd.load_instance(f) for s, nm, f in list_instances()['val'][::2]]
    rng = np.random.default_rng(7 if seed is None else 1000 + seed)
    for _ in range(state['epoch']):
        rng.permutation(len(samples))
    nb = (len(samples) + batch - 1) // batch            # 每轮的批数
    bar = Bar('train', epochs * nb, state['epoch'] * nb)
    while state['epoch'] < epochs:
        t0 = time.time()
        model.train()
        perm = rng.permutation(len(samples))
        losses, hits = [], []
        for p in range(0, len(perm), batch):
            its, tg = [], np.zeros((min(batch, len(perm) - p), MAXC), dtype=np.float32)
            for b, s in enumerate(perm[p:p + batch]):
                gi, i = samples[s]
                d = data[gi]
                x = d['S'][i]
                its.append((d['Xs'], d['E'], x['D'], x['G'], x['ok'], x['cand']))
                tg[b, :len(x['v'])] = soft_target(x['v'])
            sc = model(*collate(its, dev))
            tgt = torch.from_numpy(tg).to(dev)
            loss = -(tgt * torch.log_softmax(sc, 1)).sum(1).mean()
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            sched.step()
            losses.append(loss.item())
            # 网络首选是否落在老师“并列最好”的候选里
            pick = sc.argmax(1).cpu().numpy()
            hits += [tg[b, pick[b]] >= tg[b].max() - 1e-6 for b in range(len(pick))]
            bar.update(state['epoch'] * nb + p // batch + 1,
                       'ep %d/%d best %s' % (state['epoch'] + 1, epochs,
                                             '-' if state['best_val'] is None else '%.4f' % state['best_val']))
        tt = time.time() - t0
        v = val_score(model, val_items, dev)
        state['epoch'] += 1
        state['curve'].append((state['epoch'], float(np.mean(losses)), float(np.mean(hits)), v))
        if state['best_val'] is None or v < state['best_val']:
            state['best_val'] = v
            state['best'] = {k: x.detach().cpu().clone() for k, x in model.state_dict().items()}
        state['model'] = {k: x.detach().cpu().clone() for k, x in model.state_dict().items()}
        state['opt'] = opt.state_dict()
        state['sched'] = sched.state_dict()
        torch.save(state, CKPT + '.tmp')
        os.replace(CKPT + '.tmp', CKPT)
        print('epoch %2d/%d  loss %.4f  选中老师最优 %.1f%%  验证 ms/CPM %.4f  best %.4f  训练 %.0fs 验证 %.0fs' % (
            state['epoch'], epochs, np.mean(losses), 100 * np.mean(hits), v, state['best_val'], tt,
            time.time() - t0 - tt), flush=True)
    bar.done('best %.4f' % state['best_val'])
    print('训练完成，最优验证 %.4f，检查点 %s' % (state['best_val'], CKPT), flush=True)


def load_best(path=None, dev=None, which='best'):
    torch = T_()
    state = torch.load(path or CKPT, map_location='cpu', weights_only=False)
    cfg = state['cfg']
    model = build_model(cfg['h'], cfg['layers'], cfg.get('dropout', 0.1), cfg.get('drop', ()))
    model.load_state_dict(state[which])
    model.to(dev or torch.device('cpu'))
    model.eval()
    return model, state


# ----------------------------------------------------------------------------------------------
# 测试集评估
# ----------------------------------------------------------------------------------------------
_model = None
_evd = None
TAGS = {'bc': '模仿（3.8）', 'ppo': '模仿+PPO（3.9）'}


def ckpt_of(tag):
    return CKPT if tag == 'bc' else os.path.join(OUT, 'ppo_ckpt.pt')


def eval_dir(tag):
    return EVD if tag == 'bc' else EVD + '_' + tag


def _eval_init(tag):
    global _model, _evd
    torch = T_()
    torch.set_num_threads(1)
    _model, _ = load_best(ckpt_of(tag))
    _evd = eval_dir(tag)


def eval_one(task):
    s, name, f = task
    I = sd.load_instance(f)
    r = {'set': s, 'cpm': I.cpm}
    viol = 0
    for tag, k in (('net', 1), ('net_top2', 2)):
        t0 = time.time()
        ms, S, F, P, nd = run_net(_model, I, k)
        r[tag] = ms
        r[tag + '_s'] = time.time() - t0
        viol += sum(sd.check(I, S, F, P, space=True).values())
    r['viol'] = viol
    path = os.path.join(_evd, name + '.pkl')
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(r, fh)
    os.replace(path + '.tmp', path)
    return name, r


def eval_tasks(tag):
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(eval_dir(tag), '*.pkl')))
    tasks = [x for x in list_instances()['test'] if x[1] not in have]
    tasks.sort(key=lambda x: -int(x[0][1:]))
    return tasks, len(have)


def eval_pool(workers, tag='bc'):
    from multiprocessing import Pool
    os.makedirs(eval_dir(tag), exist_ok=True)
    tasks, nh = eval_tasks(tag)
    workers = workers or 8
    print('测试集评估[%s]：待跑 %d 例（已有 %d 例），进程数 %d' % (tag, len(tasks), nh, workers), flush=True)
    t00 = time.time()
    bar = Bar('eval ' + tag, nh + len(tasks), nh)
    with Pool(workers, initializer=_eval_init, initargs=(tag,)) as pool:
        for k, _ in enumerate(pool.imap_unordered(eval_one, tasks), 1):
            bar.update(nh + k)
            if k % 50 == 0 or k == len(tasks):
                print('[%d/%d] 累计 %.1f 分钟' % (k, len(tasks), (time.time() - t00) / 60), flush=True)
    bar.done()


def eval_part(part, budget, tag='bc'):
    os.makedirs(eval_dir(tag), exist_ok=True)
    _eval_init(tag)
    T_().set_num_threads(2)
    k, n = (int(x) for x in part.split('/'))
    tasks, nh = eval_tasks(tag)
    tasks = tasks[k::n]
    t00 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t00 > budget:
            break
        eval_one(t)
        done += 1
    print('eval %s: 本次 %d 例，剩 %d 例，%.0fs' % (part, done, len(tasks) - done, time.time() - t00), flush=True)


def merge():
    base = {}
    with open(os.path.join(A.OUT, '612例逐例结果.csv'), encoding='utf-8-sig') as fh:
        for row in csv.DictReader(fh):
            base[row['instance']] = row
    rows = {}
    for tag, pre in (('bc', ''), ('ppo', 'ppo_')):
        for f in glob.glob(os.path.join(eval_dir(tag), '*.pkl')):
            nm = os.path.splitext(os.path.basename(f))[0]
            with open(f, 'rb') as fh:
                r = pickle.load(fh)
            if nm not in rows:
                b = base[nm]
                rows[nm] = {'instance': nm, 'set': r['set'], 'viol': 0, 'LB': float(b['LB']),
                            'LFT': float(b['LFT']), 'pilot': float(b['pilot']), 'pilot_s': float(b['pilot_s']),
                            'act': float(b['act']), 'act_s': float(b['act_s']), 'guided3': float(b['guided3']),
                            'DQN': float(b['DQN'])}
            for k in ('net', 'net_top2', 'net_s', 'net_top2_s'):
                rows[nm][pre + k] = r[k]
            rows[nm]['viol'] += r['viol']
    have_ppo = any('ppo_net' in r for r in rows.values())
    rows = [r for r in rows.values() if 'net' in r and (not have_ppo or 'ppo_net' in r)]
    rows.sort(key=lambda r: (SETS.index(r['set']), r['instance']))
    cols = ['LFT', 'DQN', 'net', 'guided3', 'net_top2', 'pilot', 'act']
    if have_ppo:
        cols = ['LFT', 'DQN', 'net', 'ppo_net', 'guided3', 'net_top2', 'ppo_net_top2', 'pilot', 'act']
    L = ['3.8 选工序的图网络（模仿 act-pilot）%s —— 紧空间 U5S6 测试集（各参数组第 8~10 个，训练时未见过）' % (
             '+ 3.9 PPO 微调' if have_ppo else ''),
         '共 %d 例%s' % (len(rows), '' if len(rows) == 612 else '（还没跑全）'),
         'net = 只用网络逐道选工序（不推演）；net_top2 = 只推演网络排前 2 的候选；act = 老师 act-pilot（推演全部候选）']
    if have_ppo:
        L.append('ppo_ 前缀 = 同一网络再用 PPO 微调之后')
    L += ['', '一、相对下界差距 (工期−LB)/LB（越小越好；LB 不含空间约束）',
          '%-6s' % '集合' + ''.join('%13s' % c for c in cols)]
    for s in SETS + ['ALL']:
        x = [r for r in rows if s == 'ALL' or r['set'] == s]
        if x:
            L.append('%-6s' % s + ''.join('%12.2f%%' % (100 * np.mean([r[c] / r['LB'] - 1 for r in x])) for c in cols))
    L += ['', '二、逐例比较：平均缩短（逐例 (对照−方法)/对照 的平均）、平均少几天、更好/持平/更差']
    pairs = [('net', 'LFT'), ('net', 'DQN'), ('net_top2', 'LFT'), ('net_top2', 'guided3'),
             ('net_top2', 'pilot'), ('net', 'act'), ('net_top2', 'act')]
    if have_ppo:
        pairs += [('ppo_net', 'LFT'), ('ppo_net', 'net'), ('ppo_net_top2', 'net_top2'), ('ppo_net_top2', 'pilot'),
                  ('ppo_net', 'act'), ('ppo_net_top2', 'act')]
    for c, b in pairs:
        d = np.array([r[b] - r[c] for r in rows])
        red = 100 * np.mean([(r[b] - r[c]) / r[b] for r in rows])
        L.append('  %-13s 对 %-9s 缩短 %6.2f%%  平均少 %5.1f 天  %3d / %3d / %3d' % (
            c, b, red, d.mean(), (d > 0).sum(), (d == 0).sum(), (d < 0).sum()))
    tc = ['net', 'net_top2'] + (['ppo_net', 'ppo_net_top2'] if have_ppo else []) + ['pilot', 'act']
    L += ['', '三、单例平均耗时（秒；net 系列为本机多进程并行时测得，pilot/act 为此前测得，只宜看量级）',
          '%-6s' % '集合' + ''.join('%14s' % c for c in tc)]
    for s in SETS:
        x = [r for r in rows if r['set'] == s]
        if x:
            L.append('%-6s' % s + ''.join('%14.3f' % np.mean([r[c + '_s'] for r in x]) for c in tc))
    L.append('违约数（check 复核紧前/资源/边界/三维不重叠）：%d' % sum(r['viol'] for r in rows))
    if os.path.exists(CKPT):
        _, st = load_best()
        if 'ref_hit' in st:
            L += ['', '参照（训练集）：总选 LFT 首选 命中老师最优 %.1f%%；随机选 命中 %.1f%%' % (
                100 * st['ref_hit'][0], 100 * st['ref_hit'][1])]
        L += ['', '模仿训练曲线（验证 = 验证集半集上只用网络的平均 工期/CPM）：']
        for ep, loss, hit, v in st['curve']:
            L.append('  epoch %2d  loss %.4f  选中老师最优 %.1f%%  验证 %.4f' % (ep, loss, 100 * hit, v))
        L.append('测试用验证最好的参数（%.4f）' % st['best_val'])
    if have_ppo and os.path.exists(ckpt_of('ppo')):
        _, st = load_best(ckpt_of('ppo'))
        L += ['', 'PPO 微调曲线（采样平均 = 本轮采样轨迹的平均 工期/CPM；验证 = 验证集半集上只用网络）：']
        for it, ms, v in st['curve']:
            L.append('  iter %4d  采样平均 %.4f  验证 %s' % (it, ms, '%.4f' % v if v is not None else '-'))
        L.append('测试用验证最好的参数（%.4f）' % st['best_val'])
    txt = '\n'.join(L)
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, '结果报告.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    with open(os.path.join(OUT, '测试集逐例结果.csv'), 'w', encoding='utf-8-sig', newline='') as fh:
        keys = ['set', 'instance', 'LB'] + cols + [c + '_s' for c in tc] + ['viol']
        w = csv.DictWriter(fh, keys, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)
    print(txt)


RUNS = [('base', '3.8 原训练集，4 类边（已有结果）'),
        ('aug', '1.6 训练集翻倍，4 类边'),
        ('aug_nosp', '3.6 训练集翻倍，去掉空间不相容边'),
        ('aug_nors', '3.6 训练集翻倍，去掉资源不相容边')]


def _run_paths(name):
    if name == 'base':
        return os.path.join(OUT, 'act_ckpt.pt'), os.path.join(OUT, '_eval')
    d = os.path.join(OUT, 'runs', name)
    return os.path.join(d, 'act_ckpt.pt'), os.path.join(d, '_eval')


def _boot_ci(x, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return np.percentile(m, 2.5), np.percentile(m, 97.5)


def merge_runs():
    """1.6（训练集翻倍）和 3.6（去掉空间边 / 资源边）各变体在测试集 612 例上的对比"""
    torch = T_()
    base = {}
    with open(os.path.join(A.OUT, '612例逐例结果.csv'), encoding='utf-8-sig') as fh:
        for row in csv.DictReader(fh):
            base[row['instance']] = row
    res, info = {}, {}
    for name, desc in RUNS:
        ck, ev = _run_paths(name)
        r = {}
        for f in glob.glob(os.path.join(ev, '*.pkl')):
            with open(f, 'rb') as fh:
                r[os.path.splitext(os.path.basename(f))[0]] = pickle.load(fh)
        if r:
            res[name] = r
        if os.path.exists(ck):
            st = torch.load(ck, map_location='cpu', weights_only=False)
            cur = st['curve']
            be = min(cur, key=lambda x: x[3])
            info[name] = {'n': st.get('n_samples'), 'best_ep': be[0], 'best_val': st['best_val'],
                          'hit_last': cur[-1][2], 'epochs': len(cur), 'curve': cur}
    names = [n for n, _ in RUNS if n in res]
    common = [x for x in set.intersection(*[set(res[n]) for n in names]) if x in base]
    common.sort(key=lambda x: (SETS.index(base[x]['set']), x))
    L = ['1.6 扩充训练算例 + 3.6 消融 —— 选工序网络（模仿 act-pilot），紧空间 U5S6 测试集（各参数组第 8~10 个）',
         '共同评估的算例 %d 个%s' % (len(common), '' if len(common) == 612 else '（还没跑全）'),
         'net = 只用网络，不推演；net_top2 = 只推演网络排前 2 的候选。测试集和验证集在所有变体中完全相同。', '']
    L.append('变体：')
    for n, desc in RUNS:
        if n in names:
            x = info.get(n, {})
            L.append('  %-9s %s；训练样本 %s，最好验证 %.4f（第 %s 轮），末轮训练命中 %.1f%%，违约 %d' % (
                n, desc, x.get('n', '?'), x.get('best_val', float('nan')), x.get('best_ep', '?'),
                100 * x.get('hit_last', float('nan')), sum(res[n][k]['viol'] for k in common)))
    for mode in ('net', 'net_top2'):
        L += ['', '一、%s 相对下界差距 (工期−LB)/LB（越小越好）' % mode,
              '%-6s' % '集合' + '%11s' % 'LFT' + ''.join('%11s' % n for n in names) + '%11s' % 'act']
        for s in SETS + ['ALL']:
            x = [k for k in common if s == 'ALL' or base[k]['set'] == s]
            if not x:
                continue
            lb = np.array([float(base[k]['LB']) for k in x])
            row = '%-6s' % s + '%10.2f%%' % (100 * np.mean(np.array([float(base[k]['LFT']) for k in x]) / lb - 1))
            for n in names:
                row += '%10.2f%%' % (100 * np.mean(np.array([res[n][k][mode] for k in x]) / lb - 1))
            row += '%10.2f%%' % (100 * np.mean(np.array([float(base[k]['act']) for k in x]) / lb - 1))
            L.append(row)
    L += ['', '二、逐例比较：平均缩短（逐例 (对照−方法)/对照）、95% 自助法置信区间、更好/持平/更差']

    def cmp(a_ms, b_ms, la, lb_):
        a_ms, b_ms = np.asarray(a_ms, float), np.asarray(b_ms, float)
        red = (b_ms - a_ms) / b_ms
        lo, hi = _boot_ci(red)
        d = b_ms - a_ms
        L.append('  %-20s 对 %-20s 缩短 %6.2f%%  [%6.2f%%, %6.2f%%]  %3d / %3d / %3d' % (
            la, lb_, 100 * red.mean(), 100 * lo, 100 * hi, (d > 0).sum(), (d == 0).sum(), (d < 0).sum()))
    lft = [float(base[k]['LFT']) for k in common]
    for mode in ('net', 'net_top2'):
        for n in names:
            cmp([res[n][k][mode] for k in common], lft, '%s.%s' % (n, mode), 'LFT')
    for mode in ('net', 'net_top2'):
        g = lambda n: [res[n][k][mode] for k in common]
        if 'base' in names and 'aug' in names:
            cmp(g('aug'), g('base'), 'aug.' + mode, 'base.' + mode)
        for n in ('aug_nosp', 'aug_nors'):
            if n in names and 'aug' in names:
                cmp(g('aug'), g(n), 'aug.' + mode, n + '.' + mode)
    L += ['', '读法：区间不含 0 才算有把握的差别；“aug 对 aug_nosp 缩短 x%”为正，说明空间边有用。']
    L += ['', '三、训练曲线（每轮：loss / 训练命中老师最优 / 验证 工期/CPM）']
    for n in names:
        if n in info:
            L.append('  ' + n + '：' + '  '.join('%d:%.3f/%.0f%%/%.4f' % (e, lo_, 100 * h, v)
                                                 for e, lo_, h, v in info[n]['curve']))
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '1.6与3.6对比.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    with open(os.path.join(OUT, '1.6与3.6逐例结果.csv'), 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['set', 'instance', 'LB', 'LFT', 'act'] + ['%s_%s' % (n, m) for n in names for m in ('net', 'net_top2')])
        for k in common:
            w.writerow([base[k]['set'], k, base[k]['LB'], base[k]['LFT'], base[k]['act']] +
                       [res[n][k][m] for n in names for m in ('net', 'net_top2')])
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--label', type=str)
    ap.add_argument('--label-pool', action='store_true')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--workers', type=int, default=0)
    ap.add_argument('--epochs', type=int, default=0)
    ap.add_argument('--hidden', type=int, default=128)
    ap.add_argument('--layers', type=int, default=4)
    ap.add_argument('--batch', type=int, default=128)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--dropout', type=float, default=0.1)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--eval', type=str)
    ap.add_argument('--eval-pool', action='store_true')
    ap.add_argument('--tag', type=str, default='bc', help='评估哪个网络：bc（3.8 模仿）或 ppo（3.9）')
    ap.add_argument('--merge', action='store_true')
    ap.add_argument('--aug', action='store_true', help='1.6：打标签/训练时加入扩充算例')
    ap.add_argument('--drop-edges', type=str, default='', help='3.6 消融：去掉的边，如 sp 或 sp,rs')
    ap.add_argument('--seed', type=int, default=None)
    ap.add_argument('--merge-runs', action='store_true', help='汇总 1.6/3.6 各变体')
    a = ap.parse_args()
    drop = tuple(sorted(ETYPES[x] for x in a.drop_edges.split(',') if x))
    if a.label:
        label_part(a.label, a.budget, a.aug)
    if a.label_pool:
        label_pool(a.workers, a.aug)
    if a.epochs:
        train_epochs(a.epochs, a.hidden, a.layers, a.batch, a.lr, a.dropout, a.limit, a.aug, drop, a.seed)
    if a.eval:
        eval_part(a.eval, a.budget, a.tag)
    if a.eval_pool:
        eval_pool(a.workers, a.tag)
    if a.merge:
        merge()
    if a.merge_runs:
        merge_runs()
