# -*- coding: utf-8 -*-
"""
place_probe.py —— 位置选择探针：CP-SAT 的优势如果来自“箱子放哪”，那在推演里多试几个位置应该有效。
act1     = 现有 act-1：候选工序同 act-pilot，位置固定用 S4（z→y→x 第一个可行贴边坐标），每个候选 LFT 推演 1 次。
act1pos  = 候选 = (工序, 位置)：每道候选工序再给最多 6 个位置（按 6 种坐标轴优先顺序各取第一个可行贴边坐标，去重），
           每个 (工序, 位置) LFT 推演 1 次。后续推演里的位置仍用 S4。
用法：python3 place_probe.py --set j30 --part k/n [--budget 140] ；--merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A
import act1 as A1
import cpsat3d as C

NA = len(rl_env.ACTIONS)
LFT = rl_env.ACTIONS.index('LFT')
OUT = os.path.join(C.OUT, '_place_probe')
PERMS = list(itertools.permutations((0, 1, 2)))     # 坐标轴优先顺序：(2,1,0)=先 z 再 y 再 x，即 S4 的顺序


def positions(I, env, j):
    l, w, h = I.dim[j]
    boxes = list(env.boxes.values())
    cs = [sorted({0} | {b[a] + b[a + 3] for b in boxes}) for a in range(3)]
    feas = [(x, y, z) for x in cs[0] if x + l <= I.L for y in cs[1] if y + w <= I.W for z in cs[2]
            if z + h <= I.H and sd.fits(x, y, z, l, w, h, boxes, I.L, I.W, I.H)]
    out = []
    for p in [(2, 1, 0)] + [q for q in PERMS if q != (2, 1, 0)]:
        if feas:
            best = min(feas, key=lambda c: tuple(c[a] for a in p))
            if best not in out:
                out.append(best)
    return out


def run_act1pos(I):
    env = rl_env.Env(I)
    env.reset()
    while not env.done:
        while True:
            ok = {}
            for j in env.elig:
                f, pos = A.place(env, j)
                if f:
                    ok[j] = pos
            if not ok:
                break
            cand = []
            for a in range(NA):
                key = env.keys[rl_env.ACTIONS[a]]
                j = min(ok, key=lambda x: key[x])
                if j not in cand:
                    cand.append(j)
            opts = []
            for j in cand:
                if I.d[j] > 0 and I.vol[j] > 0:
                    opts += [(j, p) for p in positions(I, env, j)]
                else:
                    opts.append((j, None))
            if len(opts) == 1:
                best = opts[0]
            else:
                best, bv = None, None
                for (j, p) in opts:
                    e = env.clone()
                    e._start(j, p)
                    v = A.rollout_from(e, LFT)
                    if bv is None or v < bv:
                        best, bv = (j, p), v
            env._start(best[0], best[1])
        env._advance()
        env._to_decision(rl_env.ACTIONS[LFT])
    return env.makespan(), env.S, env.F, env.P


def run_part(sets, part, budget):
    import train_dqn as T
    os.makedirs(OUT, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(OUT, '*.pkl')))
    tasks = [t for t in T.list_instances()['test'] if t[0] in sets and t[1] not in have][k::n]
    t0 = time.time()
    done = 0
    for s_, nm, f in tasks:
        if time.time() - t0 > budget:
            break
        I = sd.load_instance(f)
        t1 = time.time()
        a1 = A1.run_act1(I)[0]
        ta = time.time() - t1
        ms, S, F, P = run_act1pos(I)
        tp = time.time() - t1 - ta
        viol = sum(sd.check(I, S, F, P, space=True).values())
        with open(os.path.join(OUT, nm + '.pkl'), 'wb') as fh:
            pickle.dump({'set': s_, 'act1': a1, 'act1pos': ms, 't_act1': ta, 't_pos': tp, 'viol': viol}, fh)
        done += 1
    print('place %s: 本次 %d，剩 %d，%.0fs' % (part, done, len(tasks) - done, time.time() - t0), flush=True)


def merge():
    base = C.load_base()
    cp = {}
    for f in glob.glob(os.path.join(C.CACHE, '*.pkl')):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        cp[r['name']] = r['ms']
    rows = {}
    for f in glob.glob(os.path.join(OUT, '*.pkl')):
        nm = os.path.splitext(os.path.basename(f))[0]
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        r.update({'LFT': float(base[nm]['LFT']), 'act': float(base[nm]['act']), 'cp': cp.get(nm)})
        rows[nm] = r
    for s_ in C.SETS + ['ALL']:
        sel = [r for n, r in rows.items() if s_ == 'ALL' or r['set'] == s_]
        if not sel:
            continue
        red = lambda c: 100 * np.mean([(r['LFT'] - r[c]) / r['LFT'] for r in sel])
        x = np.array([(r['act1'] - r['act1pos']) / r['act1'] for r in sel])
        y = np.array([(r['act'] - r['act1pos']) / r['act'] for r in sel])
        sc = [r for r in sel if r['cp'] is not None]
        print('%-5s n=%3d  对LFT缩短: act1 %.2f%%  act1pos %.2f%%  act %.2f%%  CP %.2f%% | act1pos 对 act1 %.2f%% (%d/%d/%d)'
              ' 对 act %.2f%% (%d/%d/%d) | 秒/例 act1 %.2f pos %.2f | 违约 %d' % (
                  s_, len(sel), red('act1'), red('act1pos'), red('act'),
                  100 * np.mean([(r['LFT'] - r['cp']) / r['LFT'] for r in sc]) if sc else float('nan'),
                  100 * x.mean(), (x > 1e-9).sum(), (abs(x) <= 1e-9).sum(), (x < -1e-9).sum(),
                  100 * y.mean(), (y > 1e-9).sum(), (abs(y) <= 1e-9).sum(), (y < -1e-9).sum(),
                  np.mean([r['t_act1'] for r in sel]), np.mean([r['t_pos'] for r in sel]),
                  sum(r['viol'] for r in sel)))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--set', default='j30')
    ap.add_argument('--part')
    ap.add_argument('--budget', type=float, default=140)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.set.split(','), a.part, a.budget)
    if a.merge:
        merge()
