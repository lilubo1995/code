# -*- coding: utf-8 -*-
"""
act1.py —— 便宜推演 act-1：和 act-pilot 同样逐道决策、同样的候选，
但每个候选只用 LFT 推演 1 次（act-pilot 是 10 条规则各推演 1 次取最短）。不用神经网络。
作用：网络“加速”这条线的目标线——网络要有价值，得在同样耗时下比它短。

用法：python3 act1.py --part k/n [--budget 150]   VM 分块跑测试集 612 例（缓存每例一个文件，已有的跳过）
      python3 act1.py --merge                    汇总（对 LFT / net / net_top2 / pilot / act-pilot）
"""
import os
import sys
import csv
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A

ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, '06_实验结果', '便宜推演_act1')
CACHE = os.path.join(OUT, '_cache')
NET_EVD = os.path.join(ROOT, '06_实验结果', '选工序网络', '_eval')
NA = len(rl_env.ACTIONS)
LFT = rl_env.ACTIONS.index('LFT')
SETS = ['j30', 'j60', 'j90', 'j120']


def run_act1(I, rule=LFT):
    """逐道决策：候选同 act-pilot；每个候选“先开它，再用 rule 排到底”，开工期最短的（并列取候选顺序靠前的）"""
    env = rl_env.Env(I)
    env.reset()
    n_sub = 0
    while not env.done:
        while True:
            ok = {}
            for j in env.elig:
                f, pos = A.place(env, j)
                if f:
                    ok[j] = pos
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = []
            for a in range(NA):
                key = env.keys[rl_env.ACTIONS[a]]
                j = min(ok, key=lambda x: key[x])
                if j not in cand:
                    cand.append(j)
            best_j, best_v = None, None
            if len(cand) == 1:
                best_j = cand[0]
            else:
                for j in cand:
                    e = env.clone()
                    e._start(j, ok[j])
                    v = A.rollout_from(e, rule)
                    if best_v is None or v < best_v:
                        best_j, best_v = j, v
                n_sub += 1
            env._start(best_j, ok[best_j])
        env._advance()
        env._to_decision(rl_env.ACTIONS[LFT])
    return env.makespan(), env.S, env.F, env.P, n_sub


def test_tasks():
    import train_dqn as T
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(CACHE, '*.pkl')))
    tasks = [x for x in T.list_instances()['test'] if x[1] not in have]
    tasks.sort(key=lambda x: -int(x[0][1:]))
    return tasks, len(have)


def run_one(task):
    s, name, f = task
    I = sd.load_instance(f)
    t0 = time.time()
    ms, S, F, P, nd = run_act1(I)
    dt = time.time() - t0
    viol = sum(sd.check(I, S, F, P, space=True).values())
    r = {'set': s, 'act1': ms, 'act1_s': dt, 'n_dec': nd, 'viol': viol}
    path = os.path.join(CACHE, name + '.pkl')
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(r, fh)
    os.replace(path + '.tmp', path)
    return name, r


def run_part(part, budget):
    os.makedirs(CACHE, exist_ok=True)
    k, n = (int(x) for x in part.split('/'))
    tasks, nh = test_tasks()
    tasks = tasks[k::n]
    t00 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t00 > budget:
            break
        run_one(t)
        done += 1
    print('act1 %s: 本次 %d 例，剩 %d 例（之前已有 %d），%.0fs' % (part, done, len(tasks) - done, nh,
                                                       time.time() - t00), flush=True)


def _boot_ci(x, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return np.percentile(m, 2.5), np.percentile(m, 97.5)


def merge():
    base = {}
    with open(os.path.join(A.OUT, '612例逐例结果.csv'), encoding='utf-8-sig') as fh:
        for row in csv.DictReader(fh):
            base[row['instance']] = row
    rows = {}
    for f in glob.glob(os.path.join(CACHE, '*.pkl')):
        nm = os.path.splitext(os.path.basename(f))[0]
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        nf = os.path.join(NET_EVD, nm + '.pkl')
        if nm not in base or not os.path.exists(nf):
            continue
        with open(nf, 'rb') as fh:
            ne = pickle.load(fh)
        b = base[nm]
        rows[nm] = {'set': r['set'], 'LB': float(b['LB']), 'LFT': float(b['LFT']), 'net': ne['net'],
                    'act1': r['act1'], 'net_top2': ne['net_top2'], 'pilot': float(b['pilot']),
                    'act': float(b['act']), 'act1_s': r['act1_s'], 'n_dec': r['n_dec'], 'viol': r['viol']}
    names = sorted(rows)
    cols = ['LFT', 'net', 'act1', 'net_top2', 'pilot', 'act']
    L = ['便宜推演 act-1 —— 紧空间 U5S6 测试集（各参数组第 8~10 个），共 %d 例' % len(names),
         'act1 = 与 act-pilot 同样逐道决策、同样候选，每个候选只用 LFT 推演 1 次（act-pilot 每个候选推演 10 次）；不用神经网络。',
         'net = 选工序网络（3.8）只用网络；net_top2 = 只推演网络排前 2 的候选；act = act-pilot。', '',
         '一、相对下界差距 (工期−LB)/LB（越小越好）',
         '%-6s' % '集合' + ''.join('%11s' % c for c in cols)]
    for s in SETS + ['ALL']:
        sel = [n for n in names if s == 'ALL' or rows[n]['set'] == s]
        if not sel:
            continue
        L.append('%-6s' % s + ''.join('%10.2f%%' % (100 * np.mean([(rows[n][c] - rows[n]['LB']) / rows[n]['LB']
                                                                     for n in sel])) for c in cols))
    L += ['', '二、逐例比较：平均缩短（逐例 (对照−方法)/对照）、95% 自助法置信区间、更好/持平/更差']
    for m, ref in (('act1', 'LFT'), ('net', 'LFT'), ('act1', 'net'), ('act1', 'pilot'), ('act1', 'net_top2'),
                   ('act1', 'act')):
        x = np.array([(rows[n][ref] - rows[n][m]) / rows[n][ref] for n in names])
        lo, hi = _boot_ci(x)
        L.append('  %-6s 对 %-9s 缩短 %6.2f%%  [%6.2f%%, %6.2f%%]  %3d / %3d / %3d' % (
            m, ref, 100 * x.mean(), 100 * lo, 100 * hi, (x > 1e-9).sum(), (np.abs(x) <= 1e-9).sum(),
            (x < -1e-9).sum()))
    L += ['', '三、act1 每例耗时（VM 单进程）与逐道决策次数']
    for s in SETS:
        sel = [n for n in names if rows[n]['set'] == s]
        if sel:
            L.append('  %-5s %.2f s/例   决策 %.0f 次/例' % (s, np.mean([rows[n]['act1_s'] for n in sel]),
                                                          np.mean([rows[n]['n_dec'] for n in sel])))
    L.append('  对照（VM 单进程，见总结 6.7）：j120 net 0.13 s / net_top2 4.2 s / pilot 2.4 s / act-pilot 5.4 s')
    L.append('  违约数：%d' % sum(rows[n]['viol'] for n in names))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(OUT, '汇总.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    with open(os.path.join(OUT, '逐例结果.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        keys = ['set', 'LB'] + cols + ['act1_s', 'n_dec', 'viol']
        w.writerow(['instance'] + keys)
        for n in names:
            w.writerow([n] + [rows[n][k] for k in keys])
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.part:
        run_part(a.part, a.budget)
    if a.merge:
        merge()
