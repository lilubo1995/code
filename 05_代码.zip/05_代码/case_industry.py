# -*- coding: utf-8 -*-
"""
case_industry.py —— 复现第四章表4-4（飞机部段装配案例）和表4-5（船舶分段建造案例）。

做法：读入 03_算例 下的案例文件，把场地长宽高改成表中的各个尺寸，然后依次计算
  传统执行   = 按 LFT 纸面计划（不管空间）开工，场地放不下就往后推（sched3d.reactive）
  本方案     = 全坐标放置 + 按工序沙盒推演 act-pilot + 前后向改进 FBI（与平台“致优版”相同）
  精确求解器 = CP-SAT（可选，需要 ortools；用 --cpsat 秒数 打开，不打开只算前两项）

用法（在 05_代码 目录下）：
  python case_industry.py                     # 两个案例、全部尺寸，不跑 CP-SAT（约 10 秒）
  python case_industry.py --case aircraft     # 只算飞机案例
  python case_industry.py --cpsat 100         # 再加 CP-SAT，每个尺寸限时 100 秒

数据来源：
  飞机部段案例：西安某航空装备制造企业的实测数据（团队整理为 .sm 格式）
  船舶分段案例：挑战杯文稿第二章以上海某集装箱船为例构造的典型分段划分，不是企业实测记录
"""
import os
import sys
import time
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd        # noqa: E402
import act_pilot as A       # noqa: E402
import fbi_probe as FB      # noqa: E402

ROOT = os.path.dirname(HERE)
CASES = {
    'aircraft': ('飞机部段装配案例（表4-4）', os.path.join(ROOT, '03_算例', '飞机部段案例', 'aircraft_40x30x12.sm'),
                 [(40, 30, 12), (16, 12, 5), (14, 10, 5)]),
    'ship': ('船舶分段建造案例（表4-5）', os.path.join(ROOT, '03_算例', '船舶分段案例', 'ship_120x60x20.sm'),
             [(120, 60, 20), (100, 40, 15), (90, 30, 15), (85, 25, 15)]),
}


def run_size(path, L, W, H, cp_seconds=0):
    I = sd.load_instance(path)
    I.L, I.W, I.H = L, W, H
    sd.prep(I)
    S0, F0, P0, order, _ = sd.Scheduler(I, 'LFT', None).run()          # 传统纸面计划
    S1, F1, P1, st = sd.reactive(I, S0, order)                         # 传统执行
    t0 = time.time()
    _, S2, F2, P2, _ = A.run_act_pilot(I)                              # 按工序沙盒推演
    _, ms, best, _ = FB.fbi(I, S2, F2, P2)                             # 前后向改进
    sec = time.time() - t0
    viol = sum(sd.check(I, best[1], best[2], best[3], space=True).values())
    row = {'plan': max(F0), 'react': max(F1), 'first_conf': st.get('first_conf'),
           'space_conf': st['space_conf'], 'delayed': st['delayed'], 'ours': ms, 'sec': sec, 'viol': viol}
    if cp_seconds > 0:
        import cpsat3d as C
        r = C.solve(I, tl=cp_seconds, workers=8, hint=(best[1], best[3]), ub=ms)
        row['cp'] = '%s/%s（%s）' % (r.get('ms'), r.get('bound'), r.get('status'))
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--case', choices=['aircraft', 'ship', 'all'], default='all')
    ap.add_argument('--cpsat', type=float, default=0, help='CP-SAT 每个尺寸的限时（秒），0=不跑')
    a = ap.parse_args()
    for key in (['aircraft', 'ship'] if a.case == 'all' else [a.case]):
        title, path, sizes = CASES[key]
        print('\n== %s  %s' % (title, os.path.relpath(path, ROOT)))
        print('场地尺寸      纸面计划 传统执行 首次冲突日 冲突次数 推迟工序  本方案 缩短   违约 用时' +
              ('  CP-SAT 最好解/下界' if a.cpsat else ''))
        for L, W, H in sizes:
            r = run_size(path, L, W, H, a.cpsat)
            red = (r['react'] - r['ours']) / r['react'] * 100
            fc = '-' if r['first_conf'] is None else '第%d天' % r['first_conf']
            print('%-12s %6d %8d %10s %8d %8d %7d %5.1f%% %4d %4.1fs' % (
                '%d×%d×%d' % (L, W, H), r['plan'], r['react'], fc, r['space_conf'], r['delayed'],
                r['ours'], red, r['viol'], r['sec']) + ('  ' + r['cp'] if 'cp' in r else ''), flush=True)


if __name__ == '__main__':
    main()
