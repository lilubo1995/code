# -*- coding: utf-8 -*-
"""
sched3d.py —— 三维空间受限项目调度（3D-sRCPSP）：并行调度生成机制 + 空间分配 + 对照实验

依据论文：Zhang, Li, Demeulemeester 等（2024）
  A three-dimensional spatial resource-constrained project scheduling problem: model and heuristic
  （02_论文\\01_2024_三维空间受限项目调度_模型与启发式.pdf，算法见论文 Algorithm 1 与 4.3–4.5 节）

模型口径（与论文一致）：
  * 每个活动占用一个长方体 (l, w, h)，执行期间位置固定，不旋转；场地为 L×W×H。
  * 两个活动只有在“时间重叠且三个坐标轴投影都重叠”时才算空间冲突；时间按半开区间 [s, f)，
    即一个活动在 t 完工后，另一个活动可以在 t 占用同一空间。
  * 箱体不能越出场地边界。论文不考虑重力/支撑，本程序同样不考虑。

空间分配策略：
  S1  论文 Algorithm a：只试放置点集 PP 中排在最前的点，不合适就推迟该活动
  S2  论文 Algorithm b：依次搜索 PP 中所有放置点（PPDGS + PPDSS）
  S3  论文 Algorithm c：S2 + 残余放置点二次分配（RPPSAS）
      （S1–S3 中：本决策时刻试过不合适的点进入 RPP；进入下一个决策时刻时 RPP 并回 PP）
  S4  本项目改进：完整候选坐标 x∈{0}∪{x_i+l_i}，y、z 同理（i 为正在执行的活动）。
      只要当前时刻存在可行位置就一定能找到（任一可行位置可沿 -z、-y、-x 推到这些坐标上）。
对照组：
  RCPSP 同一规则、忽略空间的普通 RCPSP 并行调度 → 工期 Dr，同时作为基准计划 RBSS
  REACT 按 RBSS 执行，遇到时-空冲突被动顺延（开工不早于计划；按计划开工顺序依次尝试，
        排在前面的放不下时，后面放得下的可以先开工；位置用 S4 寻找）→ Dd
        位置用最强的 S4，因此 DM3 是对“事前考虑空间”收益的保守估计。

参考值口径（见 04_PSPLIB参考解\\先读我_文件说明与使用边界.md）：
  PSPLIB 值只针对普通 RCPSP，不含三维空间约束，也没有逐工序开始时间和位置。
  * proven_optimal：普通 RCPSP 已证最优工期，可作为三维问题的放松下界。
  * best_known_upper_bound：只是最好已知上界，不能当作三维问题下界，相对它的差值不能叫“最优性差距”。
  * 下界 LB = max(已证最优值 或 官方下界, 关键路径长度)；相对 LB 的差距是真实最优性差距的上界。
  * 论文的 DM1 = (Ds − Dopt)/Dopt，这里记作 DM1_ref，并单独给出“仅已证最优子集”和“相对下界”两列。

用法：
  python sched3d.py --quick     每个参数组取第 1 个算例（j30/j60/j90 各 48 例，j120 60 例，共 204 例）
  python sched3d.py --full      全部 2040 例
  可选：--sets j30,j60  --procs 4  --limit 10
"""
import os
import sys
import csv
import time
import zlib
import random
import argparse
import traceback
from collections import defaultdict
from multiprocessing import Pool, cpu_count

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT, '03_算例')
REF_CSV = os.path.join(ROOT, '04_PSPLIB参考解', '全部2040例_参考工期与最优性标记.csv')
OUT_ROOT = os.path.join(ROOT, '06_实验结果')
SETS = ['j30', 'j60', 'j90', 'j120']

# 25 条常规资源优先规则（论文表 3）+ 11 条空间规则（论文表 6）
R_RULES = ['MAI', 'SAD', 'MIS', 'MTS', 'GRPW', 'GRPW*', 'EST', 'EFT', 'LST', 'LFT', 'TF',
           'ESTD', 'EFTD', 'LSTD', 'LFTD', 'TFD', 'TCI', 'GRD', 'RRCI', 'WRUP',
           'ACROS', 'ACTRES', 'TIMROS', 'TIMRES', 'RAD']
S_RULES = ['SRCI', 'CI-a', 'CI-b', 'CI-c', 'CI-d', 'CI-e', 'CI-f', 'IC', 'GL', 'GW', 'GH']
RULES = R_RULES + S_RULES
MIN_RULES = {'MAI', 'SAD', 'EST', 'EFT', 'LST', 'LFT', 'TF', 'ESTD', 'EFTD', 'LSTD', 'LFTD', 'TFD'}
DYN_RULES = {'ESTD', 'EFTD', 'LSTD', 'LFTD', 'TFD'}
STRATS = ['S1', 'S2', 'S3', 'S4']
ALL_STRATS = ['RCPSP'] + STRATS + ['REACT']
EPS = 1e-9


# ----------------------------------------------------------------------------------------------
# 1. 读取算例（不写死活动数与行号，j30–j120 通用）
# ----------------------------------------------------------------------------------------------
class Inst(object):
    pass


def _int_row(s):
    toks = s.split()
    if not toks:
        return None
    try:
        return [int(x) for x in toks]
    except ValueError:
        return None


def load_instance(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        lines = f.read().splitlines()
    low = [ln.strip().lower() for ln in lines]
    n = None
    for s in low:
        if s.startswith('jobs (incl'):
            n = int(s.split(':', 1)[1].split()[0])
            break
    if n is None:
        raise ValueError('找不到 jobs 行')

    def find(pred, what):
        for i, s in enumerate(low):
            if pred(s):
                return i
        raise ValueError('缺少段落: ' + what)

    def rows_after(i0, count, what):
        out = []
        i = i0 + 1
        while len(out) < count:
            if i >= len(lines):
                raise ValueError('段落行数不足: ' + what)
            row = _int_row(lines[i])
            if row is not None:
                out.append(row)
            elif out:
                raise ValueError('段落 %s 在第 %d 行中断' % (what, i + 1))
            i += 1
        return out

    prec = rows_after(find(lambda s: s.startswith('precedence relations'), 'precedence'), n, 'precedence')
    req = rows_after(find(lambda s: s.startswith('requests/durations'), 'requests'), n, 'requests')
    ra = rows_after(find(lambda s: s.startswith('resourceavailabilities'), 'resources'), 1, 'resources')[0]
    sp = rows_after(find(lambda s: s == 'space', 'space'), n, 'space')
    mx = rows_after(find(lambda s: s == 'maxspace', 'maxspace'), 1, 'maxspace')[0]

    I = Inst()
    I.path = path
    I.name = os.path.splitext(os.path.basename(path))[0]
    I.n = n
    I.K = len(ra)
    I.R = ra
    I.succ = [[] for _ in range(n)]
    I.pred = [[] for _ in range(n)]
    I.d = [None] * n
    I.r = [None] * n
    I.dim = [None] * n
    for row in prec:
        j = row[0] - 1
        ns = row[2]
        ss = row[3:3 + ns]
        if len(ss) != ns:
            raise ValueError('活动 %d 紧后活动数不符' % (j + 1))
        for s in ss:
            I.succ[j].append(s - 1)
            I.pred[s - 1].append(j)
    for row in req:
        j = row[0] - 1
        I.d[j] = row[2]
        I.r[j] = row[3:3 + I.K]
        if len(I.r[j]) != I.K:
            raise ValueError('活动 %d 资源列数不符' % (j + 1))
    for row in sp:
        I.dim[row[0] - 1] = (row[1], row[2], row[3])
    I.L, I.W, I.H = mx[0], mx[1], mx[2]
    for j in range(n):
        if I.d[j] is None or I.dim[j] is None:
            raise ValueError('活动 %d 数据缺失' % (j + 1))
        l, w, h = I.dim[j]
        if l > I.L or w > I.W or h > I.H:
            raise ValueError('活动 %d 尺寸超过场地' % (j + 1))
        for k in range(I.K):
            if I.r[j][k] > I.R[k]:
                raise ValueError('活动 %d 资源需求超过容量' % (j + 1))
    prep(I)
    return I


# ----------------------------------------------------------------------------------------------
# 2. 关键路径与优先规则的静态取值
# ----------------------------------------------------------------------------------------------
def topo_order(I):
    indeg = [len(p) for p in I.pred]
    q = [j for j in range(I.n) if indeg[j] == 0]
    out = []
    while q:
        j = q.pop(0)
        out.append(j)
        for s in I.succ[j]:
            indeg[s] -= 1
            if indeg[s] == 0:
                q.append(s)
    if len(out) != I.n:
        raise ValueError('紧前关系有环')
    return out


def cpm(I, t0=0, S=None, F=None):
    """S/F 给定时为动态版本：已排活动按实际时间，未排活动不早于 t0。"""
    n, d = I.n, I.d
    ES = [0] * n
    EF = [0] * n
    for j in I.topo:
        if S is not None and S[j] is not None:
            ES[j], EF[j] = S[j], F[j]
            continue
        e = t0
        for p in I.pred[j]:
            if EF[p] > e:
                e = EF[p]
        ES[j] = e
        EF[j] = e + d[j]
    T = max(EF)
    LF = [T] * n
    LS = [0] * n
    for j in reversed(I.topo):
        lf = T
        for s in I.succ[j]:
            if LS[s] < lf:
                lf = LS[s]
        LF[j] = lf
        LS[j] = lf - d[j]
    return ES, EF, LS, LF, T


def prep(I):
    n, d, K = I.n, I.d, I.K
    I.topo = topo_order(I)
    I.sink = I.topo[-1]
    ES, EF, LS, LF, T = cpm(I)
    I.cpm = T
    TF = [LS[j] - ES[j] for j in range(n)]
    I.V = I.L * I.W * I.H
    I.vol = [I.dim[j][0] * I.dim[j][1] * I.dim[j][2] for j in range(n)]
    reach = [0] * n                       # 全部后继（位集）
    for j in reversed(I.topo):
        m = 0
        for s in I.succ[j]:
            m |= (1 << s) | reach[s]
        reach[j] = m
    mts = [bin(reach[j]).count('1') for j in range(n)]
    grpws = [d[j] + sum(d[i] for i in range(n) if (reach[j] >> i) & 1) for j in range(n)]
    rrci = [sum(I.r[j][k] / float(I.R[k]) for k in range(K) if I.R[k] > 0) for j in range(n)]
    arc = [0.0] * n
    act = [0.0] * n
    for j in reversed(I.topo):
        arc[j] = rrci[j] + max([arc[s] for s in I.succ[j]] or [0.0])
        act[j] = d[j] * rrci[j] + max([act[s] for s in I.succ[j]] or [0.0])
    src = I.topo[0]
    span = float(LS[I.sink] - LS[src]) or 1.0
    maxtf = max(TF)
    tci = [((maxtf - TF[j]) / float(maxtf)) if maxtf > 0 else 1.0 for j in range(n)]
    srci = [I.vol[j] / float(I.V) for j in range(n)]
    rng = random.Random(zlib.crc32(I.name.encode('utf-8')))
    w = 0.5
    pv = {
        'MAI': list(range(n)),
        'SAD': list(d),
        'MIS': [len(I.succ[j]) for j in range(n)],
        'MTS': mts,
        'GRPW': [d[j] + sum(d[s] for s in I.succ[j]) for j in range(n)],
        'GRPW*': grpws,
        'EST': ES, 'EFT': EF, 'LST': LS, 'LFT': LF, 'TF': TF,
        'TCI': tci,
        'GRD': [d[j] * sum(I.r[j]) for j in range(n)],
        'RRCI': rrci,
        'WRUP': [w * len(I.succ[j]) + (1 - w) * rrci[j] for j in range(n)],
        'ACROS': arc,
        'ACTRES': act,
        'TIMROS': [w * (LS[I.sink] - LS[j]) / span + (1 - w) * arc[j] / (arc[src] or 1.0) for j in range(n)],
        'TIMRES': [w * (LS[I.sink] - LS[j]) / span + (1 - w) * act[j] / (act[src] or 1.0) for j in range(n)],
        'RAD': [rng.random() for _ in range(n)],
        'SRCI': srci,
        'CI-a': [tci[j] * srci[j] for j in range(n)],
        'CI-b': [tci[j] + srci[j] for j in range(n)],
        'CI-c': [tci[j] - srci[j] for j in range(n)],
        'CI-d': [srci[j] - tci[j] for j in range(n)],
        'CI-e': [tci[j] / (srci[j] + EPS) for j in range(n)],
        'CI-f': [srci[j] / (tci[j] + EPS) for j in range(n)],
        'IC': [0.3 * tci[j] + 0.3 * rrci[j] + 0.4 * srci[j] for j in range(n)],   # 论文最优权重 w1=w2=0.3
        'GL': [I.dim[j][0] for j in range(n)],
        'GW': [I.dim[j][1] for j in range(n)],
        'GH': [I.dim[j][2] for j in range(n)],
    }
    I.pv = pv


def sort_eligible(I, rule, elig, t, S, F):
    if rule in DYN_RULES:
        ES, EF, LS, LF, _ = cpm(I, t, S, F)
        if rule == 'ESTD':
            vals = ES
        elif rule == 'EFTD':
            vals = EF
        elif rule == 'LSTD':
            vals = LS
        elif rule == 'LFTD':
            vals = LF
        else:
            vals = [LS[j] - ES[j] for j in range(I.n)]
    else:
        vals = I.pv[rule]
    if rule in MIN_RULES:
        return sorted(elig, key=lambda j: (vals[j], j))
    return sorted(elig, key=lambda j: (-vals[j], j))


# ----------------------------------------------------------------------------------------------
# 3. 空间判断
# ----------------------------------------------------------------------------------------------
def fits(x, y, z, l, w, h, boxes, L, W, H):
    if x + l > L or y + w > W or z + h > H:
        return False
    for bx, by, bz, bl, bw, bh in boxes:
        if x < bx + bl and bx < x + l and y < by + bw and by < y + w and z < bz + bh and bz < z + h:
            return False
    return True


def find_pos_complete(l, w, h, boxes, L, W, H):
    """S4：在完整候选坐标上按 z→y→x 由小到大找第一个可行位置；找不到说明此刻确实放不下。"""
    xs = sorted({0} | {b[0] + b[3] for b in boxes})
    ys = sorted({0} | {b[1] + b[4] for b in boxes})
    zs = sorted({0} | {b[2] + b[5] for b in boxes})
    for z in zs:
        if z + h > H:
            break
        bz = [b for b in boxes if z < b[2] + b[5] and b[2] < z + h]
        for y in ys:
            if y + w > W:
                break
            byz = [b for b in bz if y < b[1] + b[4] and b[1] < y + w]
            for x in xs:
                if x + l > L:
                    break
                for b in byz:
                    if x < b[0] + b[3] and b[0] < x + l:
                        break
                else:
                    return (x, y, z)
    return None


# ----------------------------------------------------------------------------------------------
# 4. 并行调度生成机制（PSGS）
# ----------------------------------------------------------------------------------------------
class Scheduler(object):
    """mode: None=忽略空间(普通RCPSP)；'S1'/'S2'/'S3'=论文放置点策略；'S4'=完整候选坐标"""

    def __init__(self, I, rule, mode):
        self.I, self.rule, self.mode = I, rule, mode

    def run(self):
        I, rule, mode = self.I, self.rule, self.mode
        n, K, d, r, R, dim = I.n, I.K, I.d, I.r, I.R, I.dim
        L, W, H = I.L, I.W, I.H
        paper = mode in ('S1', 'S2', 'S3')
        S = [None] * n
        F = [None] * n
        P = [None] * n
        npred = [len(p) for p in I.pred]
        elig = set(j for j in range(n) if npred[j] == 0)
        active = []
        used = [0] * K
        boxes = {}
        PP = [(0, 0, 0)]
        RPP = []
        inpts = {(0, 0, 0)}           # 当前位于 PP 或 RPP 中的点
        APP = {}                      # 活动 -> 其参考点
        appset = set()
        order = []
        st = {'space_fail': 0, 'retry': 0, 'fallback': 0, 'dp': 0}
        state = {'t': 0, 'remaining': n}

        def needs_space(j):
            return mode is not None and d[j] > 0 and I.vol[j] > 0

        def start(j, pos):
            t = state['t']
            S[j] = t
            F[j] = t + d[j]
            P[j] = pos
            elig.discard(j)
            order.append(j)
            state['remaining'] -= 1
            if d[j] > 0:
                active.append(j)
                rj = r[j]
                for k in range(K):
                    used[k] += rj[k]
                if pos is not None:
                    l, w, h = dim[j]
                    boxes[j] = (pos[0], pos[1], pos[2], l, w, h)
            else:
                for s in I.succ[j]:
                    npred[s] -= 1
                    if npred[s] == 0:
                        elig.add(s)

        def res_ok(j):
            rj = r[j]
            for k in range(K):
                if used[k] + rj[k] > R[k]:
                    return False
            return True

        def add_points(j, p):
            APP[j] = p
            appset.add(p)
            l, w, h = dim[j]
            x, y, z = p
            for q in ((x + l, y, z), (x, y + w, z), (x, y, z + h)):
                if q[0] < L and q[1] < W and q[2] < H and q not in inpts and q not in appset:
                    PP.append(q)
                    inpts.add(q)

        def place_paper(j):
            l, w, h = dim[j]
            bl = list(boxes.values())
            if mode == 'S1':
                if not PP:
                    return None
                p = PP.pop(0)
                if fits(p[0], p[1], p[2], l, w, h, bl, L, W, H):
                    inpts.discard(p)
                    return p
                RPP.append(p)
                return None
            while PP:                                  # PPDSS
                p = PP.pop(0)
                if fits(p[0], p[1], p[2], l, w, h, bl, L, W, H):
                    inpts.discard(p)
                    return p
                RPP.append(p)
            if mode == 'S3':                           # RPPSAS
                for i, p in enumerate(RPP):
                    if fits(p[0], p[1], p[2], l, w, h, bl, L, W, H):
                        RPP.pop(i)
                        inpts.discard(p)
                        return p
            return None

        while state['remaining'] > 0:
            t = state['t']
            # 释放在 t 及以前完工的活动：资源、空间、参考点（PPDGS 场景 2）
            if active:
                keep = []
                for j in active:
                    if F[j] <= t:
                        rj = r[j]
                        for k in range(K):
                            used[k] -= rj[k]
                        boxes.pop(j, None)
                        if j in APP:
                            p = APP.pop(j)
                            appset.discard(p)
                            if p not in inpts:
                                PP.append(p)
                                inpts.add(p)
                        for s in I.succ[j]:
                            npred[s] -= 1
                            if npred[s] == 0:
                                elig.add(s)
                    else:
                        keep.append(j)
                active[:] = keep
            if paper and RPP:
                PP.extend(RPP)
                del RPP[:]
            st['dp'] += 1
            passes = 0
            while True:
                zs = [j for j in elig if d[j] == 0]
                while zs:
                    for j in sorted(zs):
                        start(j, None)
                    zs = [j for j in elig if d[j] == 0]
                if not elig:
                    break
                cand = sort_eligible(I, rule, list(elig), t, S, F)
                if paper:
                    # 论文 Algorithm 1：先按规则顺序挑出满足常规资源的 RE_t，再逐个分配空间
                    avail = [R[k] - used[k] for k in range(K)]
                    RE = []
                    for j in cand:
                        rj = r[j]
                        if all(rj[k] <= avail[k] for k in range(K)):
                            RE.append(j)
                            for k in range(K):
                                avail[k] -= rj[k]
                    for j in RE:
                        if not needs_space(j):
                            start(j, None)
                            continue
                        p = place_paper(j)
                        if p is None:
                            st['space_fail'] += 1          # 进入 TE_t，下个决策时刻再排
                            continue
                        start(j, p)
                        add_points(j, p)
                else:
                    # 资源与空间同时判断：放不下的活动不占资源，后面的活动可以继续用
                    failed = []        # 本时刻已放不下的尺寸；同一时刻箱体只增不减，更大的箱体必然也放不下
                    for j in cand:
                        if not res_ok(j):
                            continue
                        pos = None
                        if needs_space(j):
                            l, w, h = dim[j]
                            if any(l >= a and w >= b and h >= c for a, b, c in failed):
                                pos = None
                            else:
                                pos = find_pos_complete(l, w, h, list(boxes.values()), L, W, H)
                            if pos is None:
                                failed.append((l, w, h))
                                st['space_fail'] += 1
                                continue
                        start(j, pos)
                if active or not elig:
                    break
                # 场地已空、资源全空却一个都没开工：只可能出现在 S1（每个活动只试一个放置点）。
                # 重试会得到同样结果，所以直接把优先级最高的活动放在原点（空场地上必然可行），并计数。
                if not paper:
                    raise RuntimeError('空场地上仍无法开工，数据异常')
                passes += 1
                if passes > 2:
                    raise RuntimeError('空场地兜底失败')
                j = cand[0]
                pos = (0, 0, 0)
                PP[:] = [q for q in PP if q != pos]
                RPP[:] = [q for q in RPP if q != pos]
                inpts.discard(pos)
                st['fallback'] += 1
                start(j, pos)
                add_points(j, pos)
            if state['remaining'] == 0:
                break
            if not active:
                raise RuntimeError('调度停滞')
            state['t'] = min(F[j] for j in active)
        return S, F, P, order, st


# ----------------------------------------------------------------------------------------------
# 5. 忽略空间的计划 + 执行时被动顺延（论文 5.2 节）
# ----------------------------------------------------------------------------------------------
def reactive(I, plan_S, plan_order):
    n, K, d, r, R, dim = I.n, I.K, I.d, I.r, I.R, I.dim
    L, W, H = I.L, I.W, I.H
    rank = [0] * n
    for i, j in enumerate(plan_order):
        rank[j] = i
    S = [None] * n
    F = [None] * n
    P = [None] * n
    npred = [len(p) for p in I.pred]
    elig = set(j for j in range(n) if npred[j] == 0)
    unstarted = set(range(n))
    active = []
    used = [0] * K
    boxes = {}
    st = {'space_conf': 0, 'res_conf': 0, 'delayed': 0}
    t = 0

    def start(j, pos, t):
        S[j] = t
        F[j] = t + d[j]
        P[j] = pos
        elig.discard(j)
        unstarted.discard(j)
        if d[j] > 0:
            active.append(j)
            for k in range(K):
                used[k] += r[j][k]
            if pos is not None:
                boxes[j] = (pos[0], pos[1], pos[2]) + tuple(dim[j])
        else:
            for s in I.succ[j]:
                npred[s] -= 1
                if npred[s] == 0:
                    elig.add(s)

    while unstarted:
        keep = []
        for j in active:
            if F[j] <= t:
                for k in range(K):
                    used[k] -= r[j][k]
                boxes.pop(j, None)
                for s in I.succ[j]:
                    npred[s] -= 1
                    if npred[s] == 0:
                        elig.add(s)
            else:
                keep.append(j)
        active[:] = keep
        zs = [j for j in elig if d[j] == 0 and plan_S[j] <= t]
        while zs:
            for j in sorted(zs):
                start(j, None, t)
            zs = [j for j in elig if d[j] == 0 and plan_S[j] <= t]
        cand = sorted([j for j in elig if plan_S[j] <= t], key=lambda j: (plan_S[j], rank[j]))
        failed = []
        for j in cand:
            if not all(used[k] + r[j][k] <= R[k] for k in range(K)):
                st['res_conf'] += 1
                continue
            pos = None
            if I.vol[j] > 0:
                l, w, h = dim[j]
                if not any(l >= a and w >= b and h >= c for a, b, c in failed):
                    pos = find_pos_complete(l, w, h, list(boxes.values()), L, W, H)
                if pos is None:
                    failed.append((l, w, h))
                    st['space_conf'] += 1
                    st.setdefault('first_conf', t)          # 第一次因空间放不下而顺延的时刻
                    if st['first_conf'] == t:
                        st.setdefault('first_conf_jobs', []).append(j)
                    continue
            start(j, pos, t)
        if not unstarted:
            break
        nxt = [F[j] for j in active] + [plan_S[j] for j in unstarted if plan_S[j] > t]
        if not nxt:
            raise RuntimeError('被动顺延停滞')
        t = min(nxt)
    st['delayed'] = sum(1 for j in range(n) if S[j] > plan_S[j])
    return S, F, P, st


# ----------------------------------------------------------------------------------------------
# 6. 独立的可行性检查（不依赖调度过程，只看结果）
# ----------------------------------------------------------------------------------------------
def check(I, S, F, P, space=True):
    """缺失的活动只计数，其余活动照常检查（便于核查外部程序的不完整结果）。"""
    v = {'missing': 0, 'dur': 0, 'prec': 0, 'res': 0, 'nopos': 0, 'bound': 0, 'overlap': 0}
    n = I.n
    have = [S[j] is not None and F[j] is not None for j in range(n)]
    v['missing'] = sum(1 for j in range(n) if not have[j] and I.d[j] > 0)   # 虚拟起止活动缺失不计
    if not any(have):
        return v
    for j in range(n):
        if not have[j]:
            continue
        if F[j] - S[j] != I.d[j]:
            v['dur'] += 1
        if S[j] < 0:
            v['prec'] += 1
        for p in I.pred[j]:
            if have[p] and S[j] < F[p]:
                v['prec'] += 1
    T = max(F[j] for j in range(n) if have[j])
    for k in range(I.K):
        diff = [0] * (T + 2)
        for j in range(n):
            if have[j] and F[j] > S[j] and I.r[j][k]:
                diff[S[j]] += I.r[j][k]
                diff[F[j]] -= I.r[j][k]
        u = 0
        for x in range(T + 1):
            u += diff[x]
            if u > I.R[k]:
                v['res'] += 1
    if space:
        bx = []
        for j in range(n):
            if have[j] and F[j] > S[j] and I.vol[j] > 0:
                if P[j] is None:
                    v['nopos'] += 1
                    continue
                x, y, z = P[j]
                l, w, h = I.dim[j]
                if x < 0 or y < 0 or z < 0 or x + l > I.L or y + w > I.W or z + h > I.H:
                    v['bound'] += 1
                bx.append((S[j], F[j], x, y, z, l, w, h))
        bx.sort()
        for a in range(len(bx)):
            sa, fa, xa, ya, za, la, wa, ha = bx[a]
            for b in range(a + 1, len(bx)):
                sb, fb, xb, yb, zb, lb, wb, hb = bx[b]
                if sb >= fa:
                    break
                if xa < xb + lb and xb < xa + la and ya < yb + wb and yb < ya + wa and za < zb + hb and zb < za + ha:
                    v['overlap'] += 1
    return v


def peak_volume_ratio(I, S, F):
    T = max(F)
    diff = [0] * (T + 2)
    for j in range(I.n):
        if F[j] > S[j]:
            diff[S[j]] += I.vol[j]
            diff[F[j]] -= I.vol[j]
    u = best = 0
    for x in range(T + 1):
        u += diff[x]
        best = max(best, u)
    return best / float(I.V)


# ----------------------------------------------------------------------------------------------
# 7. 单个算例的全部实验（在子进程里运行）
# ----------------------------------------------------------------------------------------------
def _row(rule, strat, S, F, v, st, ms):
    return {'rule': rule, 'strat': strat, 'mk': max(F), 'viol': sum(v.values()),
            'vdetail': ';'.join('%s=%d' % (k, x) for k, x in v.items() if x),
            'space_fail': st.get('space_fail', 0), 'retry': st.get('retry', 0),
            'fallback': st.get('fallback', 0), 'delayed': st.get('delayed', 0),
            'space_conf': st.get('space_conf', 0), 'res_conf': st.get('res_conf', 0), 'cpu_ms': ms}


def _sched_rows(I, S, F, P):
    out = []
    for j in range(I.n):
        x, y, z = P[j] if P[j] is not None else ('', '', '')
        out.append([j + 1, S[j], F[j], I.d[j], x, y, z] + list(I.dim[j]) + list(I.r[j]))
    return out


def run_instance(task):
    path, set_name, want_sample = task
    name = os.path.splitext(os.path.basename(path))[0]
    try:
        I = load_instance(path)
        real = [j for j in range(I.n) if I.d[j] > 0]
        info = {'n': I.n, 'L': I.L, 'W': I.W, 'H': I.H, 'cpm': I.cpm,
                'vol_ratio': sum(I.vol[j] for j in real) / float(I.V),
                'maxbox_ratio': max(I.vol[j] for j in real) / float(I.V)}
        rows = []
        samples = {}
        for rule in RULES:
            t0 = time.perf_counter()
            S, F, P, order, st = Scheduler(I, rule, None).run()
            v = check(I, S, F, P, space=False)
            rows.append(_row(rule, 'RCPSP', S, F, v, st, (time.perf_counter() - t0) * 1000))
            if rule == 'IC':
                info['peak_vol_IC'] = peak_volume_ratio(I, S, F)
            plan_S, plan_order = S, order
            for m in STRATS:
                t0 = time.perf_counter()
                S2, F2, P2, _, st2 = Scheduler(I, rule, m).run()
                v2 = check(I, S2, F2, P2, space=True)
                rows.append(_row(rule, m, S2, F2, v2, st2, (time.perf_counter() - t0) * 1000))
                if want_sample and rule == 'IC' and m in ('S3', 'S4'):
                    samples['IC_' + m] = _sched_rows(I, S2, F2, P2)
            t0 = time.perf_counter()
            S3, F3, P3, st3 = reactive(I, plan_S, plan_order)
            v3 = check(I, S3, F3, P3, space=True)
            rows.append(_row(rule, 'REACT', S3, F3, v3, st3, (time.perf_counter() - t0) * 1000))
            if want_sample and rule == 'IC':
                samples['IC_REACT'] = _sched_rows(I, S3, F3, P3)
        return {'ok': True, 'set': set_name, 'name': name, 'info': info, 'rows': rows,
                'samples': samples, 'K': I.K}
    except Exception:
        return {'ok': False, 'set': set_name, 'name': name, 'err': traceback.format_exc()}


# ----------------------------------------------------------------------------------------------
# 8. 参考值、任务列表、汇总
# ----------------------------------------------------------------------------------------------
def load_refs():
    refs = {}
    if not os.path.exists(REF_CSV):
        return refs
    with open(REF_CSV, 'r', encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            def num(key):
                s = (row.get(key) or '').strip()
                return int(float(s)) if s else None
            proven = (row.get('is_proven_optimal') or '').strip().lower() == 'true'
            refs[row['instance_name'].strip()] = {
                'ref': num('reference_makespan'), 'type': row.get('reference_type', '').strip(),
                'proven': proven, 'opt': num('optimal_makespan'), 'lb': num('lower_bound'),
                'ub': num('upper_bound')}
    return refs


def list_tasks(sets, quick, limit):
    tasks = []
    for s in sets:
        folder = os.path.join(DATA_DIR, s + '_integer')
        if not os.path.isdir(folder):
            continue
        items = []
        for fn in os.listdir(folder):
            if not fn.lower().endswith('.sm'):
                continue
            stem = os.path.splitext(fn)[0]
            try:
                g, i = stem[len(s):].split('_')
                items.append((int(g), int(i), fn))
            except ValueError:
                continue
        items.sort()
        if quick:
            items = [x for x in items if x[1] == 1]
        if limit:
            items = items[:limit]
        for k, (g, i, fn) in enumerate(items):
            tasks.append((os.path.join(folder, fn), s, k == 0))
    return tasks


def mean(xs):
    return sum(xs) / float(len(xs)) if xs else float('nan')


def pct(x):
    return '   -   ' if x != x else '%6.2f%%' % (100.0 * x)


def write_outputs(out_dir, results, refs, meta, log):
    ok = [x for x in results if x['ok']]
    bad = [x for x in results if not x['ok']]
    ok.sort(key=lambda x: (SETS.index(x['set']), x['name']))
    info = {}
    setof = {}
    ms = {}
    rowmap = {}
    for x in ok:
        info[x['name']] = x['info']
        setof[x['name']] = x['set']
        for rw in x['rows']:
            key = (x['name'], rw['rule'], rw['strat'])
            ms[key] = rw['mk']
            rowmap[key] = rw

    def refinfo(name):
        rf = refs.get(name)
        cp = info[name]['cpm']
        if rf is None or rf['ref'] is None:
            return None, False, cp
        lb = rf['opt'] if rf['proven'] else rf['lb']
        return rf['ref'], rf['proven'], (max(lb, cp) if lb is not None else cp)

    # ---- runs.csv
    with open(os.path.join(out_dir, 'runs.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['set', 'instance', 'rule', 'strategy', 'makespan', 'ref', 'ref_proven_opt', 'LB',
                     'DM1_ref', 'gap_LB', 'violations', 'viol_detail', 'space_fail', 'retry', 'fallback',
                     'delayed', 'space_conf', 'res_conf', 'cpu_ms'])
        for x in ok:
            ref, proven, lb = refinfo(x['name'])
            for rw in x['rows']:
                mk = rw['mk']
                wr.writerow([x['set'], x['name'], rw['rule'], rw['strat'], mk,
                             ref if ref is not None else '', int(proven), lb,
                             '%.6f' % ((mk - ref) / float(ref)) if ref else '',
                             '%.6f' % ((mk - lb) / float(lb)),
                             rw['viol'], rw['vdetail'], rw['space_fail'], rw['retry'], rw['fallback'],
                             rw['delayed'], rw['space_conf'], rw['res_conf'], '%.2f' % rw['cpu_ms']])

    # ---- 样例调度
    for x in ok:
        for tag, rows in x.get('samples', {}).items():
            fn = os.path.join(out_dir, '样例调度_%s_%s.csv' % (x['name'], tag))
            with open(fn, 'w', encoding='utf-8-sig', newline='') as f:
                wr = csv.writer(f)
                wr.writerow(['activity', 'start', 'finish', 'duration', 'x', 'y', 'z', 'l', 'w', 'h'] +
                            ['R%d' % (k + 1) for k in range(x['K'])])
                wr.writerows(rows)

    names_by_set = defaultdict(list)
    for x in ok:
        names_by_set[x['set']].append(x['name'])
    sets = [s for s in SETS if names_by_set[s]]

    def best(name, strat):
        return min(ms[(name, rl, strat)] for rl in RULES)

    # ---- instances.csv
    with open(os.path.join(out_dir, 'instances.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['set', 'instance', 'jobs', 'L', 'W', 'H', 'vol_ratio', 'maxbox_ratio', 'peak_vol_ratio_IC',
                     'CPM', 'ref', 'ref_proven_opt', 'LB'] + ['best_' + s for s in ALL_STRATS] + ['best_rules_S4'])
        for x in ok:
            nm = x['name']
            ref, proven, lb = refinfo(nm)
            it = info[nm]
            b4 = best(nm, 'S4')
            wr.writerow([x['set'], nm, it['n'], it['L'], it['W'], it['H'], '%.4f' % it['vol_ratio'],
                         '%.4f' % it['maxbox_ratio'], '%.4f' % it.get('peak_vol_IC', 0), it['cpm'],
                         ref if ref is not None else '', int(proven), lb] +
                        [best(nm, s) for s in ALL_STRATS] +
                        ['|'.join(rl for rl in RULES if ms[(nm, rl, 'S4')] == b4)])

    # ---- rule_table.csv
    with open(os.path.join(out_dir, 'rule_table.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['set', 'strategy', 'rule', 'n', 'mean_DM1_ref', 'mean_gap_LB'])
        for s in sets:
            for stg in ALL_STRATS:
                for rl in RULES:
                    g1, g2 = [], []
                    for nm in names_by_set[s]:
                        ref, proven, lb = refinfo(nm)
                        mk = ms[(nm, rl, stg)]
                        if ref:
                            g1.append((mk - ref) / float(ref))
                        g2.append((mk - lb) / float(lb))
                    wr.writerow([s, stg, rl, len(g2), '%.6f' % mean(g1), '%.6f' % mean(g2)])

    # ---- 汇总报告
    out = []
    A = out.append
    A('三维空间受限项目调度（3D-sRCPSP）实验汇总')
    A('=' * 100)
    A('运行模式: %s    成功算例: %d    失败算例: %d    进程数: %d    用时: %.1f 分钟'
      % (meta['mode'], len(ok), len(bad), meta['procs'], meta['elapsed'] / 60.0))
    A('规则: %d 条（25 条 r-PR + 11 条 s-PR）；每例每条规则跑 RCPSP、S1、S2、S3、S4、REACT 六种方案。' % len(RULES))
    A('')
    A('口径说明')
    A('  DM1_ref = (D − 参考工期)/参考工期。参考工期来自 PSPLIB，只针对普通 RCPSP；j30 全部已证最优，')
    A('          j60/j90/j120 中未证最优的只是最好已知上界，所以“全部”一列是相对参考值的偏差，不是最优性差距。')
    A('  DM1_opt = 只在“参考值已证最优”的算例上平均，此时参考值是三维问题的放松下界。')
    A('  gap_LB  = (D − LB)/LB，LB = max(已证最优值或官方下界, 关键路径长度)。真实最优性差距 ≤ gap_LB。')
    A('  DM2 = (Dd − 参考工期)/参考工期；DM3 = (Dd − Ds)/Dd。Dd 为忽略空间的计划被动顺延后的实际工期。')
    A('  空间增量 = (Ds − Dr)/Dr，Dr 为同一规则忽略空间时的普通 RCPSP 工期，用来分离“空间约束”与“启发式本身”的影响。')
    A('')

    A('一、数据与空间紧张度')
    A('  %-6s %6s %12s %14s %18s %18s %10s' % ('算例集', '例数', '已证最优参考', '体积比均值', '最大单箱体积比均值',
                                             'IC普通排程峰值并发体积比(均/最大)', '平均CPM'))
    for s in sets:
        nms = names_by_set[s]
        npv = sum(1 for nm in nms if refinfo(nm)[1])
        pk = [info[nm].get('peak_vol_IC', 0) for nm in nms]
        A('  %-6s %6d %12d %14s %18s %12s / %-8s %8.1f' % (
            s, len(nms), npv, pct(mean([info[nm]['vol_ratio'] for nm in nms])),
            pct(mean([info[nm]['maxbox_ratio'] for nm in nms])), pct(mean(pk)), pct(max(pk)),
            mean([info[nm]['cpm'] for nm in nms])))
    A('  （体积比 = 全部活动体积之和 / 场地体积；即使所有活动同时开工也只占这么多空间。）')
    A('')

    A('二、可行性核验（每个方案都用独立检查函数复核）')
    A('  %-6s %10s %10s %14s %12s' % ('方案', '方案数', '违约数', 'S1-S3兜底次数', '空场地重试'))
    for stg in ALL_STRATS:
        rws = [rw for k, rw in rowmap.items() if k[2] == stg]
        A('  %-6s %10d %10d %14d %12d' % (stg, len(rws), sum(rw['viol'] for rw in rws),
                                          sum(rw['fallback'] for rw in rws), sum(rw['retry'] for rw in rws)))
    A('  （RCPSP 方案只检查时间/资源，其余同时检查边界与三维不重叠。违约数应全部为 0。）')
    A('')

    A('三、合理性检查（数据与参考值是否对得上）')
    for s in sets:
        nms = names_by_set[s]
        c_r = sum(1 for nm in nms for rl in RULES if ms[(nm, rl, 'RCPSP')] < refinfo(nm)[2])
        c_s = sum(1 for nm in nms for rl in RULES for stg in STRATS + ['REACT'] if ms[(nm, rl, stg)] < refinfo(nm)[2])
        c_u = sum(1 for nm in nms if refinfo(nm)[0] and not refinfo(nm)[1] and best(nm, 'RCPSP') < refinfo(nm)[0])
        c_n = sum(1 for nm in nms if refinfo(nm)[0] is None)
        A('  %-6s 普通排程低于下界: %d 次；三维方案低于下界: %d 次；低于未证最优上界的算例: %d；无参考值: %d'
          % (s, c_r, c_s, c_u, c_n))
    A('  （低于下界说明算例与 PSPLIB 原版不一致或程序有误，应为 0。低于上界不一定是错误，但需独立验证。）')
    A('')

    A('四、主结果（各列为对算例和规则的平均；“最佳单一规则”为平均 DM1_ref 最小的规则）')
    for s in sets:
        nms = names_by_set[s]
        A('  【%s】%d 例' % (s, len(nms)))
        A('    %-6s %10s %10s %10s   %-8s %10s   %12s %12s' % ('方案', 'DM1_ref', 'DM1_opt', 'gap_LB',
                                                            '最佳规则', '其DM1_ref', '逐例最优DM1', '逐例最优gapLB'))
        for stg in ALL_STRATS:
            g_ref, g_opt, g_lb = [], [], []
            per_rule = {}
            for rl in RULES:
                pr = []
                for nm in nms:
                    ref, proven, lb = refinfo(nm)
                    mk = ms[(nm, rl, stg)]
                    if ref:
                        g = (mk - ref) / float(ref)
                        g_ref.append(g)
                        pr.append(g)
                        if proven:
                            g_opt.append(g)
                    g_lb.append((mk - lb) / float(lb))
                per_rule[rl] = mean(pr)
            br = min(RULES, key=lambda rl: per_rule[rl] if per_rule[rl] == per_rule[rl] else 9e9)
            o_ref, o_lb = [], []
            for nm in nms:
                ref, proven, lb = refinfo(nm)
                b = best(nm, stg)
                if ref:
                    o_ref.append((b - ref) / float(ref))
                o_lb.append((b - lb) / float(lb))
            A('    %-6s %10s %10s %10s   %-8s %10s   %12s %12s' % (
                stg, pct(mean(g_ref)), pct(mean(g_opt)), pct(mean(g_lb)), br, pct(per_rule[br]),
                pct(mean(o_ref)), pct(mean(o_lb))))
    A('')

    A('五、空间约束带来的工期增量（同一规则下与忽略空间的普通排程相比）')
    A('  %-6s %-6s %12s %14s %14s' % ('算例集', '方案', '平均增量', '工期变长占比', '工期变短占比'))
    for s in sets:
        nms = names_by_set[s]
        for stg in STRATS + ['REACT']:
            inc = []
            up = dn = 0
            for nm in nms:
                for rl in RULES:
                    dr = ms[(nm, rl, 'RCPSP')]
                    dv = ms[(nm, rl, stg)]
                    inc.append((dv - dr) / float(dr))
                    up += dv > dr
                    dn += dv < dr
            tot = float(len(inc))
            A('  %-6s %-6s %12s %14s %14s' % (s, stg, pct(mean(inc)), pct(up / tot), pct(dn / tot)))
    A('  （工期变短：考虑空间后开工顺序改变，偶尔反而更短，这是启发式的常见现象，不是错误。）')
    A('')

    A('六、事前考虑空间 vs 忽略空间后被动顺延（论文 DM2 / DM3）')
    A('  %-6s %10s %12s %12s %16s %12s %12s %12s' % ('算例集', 'DM2', 'DM3(对S3)', 'DM3(对S4)', 'DM3(各自最佳规则,S4)',
                                                   '平均顺延活动', '平均空间冲突', '平均资源冲突'))
    for s in sets:
        nms = names_by_set[s]
        dm2, d3a, d3b, d3best, dl, sc, rc = [], [], [], [], [], [], []
        for nm in nms:
            ref, proven, lb = refinfo(nm)
            for rl in RULES:
                dd = ms[(nm, rl, 'REACT')]
                if ref:
                    dm2.append((dd - ref) / float(ref))
                d3a.append((dd - ms[(nm, rl, 'S3')]) / float(dd))
                d3b.append((dd - ms[(nm, rl, 'S4')]) / float(dd))
                rw = rowmap[(nm, rl, 'REACT')]
                dl.append(rw['delayed'])
                sc.append(rw['space_conf'])
                rc.append(rw['res_conf'])
            bd = best(nm, 'REACT')
            d3best.append((bd - best(nm, 'S4')) / float(bd))
        A('  %-6s %10s %12s %12s %16s %12.2f %12.2f %12.2f' % (
            s, pct(mean(dm2)), pct(mean(d3a)), pct(mean(d3b)), pct(mean(d3best)), mean(dl), mean(sc), mean(rc)))
    A('')

    A('七、各规则平均 DM1_ref（S3 = 论文算法 c，S4 = 完整候选坐标）')
    hdr = '  %-8s' % '规则'
    for s in sets:
        hdr += ' %9s %9s' % (s + '-S3', s + '-S4')
    A(hdr)
    for rl in RULES:
        line = '  %-8s' % rl
        for s in sets:
            for stg in ('S3', 'S4'):
                g = []
                for nm in names_by_set[s]:
                    ref = refinfo(nm)[0]
                    if ref:
                        g.append((ms[(nm, rl, stg)] - ref) / float(ref))
                line += ' %9s' % pct(mean(g)).strip()
        A(line)
    A('')

    A('八、各规则在多少算例上取得该例最短工期（S4，并列都算）——说明“没有一条规则通吃”，为 AI 规则选择提供依据')
    for s in sets:
        nms = names_by_set[s]
        wins = defaultdict(int)
        for nm in nms:
            b = best(nm, 'S4')
            for rl in RULES:
                if ms[(nm, rl, 'S4')] == b:
                    wins[rl] += 1
        top = sorted(RULES, key=lambda rl: -wins[rl])[:10]
        A('  %-6s ' % s + '  '.join('%s:%d' % (rl, wins[rl]) for rl in top) + '   （共 %d 例）' % len(nms))
    A('')

    if bad:
        A('九、失败算例')
        for x in bad:
            A('  %s %s' % (x['set'], x['name']))
            A('    ' + x['err'].replace('\n', '\n    '))
    A('')
    A('输出文件：runs.csv（逐例逐规则逐方案）、instances.csv（逐例汇总）、rule_table.csv（规则×方案平均）、样例调度_*.csv（含坐标，可画甘特图/三维图）')
    with open(os.path.join(out_dir, '汇总报告.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(out) + '\n')
    log('汇总报告已写入')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--full', action='store_true')
    ap.add_argument('--sets', default=','.join(SETS))
    ap.add_argument('--procs', type=int, default=0)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--data', default='', help='03_算例 下的子文件夹，如 紧空间_U5S6；默认用原始 R-instances')
    ap.add_argument('--part', default='', help='分块运行，如 3/10 表示第3块(从0计)共10块')
    ap.add_argument('--merge', action='store_true', help='只读取 _cache_*.pkl 合并出报告（分批运行时用）')
    args = ap.parse_args()
    global DATA_DIR
    mode = 'full' if args.full else 'quick'
    out_dir = os.path.join(OUT_ROOT, mode)
    if args.data:
        DATA_DIR = os.path.join(DATA_DIR, args.data)
        out_dir = os.path.join(OUT_ROOT, args.data + '_' + mode)
    os.makedirs(out_dir, exist_ok=True)
    logf = open(os.path.join(out_dir, '运行日志.txt'), 'a', encoding='utf-8')

    def log(msg):
        line = time.strftime('%H:%M:%S ') + msg
        logf.write(line + '\n')
        logf.flush()
        try:
            print(line, flush=True)
        except Exception:
            pass

    t_all = time.time()
    try:
        sets = [s.strip() for s in args.sets.split(',') if s.strip() in SETS]
        tasks = list_tasks(sets, quick=(mode == 'quick'), limit=args.limit)
        if args.part:
            k_, n_ = map(int, args.part.split('/'))
            tasks = tasks[k_::n_]
        tasks.sort(key=lambda x: -SETS.index(x[1]))          # 大算例先算，便于负载均衡
        refs = load_refs()
        procs = args.procs or max(1, cpu_count() - 1)
        log('mode=%s tasks=%d procs=%d refs=%d python=%s' % (mode, len(tasks), procs, len(refs), sys.version.split()[0]))
        if not tasks:
            log('没有找到算例，请检查 03_算例 文件夹')
            return
        results = []
        if args.merge:
            import pickle
            import glob
            seen = set()
            for cp in sorted(glob.glob(os.path.join(out_dir, '_cache_*.pkl'))):
                with open(cp, 'rb') as f:
                    for x in pickle.load(f):
                        if x['name'] not in seen:
                            seen.add(x['name'])
                            results.append(x)
            log('merge: %d 个算例结果来自缓存' % len(results))
            meta = {'mode': mode, 'procs': procs, 'elapsed': time.time() - t_all}
            write_outputs(out_dir, results, refs, meta, log)
            return
        with Pool(procs) as pool:
            for k, res in enumerate(pool.imap_unordered(run_instance, tasks, chunksize=1), 1):
                results.append(res)
                if not res['ok']:
                    log('[ERROR] %s\n%s' % (res['name'], res['err']))
                if k % 10 == 0 or k == len(tasks):
                    log('progress %d/%d  %.0fs' % (k, len(tasks), time.time() - t_all))
        import pickle
        tag = '_'.join(sets) + ('_p' + args.part.replace('/', 'of') if args.part else '')
        with open(os.path.join(out_dir, '_cache_%s.pkl' % tag), 'wb') as f:
            pickle.dump(results, f)
        if args.part:
            log('part %s 已缓存 %d 例' % (args.part, len(results)))
            return
        meta = {'mode': mode, 'procs': procs, 'elapsed': time.time() - t_all}
        write_outputs(out_dir, results, refs, meta, log)
        log('done in %.1f min' % ((time.time() - t_all) / 60.0))
    except Exception:
        log('[FATAL]\n' + traceback.format_exc())
        raise
    finally:
        logf.close()


if __name__ == '__main__':
    main()
