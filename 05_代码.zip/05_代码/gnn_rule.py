# -*- coding: utf-8 -*-
"""
gnn_rule.py —— 时-空-资源 图神经网络（关系图卷积）规则选择器，PyTorch 实现

图的构造（每个决策时刻一张图，对应申请书 3.1.1 的“时空结构图”）：
  节点 = 工序。节点特征 = 静态（工期、4 类资源占比、箱体长宽高与体积、关键路径时间参数、后继数、
         10 条候选规则下的优先名次）+ 动态（已完工/执行中/可开工/未就绪、此刻资源是否够、剩余工期、
         距最晚开始/完成的余量、执行中工序的箱体坐标）。
  边（4 类，分别有各自的权重矩阵）：
    时间边  紧前→紧后、紧后→紧前（两类）
    空间边  两个无紧前关系的工序在三个轴上都无法并排放下（l1+l2>L 且 w1+w2>W 且 h1+h2>H），即永远不能同时执行
    资源边  两个无紧前关系的工序在某类资源上需求之和超过容量
网络：输入层 → 3 层关系图卷积（残差 + LayerNorm）→ 读出（可开工节点的均值/最大值、执行中节点均值、全图均值）
      拼接 20 维全局状态 → MLP → 10 条规则各自的“预计工期代价”，选代价最小的规则。
训练：与 train_dqn.py 的 MLP 相同——用仿真前瞻教师（pilot）的 Q 值标签做监督回归（Q 值蒸馏）。
动作执行仍由 S4 放置，因此任何输出都可行。

用法（每条命令 <170 秒）：
  python3 gnn_rule.py --build k/n      回放教师轨迹，生成图数据缓存（/tmp/gnn_cache）
  python3 gnn_rule.py --train 150      训练（断点续训，每块结束在验证集上评估并保留最好参数）
  python3 gnn_rule.py --eval k/n       测试集评估（贪心 + 前3推演），--merge 汇总
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np
import torch
import torch.nn as nn

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import train_dqn as T

torch.set_num_threads(2)
OUT = os.path.join(T.ROOT, '06_实验结果', 'GNN规则选择')
CACHE = os.path.join(OUT, '_cache')          # 放在共享文件夹里，Windows 端 GPU 训练直接读
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
CKPT = os.environ.get('GNN_CKPT', os.path.join(OUT, 'gnn_ckpt.pt'))
NA = len(rl_env.ACTIONS)
F_STATIC = 1 + 4 + 4 + 4 + 3 + 1 + NA      # 27
F_DYN = 11
F_IN = F_STATIC + F_DYN
F_G = rl_env.N_FEAT
N_ETYPE = 4


# ----------------------------------------------------------------------------------------------
# 图构造
# ----------------------------------------------------------------------------------------------
def static_graph(env):
    """每个算例只算一次：静态节点特征 + 4 类边"""
    I = env.I
    n, K = I.n, I.K
    if hasattr(env, '_g'):
        return env._g
    ES, LS, LF, TF = I.pv['EST'], I.pv['LST'], I.pv['LFT'], I.pv['TF']
    c = env.cpm
    X = np.zeros((n, F_STATIC), dtype=np.float32)
    for j in range(n):
        l, w, h = I.dim[j]
        X[j, 0] = I.d[j] / env.maxd
        for k in range(min(K, 4)):
            X[j, 1 + k] = I.r[j][k] / float(I.R[k]) if I.R[k] > 0 else 0
        X[j, 5:9] = [l / float(I.L), w / float(I.W), h / float(I.H), I.vol[j] / env.maxvol]
        X[j, 9:13] = [ES[j] / c, LS[j] / c, LF[j] / c, TF[j] / env.maxtf]
        X[j, 13:16] = [I.pv['MTS'][j] / float(n), len(I.succ[j]) / 3.0, len(I.pred[j]) / 3.0]
        X[j, 16] = 1.0 if I.d[j] == 0 else 0.0
    for a, rule in enumerate(rl_env.ACTIONS):
        order = sorted(range(n), key=lambda j: env.keys[rule][j])
        for rk, j in enumerate(order):
            X[j, 17 + a] = rk / float(n - 1)
    # 可达关系（有紧前/紧后路径的两道工序永远不会同时执行，不连空间/资源边）
    reach = [0] * n
    for j in reversed(I.topo):
        m = 0
        for s in I.succ[j]:
            m |= (1 << s) | reach[s]
        reach[j] = m
    real = [j for j in range(n) if I.d[j] > 0]
    sp, rs = [], []
    for ai in range(len(real)):
        i = real[ai]
        li, wi, hi = I.dim[i]
        for bj in range(ai + 1, len(real)):
            j = real[bj]
            if (reach[i] >> j) & 1 or (reach[j] >> i) & 1:
                continue
            lj, wj, hj = I.dim[j]
            if li + lj > I.L and wi + wj > I.W and hi + hj > I.H:
                sp += [(i, j), (j, i)]
            if any(I.r[i][k] + I.r[j][k] > I.R[k] for k in range(K)):
                rs += [(i, j), (j, i)]
    fw = [(i, s) for i in range(n) for s in I.succ[i]]
    bw = [(s, i) for i, s in fw]
    E = [np.array(e, dtype=np.int64).reshape(-1, 2) for e in (fw, bw, sp, rs)]
    env._g = (X, E)
    return env._g


def dyn_feats(env):
    """当前决策时刻的动态节点特征 + 掩码"""
    I = env.I
    n = I.n
    t = env.t
    c = env.cpm
    D = np.zeros((n, F_DYN), dtype=np.float32)
    act = set(env.active)
    LS, LF = I.pv['LST'], I.pv['LFT']
    for j in range(n):
        if j in act:
            D[j, 1] = 1
            D[j, 5] = (env.F[j] - t) / env.maxd
            p = env.P[j]
            if p is not None:
                D[j, 8:11] = [p[0] / float(I.L), p[1] / float(I.W), p[2] / float(I.H)]
        elif env.S[j] is not None:
            D[j, 0] = 1
        elif j in env.elig:
            D[j, 2] = 1
            D[j, 4] = 1.0 if env._res_ok(j) else 0.0
        else:
            D[j, 3] = 1
        D[j, 6] = (LS[j] - t) / c
        D[j, 7] = (LF[j] - t) / c
    return D


# ----------------------------------------------------------------------------------------------
# 回放教师轨迹，生成训练数据
# ----------------------------------------------------------------------------------------------
def build(k, n):
    os.makedirs(CACHE, exist_ok=True)
    pil = T.load_pilot()
    inst = T.list_instances()
    items = (inst['train'] + inst['val'])[k::n]
    out = []
    t0 = time.time()
    nsp = nrs = 0
    for s, name, f in items:
        env = rl_env.Env(sd.load_instance(f))
        Xs, E = static_graph(env)
        nsp += len(E[2]); nrs += len(E[3])
        Y = pil[name]['Y']
        obs = env.reset()
        D, G = [], []
        i = 0
        while not env.done:
            D.append(dyn_feats(env).astype(np.float16))
            G.append(obs.astype(np.float32))
            obs, _, _ = env.step(int(np.argmin(Y[i])))
            i += 1
        assert i == len(Y), (name, i, len(Y))
        assert env.makespan() == pil[name]['pilot_ms'], name
        out.append({'name': name, 'split': T.split_of(name), 'Xs': Xs, 'E': E,
                    'D': D, 'G': np.array(G), 'Y': Y.astype(np.float32)})
    with open(os.path.join(CACHE, 'g_p%dof%d.pkl' % (k, n)), 'wb') as fh:
        pickle.dump(out, fh, protocol=4)
    print('build %d/%d: %d 例 %.0fs，平均空间边 %.0f、资源边 %.0f（有向）' % (
        k, n, len(out), time.time() - t0, nsp / max(1, len(out)), nrs / max(1, len(out))))


def load_cache():
    data = []
    for f in sorted(glob.glob(os.path.join(CACHE, 'g_p*.pkl'))):
        with open(f, 'rb') as fh:
            data += pickle.load(fh)
    return data


# ----------------------------------------------------------------------------------------------
# 网络
# ----------------------------------------------------------------------------------------------
class RGCN(nn.Module):
    def __init__(self, fin=F_IN, fg=F_G, h=64, layers=3, nact=NA):
        super().__init__()
        self.inp = nn.Linear(fin, h)
        self.self_lin = nn.ModuleList([nn.Linear(h, h) for _ in range(layers)])
        self.rel_lin = nn.ModuleList([nn.ModuleList([nn.Linear(h, h, bias=False) for _ in range(N_ETYPE)])
                                      for _ in range(layers)])
        self.norm = nn.ModuleList([nn.LayerNorm(h) for _ in range(layers)])
        self.head = nn.Sequential(nn.Linear(4 * h + fg, 256), nn.ReLU(), nn.Linear(256, 128), nn.ReLU(),
                                  nn.Linear(128, nact))
        self.h = h

    def forward(self, x, edges, gid, ng, elig, actv, g):
        h = torch.relu(self.inp(x))
        N = h.shape[0]
        dv = h.device
        for L in range(len(self.self_lin)):
            m = self.self_lin[L](h)
            for t, (src, dst, dinv) in enumerate(edges):
                if src.numel() == 0:
                    continue
                msg = self.rel_lin[L][t](h)[src]
                agg = torch.zeros(N, self.h, device=dv).index_add_(0, dst, msg)
                m = m + agg * dinv[:, None]
            h = self.norm[L](h + torch.relu(m))

        def mean_pool(mask):
            w = mask.float()
            s = torch.zeros(ng, self.h, device=dv).index_add_(0, gid, h * w[:, None])
            c = torch.zeros(ng, device=dv).index_add_(0, gid, w).clamp(min=1.0)
            return s / c[:, None]

        hm = torch.where(elig[:, None], h, torch.full_like(h, -1e4))
        mx = torch.full((ng, self.h), -1e4, device=dv).scatter_reduce(0, gid[:, None].expand(-1, self.h), hm,
                                                                     'amax', include_self=True)
        mx = torch.where(mx < -1e3, torch.zeros_like(mx), mx)
        pooled = torch.cat([mean_pool(elig), mx, mean_pool(actv), mean_pool(torch.ones_like(elig))], 1)
        return self.head(torch.cat([pooled, g], 1))


def collate(graphs):
    """graphs: [(Xs, E, D, G)] -> 批张量"""
    xs, gid, el, ac, gg = [], [], [], [], []
    es = [[] for _ in range(N_ETYPE)]
    off = 0
    for b, (Xs, E, D, G) in enumerate(graphs):
        n = Xs.shape[0]
        D = D.astype(np.float32)
        xs.append(np.concatenate([Xs, D], 1))
        gid.append(np.full(n, b, dtype=np.int64))
        el.append(D[:, 2] > 0.5)
        ac.append(D[:, 1] > 0.5)
        gg.append(G)
        for t in range(N_ETYPE):
            if len(E[t]):
                es[t].append(E[t] + off)
        off += n
    N = off
    edges = []
    for t in range(N_ETYPE):
        if es[t]:
            e = torch.from_numpy(np.concatenate(es[t]))
            src, dst = e[:, 0], e[:, 1]
            deg = torch.zeros(N).index_add_(0, dst, torch.ones(len(dst)))
            dinv = 1.0 / deg.clamp(min=1.0)
            edges.append((src, dst, dinv))
        else:
            edges.append((torch.zeros(0, dtype=torch.long),) * 2 + (torch.zeros(N),))
    d = DEV
    edges = [(s.to(d), t.to(d), v.to(d)) for s, t, v in edges]
    return (torch.from_numpy(np.concatenate(xs)).to(d), edges, torch.from_numpy(np.concatenate(gid)).to(d),
            len(graphs), torch.from_numpy(np.concatenate(el)).to(d), torch.from_numpy(np.concatenate(ac)).to(d),
            torch.from_numpy(np.stack(gg).astype(np.float32)).to(d))


def predict_env(model, env, obs):
    Xs, E = static_graph(env)
    with torch.no_grad():
        return model(*collate([(Xs, E, dyn_feats(env), obs)]))[0].cpu().numpy()


def run_gnn(model, I, topk=1):
    """topk=1：直接用网络选的规则；topk=3：只推演网络认为最好的 3 条规则，选推演工期最短的"""
    env = rl_env.Env(I)
    obs = env.reset()
    while not env.done:
        cost = predict_env(model, env, obs)
        cand = np.argsort(cost)[:topk]
        if topk == 1:
            a = int(cand[0])
        else:
            best = None
            for c in cand:
                e = env.clone()
                while not e.done:
                    e.step(int(c))
                if best is None or e.makespan() < best[1]:
                    best = (int(c), e.makespan())
            a = best[0]
        obs, _, _ = env.step(a)
    return env.makespan(), env.S, env.F, env.P


_val_env = {}


def val_score(model, items):
    model.eval()
    r = []
    for s, name, f in items:
        if f not in _val_env:
            _val_env[f] = sd.load_instance(f)
        I = _val_env[f]
        r.append(run_gnn(model, I)[0] / float(I.cpm))
    model.train()
    return float(np.mean(r))


# ----------------------------------------------------------------------------------------------
# 训练
# ----------------------------------------------------------------------------------------------
def train(seconds, batch=64, lr=1e-3):
    os.makedirs(OUT, exist_ok=True)
    data = [d for d in load_cache() if d['split'] == 'train']
    samples = [(gi, i) for gi, d in enumerate(data) for i in range(len(d['Y']))]
    model = RGCN()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    state = {'epoch': 0, 'step': 0, 'best_val': None, 'best': None, 'curve': [], 'seed': 0}
    if os.path.exists(CKPT):
        state = torch.load(CKPT, weights_only=False)
        model.load_state_dict(state['model'])
        opt.load_state_dict(state['opt'])
    rng = np.random.default_rng(1000 + state['step'])
    t0 = time.time()
    losses = []
    model.train()
    budget = seconds - 40          # 留 40 秒做验证
    while time.time() - t0 < budget:
        perm = rng.permutation(len(samples))
        pos = state.get('pos', 0) if state.get('perm_epoch') == state['epoch'] else 0
        if pos:
            perm = state['perm']
        else:
            state['perm'] = perm
            state['perm_epoch'] = state['epoch']
        while pos < len(perm) and time.time() - t0 < budget:
            idx = perm[pos:pos + batch]
            pos += batch
            gs, ys = [], []
            for s in idx:
                gi, i = samples[s]
                d = data[gi]
                gs.append((d['Xs'], d['E'], d['D'][i], d['G'][i]))
                y = d['Y'][i]
                ys.append((y - y.min()) * 10.0)
            pred = model(*collate(gs))
            loss = ((pred - torch.from_numpy(np.stack(ys))) ** 2).mean()
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            state['step'] += 1
            losses.append(loss.item())
        state['pos'] = pos
        if pos >= len(perm):
            state['epoch'] += 1
            state['pos'] = 0
    val = T.list_instances()['val']
    v = val_score(model, val[::2])
    state['curve'].append((state['epoch'], state['pos'], state['step'], float(np.mean(losses)) if losses else 0, v))
    if state['best_val'] is None or v < state['best_val']:
        state['best_val'] = v
        state['best'] = {k: x.clone() for k, x in model.state_dict().items()}
    state['model'] = model.state_dict()
    state['opt'] = opt.state_dict()
    torch.save(state, CKPT + '.tmp')
    os.replace(CKPT + '.tmp', CKPT)
    print('epoch %d (+%d/%d) step %d loss %.4f  验证(半集) ms/CPM %.4f  best %.4f  %.0fs' % (
        state['epoch'], state['pos'], len(samples), state['step'], np.mean(losses) if losses else 0, v,
        state['best_val'], time.time() - t0))


def _cpu(sd_):
    return {k: v.detach().cpu().clone() for k, v in sd_.items()}


def train_epochs(epochs, hidden=128, layers=4, batch=128, lr=1e-3, limit=0):
    """整轮训练（适合 GPU 一次跑完）：每个 epoch 结束在完整验证集上贪心评估，保留最好参数；每轮都存检查点可续训"""
    os.makedirs(OUT, exist_ok=True)
    print('设备:', DEV, torch.cuda.get_device_name(0) if DEV.type == 'cuda' else '', flush=True)
    data = [d for d in load_cache() if d['split'] == 'train']
    if limit:
        data = data[:limit]
    samples = [(gi, i) for gi, d in enumerate(data) for i in range(len(d['Y']))]
    cfg = {'h': hidden, 'layers': layers}
    model = RGCN(h=hidden, layers=layers).to(DEV)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    steps_per = (len(samples) + batch - 1) // batch
    total = max(1, epochs * steps_per)
    warm = max(1, total // 20)

    def lr_lambda(step):            # 前 5% 线性预热，之后余弦衰减到 5%
        if step < warm:
            return (step + 1) / float(warm)
        p = min(1.0, (step - warm) / float(max(1, total - warm)))
        return 0.05 + 0.95 * 0.5 * (1 + np.cos(np.pi * p))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda)
    state = {'epoch': 0, 'best_val': None, 'best': None, 'curve': [], 'cfg': cfg}
    if os.path.exists(CKPT):
        old = torch.load(CKPT, map_location=DEV, weights_only=False)
        if old.get('cfg') == cfg and old.get('mode') == 'epochs' and old.get('epochs_total') == epochs:
            state = old
            model.load_state_dict(old['model'])
            opt.load_state_dict(old['opt'])
            sched.load_state_dict(old['sched'])
            print('从 epoch %d 续训' % state['epoch'], flush=True)
    state['mode'], state['epochs_total'] = 'epochs', epochs
    print('训练样本 %d（%d 个算例），参数量 %.3fM，每轮 %d 步' % (
        len(samples), len(data), sum(p.numel() for p in model.parameters()) / 1e6, steps_per), flush=True)
    val = T.list_instances()['val']
    rng = np.random.default_rng(7)
    for _ in range(state['epoch']):
        rng.permutation(len(samples))
    while state['epoch'] < epochs:
        t0 = time.time()
        model.train()
        perm = rng.permutation(len(samples))
        losses = []
        for p in range(0, len(perm), batch):
            gs, ys = [], []
            for s in perm[p:p + batch]:
                gi, i = samples[s]
                d = data[gi]
                gs.append((d['Xs'], d['E'], d['D'][i], d['G'][i]))
                y = d['Y'][i]
                ys.append((y - y.min()) * 10.0)
            pred = model(*collate(gs))
            loss = ((pred - torch.from_numpy(np.stack(ys)).to(DEV)) ** 2).mean()
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            sched.step()
            losses.append(loss.item())
        tt = time.time() - t0
        v = val_score(model, val)
        state['epoch'] += 1
        state['curve'].append((state['epoch'], 0, state['epoch'] * steps_per, float(np.mean(losses)), v))
        if state['best_val'] is None or v < state['best_val']:
            state['best_val'] = v
            state['best'] = _cpu(model.state_dict())
        state['model'] = _cpu(model.state_dict())
        state['opt'] = opt.state_dict()
        state['sched'] = sched.state_dict()
        torch.save(state, CKPT + '.tmp')
        os.replace(CKPT + '.tmp', CKPT)
        print('epoch %2d/%d  loss %.4f  验证 ms/CPM %.4f  best %.4f  训练 %.0fs 验证 %.0fs' % (
            state['epoch'], epochs, np.mean(losses), v, state['best_val'], tt, time.time() - t0 - tt), flush=True)
    print('训练完成，最优验证 %.4f，检查点 %s' % (state['best_val'], CKPT), flush=True)


def load_best():
    state = torch.load(CKPT, map_location='cpu', weights_only=False)
    cfg = state.get('cfg', {'h': 64, 'layers': 3})
    model = RGCN(h=cfg['h'], layers=cfg['layers']).to(DEV)
    model.load_state_dict(state['best'])
    model.eval()
    return model, state


def do_eval(k, n):
    model, _ = load_best()
    items = T.list_instances()['test'][k::n]
    path = os.path.join(OUT, '_eval_p%dof%d.pkl' % (k, n))
    rows = []
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            rows = pickle.load(fh)
    done = set(r[1] for r in rows)
    t00 = time.time()
    for s, name, f in items:
        if name in done:
            continue
        I = sd.load_instance(f)
        t0 = time.time()
        ms1, S, F, P = run_gnn(model, I, 1)
        dt1 = time.time() - t0
        v1 = sum(sd.check(I, S, F, P, space=True).values())
        t0 = time.time()
        ms3, S, F, P = run_gnn(model, I, 3)
        dt3 = time.time() - t0
        v3 = sum(sd.check(I, S, F, P, space=True).values())
        rows.append((s, name, ms1, dt1, ms3, dt3, v1 + v3))
        if time.time() - t00 > float(os.environ.get('EVAL_BUDGET', '140')):
            break
    with open(path, 'wb') as fh:
        pickle.dump(rows, fh)
    print('eval %d/%d: %d/%d' % (k, n, len(rows), len(items)))


def merge():
    import pandas as pd
    rows = []
    for f in glob.glob(os.path.join(OUT, '_eval_p*.pkl')):
        with open(f, 'rb') as fh:
            rows += pickle.load(fh)
    g = pd.DataFrame(rows, columns=['set', 'instance', 'GNN', 'GNN_s', 'GNN_guided3', 'GNN_guided3_s',
                                    'gnn_viol']).drop_duplicates('instance')
    d = pd.read_csv(os.path.join(T.OUT, '测试集逐例结果.csv'))
    d = d.merge(g, on=['set', 'instance'])
    assert len(d) == 612, len(d)
    d['violations'] = d['violations'] + d['gnn_viol']
    d = d.drop(columns=['gnn_viol']).rename(columns={'DQN': 'MLP', 'guided3': 'MLP_guided3',
                                                     'DQN_ms': 'MLP_ms', 'guided3_s': 'MLP_guided3_s'})
    d.to_csv(os.path.join(OUT, '测试集逐例结果_含GNN.csv'), index=False, encoding='utf-8-sig')
    _, state = load_best()
    cols = ['LFT', 'MLP', 'GNN', 'oracle10', 'MLP_guided3', 'GNN_guided3', 'pilot']
    L = ['图神经网络（关系图卷积 RGCN）规则选择器 —— 紧空间 U5S6 测试集 612 例（训练时未见过）',
         '',
         '与 06_实验结果/DQN规则选择 使用同一训练集、同一教师标签（仿真前瞻 pilot 的 Q 值）、同一测试集，',
         '唯一区别是网络：MLP 只看 20 维汇总状态；GNN 看整张“工序-时间边-空间边-资源边”图（每个工序一个节点）。',
         'MLP 参数量约 0.006M；GNN 参数量 %.3fM。' % (sum(p.numel() for p in RGCN().parameters()) / 1e6),
         '',
         '一、相对下界差距 (工期−LB)/LB（越小越好；LB 不含空间约束，只是最优性差距的上界）',
         '%-6s' % '集合' + ''.join('%13s' % c for c in cols)]
    for s in T.SETS + ['ALL']:
        x = d if s == 'ALL' else d[d['set'] == s]
        L.append('%-6s' % s + ''.join('%12.2f%%' % (100 * (x[c] / x['LB'] - 1).mean()) for c in cols))
    L += ['', '二、相对 LFT 的工期缩短（逐例 (LFT−方法)/LFT 的平均），胜/平/负（对 LFT），单例平均耗时（j120）']
    j120 = d[d['set'] == 'j120']
    tcol = {'MLP': 'MLP_ms', 'GNN': 'GNN_s', 'MLP_guided3': 'MLP_guided3_s', 'GNN_guided3': 'GNN_guided3_s',
            'pilot': 'pilot_s'}
    for c in cols[1:]:
        diff = d['LFT'] - d[c]
        tt = ''
        if c in tcol:
            v = j120[tcol[c]].mean()
            tt = '%.3f s' % (v / 1000.0 if c == 'MLP' else v)
        L.append('  %-12s 缩短 %5.2f%%  平均少 %5.1f 天  %3d / %3d / %3d   %s' % (
            c, 100 * (diff / d['LFT']).mean(), diff.mean(), (diff > 0).sum(), (diff == 0).sum(), (diff < 0).sum(), tt))
    dd = d['MLP'] - d['GNN']
    L += ['', 'GNN 对 MLP（单次贪心）：GNN 更好 %d 例 / 持平 %d / 更差 %d' % ((dd > 0).sum(), (dd == 0).sum(), (dd < 0).sum())]
    dd = d['MLP_guided3'] - d['GNN_guided3']
    L += ['GNN_guided3 对 MLP_guided3：GNN 更好 %d 例 / 持平 %d / 更差 %d' % ((dd > 0).sum(), (dd == 0).sum(), (dd < 0).sum())]
    L += ['总违规数（全部方法、全部测试算例，check() 复核紧前/资源/三维不重叠/边界）：%d' % int(d['violations'].sum()),
          '', '训练曲线（每个训练块结束时在半个验证集上贪心评估，指标 = 平均 工期/CPM；MLP 同口径最好约 1.63）：']
    for ep, pos, step, loss, v in state['curve']:
        L.append('  epoch %2d  step %6d  loss %.4f  验证 %.4f' % (ep, step, loss, v))
    L.append('测试使用验证最好的参数（验证 %.4f）' % state['best_val'])
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '结果报告.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--build', type=str)
    ap.add_argument('--train', type=float, default=0)
    ap.add_argument('--eval', type=str)
    ap.add_argument('--merge', action='store_true')
    ap.add_argument('--epochs', type=int, default=0)
    ap.add_argument('--hidden', type=int, default=128)
    ap.add_argument('--layers', type=int, default=4)
    ap.add_argument('--batch', type=int, default=128)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()
    if a.build:
        build(*(int(x) for x in a.build.split('/')))
    if a.epochs:
        train_epochs(a.epochs, a.hidden, a.layers, a.batch, a.lr, a.limit)
    if a.train:
        train(a.train)
    if a.eval:
        do_eval(*(int(x) for x in a.eval.split('/')))
    if a.merge:
        merge()
