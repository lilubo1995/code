# -*- coding: utf-8 -*-
"""dqn.py —— 纯 numpy 实现的 Double DQN（两层隐藏层 MLP + Adam + 经验回放 + 目标网络），不依赖 torch。"""
import numpy as np


class QNet(object):
    def __init__(self, nin, nout, h=64, seed=0):
        rng = np.random.default_rng(seed)
        self.p = {'W1': rng.normal(0, np.sqrt(2.0 / nin), (nin, h)), 'b1': np.zeros(h),
                  'W2': rng.normal(0, np.sqrt(2.0 / h), (h, h)), 'b2': np.zeros(h),
                  'W3': rng.normal(0, 0.01, (h, nout)), 'b3': np.zeros(nout)}
        self.m = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.step = 0

    @staticmethod
    def forward(p, X):
        h1 = X @ p['W1'] + p['b1']
        a1 = np.maximum(h1, 0)
        h2 = a1 @ p['W2'] + p['b2']
        a2 = np.maximum(h2, 0)
        return a2 @ p['W3'] + p['b3'], (X, h1, a1, h2, a2)

    def q(self, X):
        return self.forward(self.p, X)[0]

    def update(self, X, dq, lr=5e-4, clip=10.0):
        p = self.p
        q, (X, h1, a1, h2, a2) = self.forward(p, X)
        g = {'W3': a2.T @ dq, 'b3': dq.sum(0)}
        dh2 = (dq @ p['W3'].T) * (h2 > 0)
        g['W2'] = a1.T @ dh2
        g['b2'] = dh2.sum(0)
        dh1 = (dh2 @ p['W2'].T) * (h1 > 0)
        g['W1'] = X.T @ dh1
        g['b1'] = dh1.sum(0)
        norm = np.sqrt(sum(float((x * x).sum()) for x in g.values()))
        if norm > clip:
            for k in g:
                g[k] *= clip / norm
        self.step += 1
        b1, b2, eps = 0.9, 0.999, 1e-8
        for k in p:
            self.m[k] = b1 * self.m[k] + (1 - b1) * g[k]
            self.v[k] = b2 * self.v[k] + (1 - b2) * g[k] * g[k]
            mh = self.m[k] / (1 - b1 ** self.step)
            vh = self.v[k] / (1 - b2 ** self.step)
            p[k] -= lr * mh / (np.sqrt(vh) + eps)


class Agent(object):
    def __init__(self, nin, nact, cap=100000, seed=0):
        self.net = QNet(nin, nact, seed=seed)
        self.tgt = {k: v.copy() for k, v in self.net.p.items()}
        self.nact = nact
        self.cap = cap
        self.S = np.zeros((cap, nin))
        self.A = np.zeros(cap, dtype=np.int64)
        self.R = np.zeros(cap)
        self.S2 = np.zeros((cap, nin))
        self.D = np.zeros(cap)
        self.size = 0
        self.ptr = 0
        self.n_updates = 0
        self.episodes = 0
        self.rng = np.random.default_rng(seed)

    def act(self, s, eps):
        if self.rng.random() < eps:
            return int(self.rng.integers(self.nact))
        return int(np.argmax(self.net.q(s[None, :])[0]))

    def greedy(self, s):
        return int(np.argmax(self.net.q(s[None, :])[0]))

    def remember(self, s, a, r, s2, done):
        i = self.ptr
        self.S[i], self.A[i], self.R[i], self.D[i] = s, a, r, float(done)
        self.S2[i] = s2 if s2 is not None else 0.0
        self.ptr = (i + 1) % self.cap
        self.size = min(self.size + 1, self.cap)

    def learn(self, batch=64, gamma=1.0, sync=500, lr=5e-4):
        idx = self.rng.integers(self.size, size=batch)
        s, a, r, s2, d = self.S[idx], self.A[idx], self.R[idx], self.S2[idx], self.D[idx]
        a_star = np.argmax(self.net.q(s2), axis=1)                       # Double DQN：在线网络选动作
        q_next = QNet.forward(self.tgt, s2)[0][np.arange(batch), a_star]  # 目标网络估值
        y = r + gamma * (1.0 - d) * q_next
        q = self.net.q(s)
        diff = q[np.arange(batch), a] - y
        dq = np.zeros_like(q)
        dq[np.arange(batch), a] = np.clip(diff, -1.0, 1.0) / batch      # Huber 损失
        self.net.update(s, dq, lr=lr)
        self.n_updates += 1
        if self.n_updates % sync == 0:
            self.tgt = {k: v.copy() for k, v in self.net.p.items()}
        return float(np.mean(np.abs(diff)))
