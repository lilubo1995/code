# -*- coding: utf-8 -*-
"""
progress.py —— 在 bat 窗口里画一行进度条（不写进日志）。

bat 把 stdout/stderr 都重定向到了日志文件，窗口里本来什么都看不到。这里在 Windows 上直接打开控制台 CONOUT$ 写，
所以日志照常记录，窗口里多一行会原地刷新的进度条：
    label        [###########-------------------]  37%  530/1428  used 2:05  left 3:31
只在主进程里调用；多进程池的子进程不画。只用 ASCII，避免控制台编码问题。
Linux/VM 上默认不画（设 PROGRESS_FORCE=1 时画到 stderr，自检用）。
"""
import os
import sys
import time

_out = None
_init = False


def _stream():
    global _out, _init
    if not _init:
        _init = True
        try:
            if os.environ.get('PROGRESS_FORCE') == '1':
                _out = sys.stderr
            elif os.name == 'nt':
                _out = open('CONOUT$', 'w')
        except Exception:
            _out = None
    return _out


def _fmt(sec):
    sec = int(max(0, sec))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return '%d:%02d:%02d' % (h, m, s) if h else '%d:%02d' % (m, s)


class Bar(object):
    def __init__(self, label, total, start=0, width=28):
        """start：续跑时已完成的量（剩余时间只按本次的速度估算）"""
        self.label = label[:12]
        self.total = max(1, int(total))
        self.start = int(start)
        self.width = width
        self.t0 = time.time()
        self.last = 0.0

    def update(self, k, note=''):
        s = _stream()
        if s is None:
            return
        now = time.time()
        if k < self.total and now - self.last < 0.5:      # 最多每 0.5 秒刷新一次
            return
        self.last = now
        f = min(1.0, max(0.0, k / float(self.total)))
        used = now - self.t0
        dk = k - self.start
        left = used * (self.total - k) / float(dk) if dk > 0 else 0
        f_ok = dk > 0
        n = int(round(self.width * f))
        line = '%-12s [%s%s] %3d%%  %d/%d  used %s  left %s  %s' % (
            self.label, '#' * n, '-' * (self.width - n), int(100 * f), k, self.total, _fmt(used),
            _fmt(left) if f_ok else '?', note)
        try:
            s.write('\r' + line[:110].ljust(110))
            s.flush()
        except Exception:
            pass

    def done(self, note=''):
        self.last = 0.0
        self.update(self.total, note)
        s = _stream()
        if s is not None:
            try:
                s.write('\n')
                s.flush()
            except Exception:
                pass
