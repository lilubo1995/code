# -*- coding: utf-8 -*-
"""
warm_probe.py —— 网络当 CP-SAT 的“快速起点”有没有用（VM 小样本）。

同一个算例，用 4 种初解热启动 CP-SAT，各精修 TL 秒，记录精修过程中每次找到更好解的时刻：
  LFT   单一规则（约 0.01 s）
  net   选工序网络只用网络（3.8，约 0.1 s）
  act1  便宜推演（约 0.5 s）
  act   act-pilot（约 5 s）
两种比法：
  同样精修时间：只看 CP-SAT 求解时间 t 秒后的工期；
  同样总时间：总时间 = 出初解耗时 + 建模耗时 + 求解时间（act-pilot 的 5 秒要算进去）。
样本：测试集 j90 每 36 个取 1 个（4 例），j120 每 23 个取 1 个（8 例）。CP-SAT 在 VM 上只有 2 线程，比本机弱，结论只作方向判断。

用法：python3 warm_probe.py --run [--budget 150]   分块跑（缓存 06_实验结果\CP-SAT求解器\_warm）
      python3 warm_probe.py --merge
"""
import os
import sys
import glob
import time
import pickle
import argparse
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
import act_pilot as A
import act1 as A1
import cpsat3d as C

OUT = os.path.join(C.OUT, '_warm')
TL = 20
WORKERS = 2
STARTS = ['LFT', 'net', 'act1', 'act']
LAB = {'LFT': 'LFT', 'net': '网络', 'act1': 'act-1', 'act': 'act-pilot'}
SOLVE_T = [0, 1, 2, 5, 10, 20]
TOTAL_T = [2, 5, 10, 20]
_model = None


def sample():
    import train_dqn as T
    te = T.list_instances()['test']
    return [t for t in te if t[0] == 'j90'][::36] + [t for t in te if t[0] == 'j120'][::23]


def start_sol(name, I):
    global _model
    if name == 'net':
        import act_net as N
        if _model is None:
            import torch
            torch.set_num_threads(1)
            _model, _ = N.load_best(N.CKPT)          # 加载模型只算一次，不计入耗时
        t0 = time.time()
        ms, S, F, P, _ = N.run_net(_model, I, 1)
    else:
        t0 = time.time()
        if name == 'LFT':
            lft = rl_env.ACTIONS.index('LFT')
            ms, S, F, P, _ = rl_env.run_policy(I, lambda s: lft)
        elif name == 'act1':
            ms, S, F, P, _ = A1.run_act1(I)
        else:
            ms, S, F, P, _ = A.run_act_pilot(I)
    return ms, S, F, P, time.time() - t0


def run_one(task, base):
    s_, nm, f = task
    I = sd.load_instance(f)
    lb = int(float(base[nm]['LB']))
    rec = {'set': s_, 'start': {}, 't_start': {}, 'build': {}, 'trace': {}, 'final': {}, 'status': {}, 'viol': 0}
    for st in STARTS:
        ms, S, F, P, ts = start_sol(st, I)
        rec['viol'] += sum(sd.check(I, S, F, P, space=True).values())
        tr = []
        w0 = time.time()
        r = C.solve(I, TL, WORKERS, lb=lb, hint=(S, P), ub=ms, trace=tr)
        rec['build'][st] = time.time() - w0 - r['t']
        rec['start'][st], rec['t_start'][st], rec['trace'][st] = ms, ts, tr
        rec['status'][st] = r['status']
        rec['final'][st] = r['ms'] if r['ms'] is not None else ms
        if r['S'] is not None:
            rec['viol'] += sum(sd.check(I, r['S'], r['F'], r['P'], space=True).values())
    with open(os.path.join(OUT, nm + '.pkl'), 'wb') as fh:
        pickle.dump(rec, fh)
    return nm, rec


def run(budget):
    os.makedirs(OUT, exist_ok=True)
    base = C.load_base()
    have = set(os.path.splitext(os.path.basename(f))[0] for f in glob.glob(os.path.join(OUT, '*.pkl')))
    tasks = [t for t in sample() if t[1] not in have]
    t0 = time.time()
    done = 0
    for t in tasks:
        if time.time() - t0 + 4 * TL + 12 > budget:
            break
        nm, r = run_one(t, base)
        done += 1
        print('  %s 初解 %s → %d 秒后 %s  viol=%d' % (
            nm, '/'.join(str(r['start'][s]) for s in STARTS), TL, '/'.join(str(r['final'][s]) for s in STARTS),
            r['viol']), flush=True)
    print('warm: 本次 %d，剩 %d，%.0fs' % (done, len(tasks) - done, time.time() - t0), flush=True)


def value_at(rec, st, t):
    """CP-SAT 求解 t 秒时的最好工期（t<0 表示初解还没出来）"""
    if t < 0:
        return None
    v = rec['start'][st]
    for (tt, obj) in rec['trace'][st]:
        if tt <= t:
            v = min(v, obj)
    return v


def merge():
    base = C.load_base()
    best = {}
    for f in glob.glob(os.path.join(C.CACHE, '*.pkl')):
        with open(f, 'rb') as fh:
            r = pickle.load(fh)
        best[r['name']] = r['ms']
    rows = {}
    for f in glob.glob(os.path.join(OUT, '*.pkl')):
        nm = os.path.splitext(os.path.basename(f))[0]
        with open(f, 'rb') as fh:
            rows[nm] = pickle.load(fh)
        rows[nm]['LFTcsv'] = float(base[nm]['LFT'])
        rows[nm]['best120'] = best.get(nm)
    names = sorted(rows)
    red = lambda r, v: 100.0 * (r['LFTcsv'] - v) / r['LFTcsv']
    L = ['网络当 CP-SAT 起点（VM 小样本，%d 例：j90 %d / j120 %d；CP-SAT 2 线程，每种起点精修 %d 秒）' % (
        len(names), sum(rows[n]['set'] == 'j90' for n in names), sum(rows[n]['set'] == 'j120' for n in names), TL),
         '数字 = 比 LFT 短多少（越大越好）', '']
    L.append('一、初解本身：比 LFT 短 / 出初解耗时')
    for st in STARTS:
        L.append('  %-10s %6.2f%%   %.2f s' % (LAB[st], np.mean([red(rows[n], rows[n]['start'][st]) for n in names]),
                                              np.mean([rows[n]['t_start'][st] for n in names])))
    L.append('  建模耗时（各起点相同，取每例 4 次里最小的，避开首次 import 的开销）%.2f s；参考：本机 8 线程 120 秒的 CP-SAT %.2f%%' % (
        np.mean([min(rows[n]['build'].values()) for n in names]),
        np.mean([red(rows[n], rows[n]['best120']) for n in names if rows[n]['best120']])))
    L += ['', '二、同样精修时间：CP-SAT 求解 t 秒后', '  %-10s' % '起点' + ''.join('%9s' % ('t=%ds' % t) for t in SOLVE_T)]
    for st in STARTS:
        L.append('  %-10s' % LAB[st] + ''.join('%8.2f%%' % np.mean([red(rows[n], value_at(rows[n], st, t))
                                                                    for n in names]) for t in SOLVE_T))
    L += ['', '三、同样总时间（出初解 + 建模 + 求解）；“—” = 有算例此时初解还没出来',
          '  %-10s' % '起点' + ''.join('%9s' % ('总%ds' % t) for t in TOTAL_T)]
    for st in STARTS:
        cells = []
        for T in TOTAL_T:
            vs = [value_at(rows[n], st, T - rows[n]['t_start'][st] - min(rows[n]['build'].values())) for n in names]
            cells.append('%9s' % '—' if any(v is None for v in vs) else
                         '%8.2f%%' % np.mean([red(rows[n], v) for n, v in zip(names, vs)]))
        L.append('  %-10s' % LAB[st] + ''.join(cells))
    L += ['', '四、逐例：网络起点 对 其他起点（精修 %d 秒后工期，更好/持平/更差）' % TL]
    for st in ('LFT', 'act1', 'act'):
        x = np.array([rows[n]['final'][st] - rows[n]['final']['net'] for n in names])
        L.append('  网络 对 %-10s %d / %d / %d   网络平均短 %.2f 天' % (LAB[st], (x > 0).sum(), (x == 0).sum(),
                                                                (x < 0).sum(), x.mean()))
    for s_ in ('j90', 'j120'):
        sel = [n for n in names if rows[n]['set'] == s_]
        if sel:
            L.append('  %-5s 精修 %d 秒后：' % (s_, TL) + '  '.join('%s %.2f%%' % (LAB[st], np.mean(
                [red(rows[n], rows[n]['final'][st]) for n in sel])) for st in STARTS))
    L.append('  违约数：%d' % sum(rows[n]['viol'] for n in names))
    txt = '\n'.join(L) + '\n'
    with open(os.path.join(C.OUT, '网络当起点_小样本.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt)
    print(txt)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', action='store_true')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    a = ap.parse_args()
    if a.run:
        run(a.budget)
    if a.merge:
        merge()
