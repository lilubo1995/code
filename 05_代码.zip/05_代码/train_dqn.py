# -*- coding: utf-8 -*-
"""
train_dqn.py —— 在紧空间算例（U5S6）上训练 DQN“规则选择器”，并与单一规则 / 事后最优规则对比

划分：每个参数组 10 个算例，第 1–6 个训练，第 7 个验证（挑最好的网络），第 8–10 个测试（训练全程没见过）。
用法（每条命令 <170 秒，可反复调用，断点续训）：
  python3 train_dqn.py --train 150      训练 150 秒，存检查点
  python3 train_dqn.py --eval           在测试集评估，写 06_实验结果/DQN规则选择/
"""
import os
import sys
import csv
import glob
import time
import pickle
import argparse
from collections import defaultdict
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env
from dqn import Agent

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, '03_算例', '紧空间_U5S6')
RUNS = os.path.join(ROOT, '06_实验结果', '紧空间_U5S6_full', 'runs.csv')
OUT = os.path.join(ROOT, '06_实验结果', 'DQN规则选择')
CKPT = os.environ.get('DQN_CKPT', os.path.join(OUT, 'checkpoint.pkl'))
SETS = ['j30', 'j60', 'j90', 'j120']
EPS_EPISODES = 6000          # ε 从 1 线性降到 0.05 所用回合数


def split_of(name):
    k = int(name.split('_')[1])
    return 'train' if k <= 6 else ('val' if k == 7 else 'test')


def list_instances():
    out = defaultdict(list)
    for s in SETS:
        for f in sorted(glob.glob(os.path.join(DATA, s + '_integer', '*.sm'))):
            name = os.path.splitext(os.path.basename(f))[0]
            out[split_of(name)].append((s, name, f))
    return out


_envs = {}


def get_env(f):
    if f not in _envs:
        _envs[f] = rl_env.Env(sd.load_instance(f))
    return _envs[f]


def greedy_ms(agent, f):
    env = get_env(f)
    s = env.reset()
    while not env.done:
        s, _, _ = env.step(agent.greedy(s))
    return env.makespan()


def evaluate(agent, items):
    return float(np.mean([greedy_ms(agent, f) / float(get_env(f).I.cpm) for _, _, f in items]))


def save(state):
    tmp = CKPT + '.tmp'
    with open(tmp, 'wb') as fh:
        pickle.dump(state, fh, protocol=4)
    os.replace(tmp, CKPT)


def train(seconds, seed=0):
    os.makedirs(OUT, exist_ok=True)
    inst = list_instances()
    if os.path.exists(CKPT):
        with open(CKPT, 'rb') as fh:
            state = pickle.load(fh)
    else:
        state = {'agent': Agent(rl_env.N_FEAT, len(rl_env.ACTIONS), seed=seed),
                 'best_val': None, 'best_params': None, 'curve': [], 'rng': np.random.default_rng(seed)}
    agent, rng = state['agent'], state['rng']
    val = inst['val'][::2]                       # 验证集取一半，节省时间
    tr = inst['train']
    t0 = time.time()
    ep0 = agent.episodes
    losses = []
    rets = []
    while time.time() - t0 < seconds:
        _, _, f = tr[int(rng.integers(len(tr)))]
        env = get_env(f)
        eps = max(0.05, 1.0 - agent.episodes / float(EPS_EPISODES))
        s = env.reset()
        G = 0.0
        while not env.done:
            a = agent.act(s, eps)
            s2, r, done = env.step(a)
            agent.remember(s, a, r, s2, done)
            G += r
            s = s2
            if agent.size >= 2000:
                losses.append(agent.learn())
        agent.episodes += 1
        rets.append(G)
        if agent.episodes % 1000 == 0:
            v = evaluate(agent, val)
            state['curve'].append((agent.episodes, eps, float(np.mean(rets[-1000:])), v))
            if state['best_val'] is None or v < state['best_val']:
                state['best_val'] = v
                state['best_params'] = {k: x.copy() for k, x in agent.net.p.items()}
            print('ep %d eps %.2f ret %.4f val(ms/CPM) %.4f best %.4f loss %.4f' %
                  (agent.episodes, eps, np.mean(rets[-1000:]), v, state['best_val'],
                   np.mean(losses[-2000:]) if losses else 0), flush=True)
    save(state)
    print('本块训练 %d 回合，累计 %d 回合，用时 %.0fs' % (agent.episodes - ep0, agent.episodes, time.time() - t0))


def load_rule_table():
    """runs.csv 中 S4 策略下 36 条规则的工期 -> {instance: {rule: ms}}，以及 LB"""
    tab = defaultdict(dict)
    lb = {}
    with open(RUNS, encoding='utf-8-sig') as fh:
        for row in csv.DictReader(fh):
            if row['strategy'] == 'S4':
                tab[row['instance']][row['rule']] = int(row['makespan'])
                lb[row['instance']] = int(row['LB'])
    return tab, lb


def do_eval(part=None):
    """part=(k,n)：只评估测试集的第 k 份，结果缓存；不给 part 则汇总"""
    with open(CKPT, 'rb') as fh:
        state = pickle.load(fh)
    agent = state['agent']
    agent.net.p = state['best_params']
    inst = list_instances()
    tab, lb = load_rule_table()
    test = inst['test']
    if part is not None:
        k, n = part
        rows = []
        rng = np.random.default_rng(123 + k)
        for s, name, f in test[k::n]:
            env = get_env(f)
            t0 = time.time()
            ms_dqn = greedy_ms(agent, f)
            dt = (time.time() - t0) * 1000
            # 采样 10 次（softmax(Q/τ)）取最好，用来和“10 条规则各跑一次取最好”公平对比
            best10 = ms_dqn
            for _ in range(9):
                e2 = get_env(f)
                o = e2.reset()
                while not e2.done:
                    q = agent.net.q(o[None, :])[0]
                    p = np.exp((q - q.max()) / 0.02)
                    p /= p.sum()
                    o, _, _ = e2.step(int(rng.choice(len(p), p=p)))
                best10 = min(best10, e2.makespan())
                # 可行性复核
                v = sd.check(e2.I, e2.S, e2.F, e2.P, space=True)
                assert sum(v.values()) == 0, (name, v)
            ms, S, F, P, _ = rl_env.run_policy(env.I, agent.greedy)
            v = sd.check(env.I, S, F, P, space=True)
            assert sum(v.values()) == 0, (name, v)
            rows.append((s, name, ms_dqn, best10, dt, sum(v.values())))
        with open(os.path.join(OUT, '_eval_p%dof%d.pkl' % (k, n)), 'wb') as fh:
            pickle.dump(rows, fh)
        print('part %d/%d done: %d' % (k, n, len(rows)))
        return
    rows = []
    for f in sorted(glob.glob(os.path.join(OUT, '_eval_p*.pkl'))):
        with open(f, 'rb') as fh:
            rows += pickle.load(fh)
    rows = list({r[1]: r for r in rows}.values())
    assert len(rows) == len(test), (len(rows), len(test))
    pil = load_pilot()
    # 训练集上平均最好的单一规则（只用训练集挑，避免偷看测试集）
    tr_names = [n for _, n, _ in inst['train']]
    rule_mean = {r: np.mean([tab[n][r] / float(lb[n]) for n in tr_names]) for r in sd.RULES}
    best_rule = min(rule_mean, key=rule_mean.get)
    best_act = min(rl_env.ACTIONS, key=lambda r: rule_mean[r])
    out_rows = []
    per = defaultdict(lambda: defaultdict(list))
    for s, name, ms_dqn, best10, dt, viol in rows:
        t = tab[name]
        L = float(lb[name])
        rec = {'set': s, 'instance': name, 'LB': lb[name],
               'LFT': t['LFT'], 'best_rule(' + best_rule + ')': t[best_rule],
               'oracle10': min(t[r] for r in rl_env.ACTIONS), 'oracle36': min(t.values()),
               'DQN': ms_dqn, 'DQN_best10': best10, 'pilot': pil[name]['pilot_ms'],
               'DQN_ms': round(dt, 1), 'pilot_s': round(pil[name]['pilot_sec'], 2),
               'violations': viol + pil[name]['viol']}
        out_rows.append(rec)
        for key in ['LFT', 'best_rule(' + best_rule + ')', 'oracle10', 'oracle36', 'DQN', 'DQN_best10', 'pilot']:
            per[s][key].append(rec[key] / L - 1)
            per['ALL'][key].append(rec[key] / L - 1)
        per[s]['win'].append(ms_dqn < t[best_rule])
        per[s]['lose'].append(ms_dqn > t[best_rule])
        per['ALL']['win'].append(ms_dqn < t[best_rule])
        per['ALL']['lose'].append(ms_dqn > t[best_rule])
    with open(os.path.join(OUT, '测试集逐例结果.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out_rows[0].keys()))
        w.writeheader()
        w.writerows(sorted(out_rows, key=lambda r: (SETS.index(r['set']), r['instance'])))
    keys = ['LFT', 'best_rule(' + best_rule + ')', 'DQN', 'oracle10', 'DQN_best10', 'oracle36', 'pilot']
    lines = ['DQN 规则选择器 —— 紧空间 U5S6 测试集（每参数组第 8–10 个算例，训练时未见过）',
             '',
             '指标：相对下界差距 = (工期 − LB)/LB，LB = max(普通RCPSP已证最优/官方下界, 关键路径)。',
             'LB 不含空间约束，所以这个差距是“最优性差距的上界”，真实最优解可能离 LB 还很远。',
             '所有方案均用 S4 放位置，并经 check() 复核：紧前、资源、三维不重叠、边界违规数 = 0。',
             '',
             '对比方：',
             '  LFT            单一规则 LFT 跑一次',
             '  best_rule      在训练集上平均最好的那条单一规则（36 条中挑，%s），跑一次' % best_rule,
             '  DQN            每个决策时刻由网络从 10 条规则中选一条，跑一次（贪心）',
             '  oracle10       10 条候选规则各跑一次、事后取最好（需要跑 10 次）',
             '  DQN_best10     DQN 按 Q 值概率采样 10 次取最好（同样跑 10 次，和 oracle10 公平对比）',
             '  oracle36       36 条规则各跑一次取最好（需要跑 36 次）',
             '  pilot          仿真沙盒前瞻（教师）：每个决策点把 10 条规则各推演到底，选最好的走一步',
             '',
             'DQN 网络的训练方式：先用 pilot 在训练集上产生 (状态, 10 个动作各自推演到底的工期) 标签，',
             '对 Q 网络做监督回归（Q 值蒸馏），按验证集挑最好的参数。纯 DQN 从零试错训练 6911 回合',
             '在验证集上未超过最好单一规则（见 checkpoint_纯DQN从零.pkl），因此改用教师蒸馏。',
             '',
             '%-6s %6s ' % ('集合', '算例数') + ' '.join('%14s' % k[:14] for k in keys) + '   DQN胜/负(对best_rule)']
    for s in SETS + ['ALL']:
        d = per[s]
        lines.append('%-6s %6d ' % (s, len(d['DQN'])) +
                     ' '.join('%13.2f%%' % (100 * np.mean(d[k])) for k in keys) +
                     '   %d / %d' % (sum(d['win']), sum(d['lose'])))
    lines += ['', '蒸馏训练曲线（验证集 = 每参数组第 7 个算例，指标 = 平均 工期/CPM）：']
    for ep, acc, v in state.get('distill_curve', []):
        lines.append('  epoch %3d  训练集上选中教师最优动作的比例 %.3f  验证 %.4f' % (ep, acc, v))
    lines.append('最优验证值 %.4f（测试使用该时刻的网络参数）' % state['best_val'])
    lines.append('')
    lines.append('平均耗时（单个算例）：')
    for s in SETS:
        rs = [r for r in out_rows if r['set'] == s]
        lines.append('  %-5s DQN %.0f ms    pilot %.2f s' % (s, np.mean([r['DQN_ms'] for r in rs]),
                                                       np.mean([r['pilot_s'] for r in rs])))
    txt = '\n'.join(lines)
    with open(os.path.join(OUT, '结果报告.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)


# ----------------------------------------------------------------------------------------------
# 前瞻仿真教师：收集 (状态, 10 个动作各自推演到底的工期) 作为 Q 值标签
# ----------------------------------------------------------------------------------------------
def _collect_one(item):
    s, name, f = item
    I = sd.load_instance(f)
    rec = []
    t0 = time.time()
    ms, S, F, P, nd = rl_env.run_pilot(I, rec)
    dt = time.time() - t0
    v = sd.check(I, S, F, P, space=True)
    X = np.array([r[0] for r in rec]) if rec else np.zeros((0, rl_env.N_FEAT))
    Y = np.array([r[1] for r in rec]) if rec else np.zeros((0, len(rl_env.ACTIONS)))
    return {'set': s, 'name': name, 'split': split_of(name), 'pilot_ms': ms, 'pilot_sec': dt,
            'viol': sum(v.values()), 'X': X, 'Y': Y}


def collect(k, n, procs=2, budget=140):
    """可续跑：已完成的算例存在 _pilot_p{k}of{n}.pkl，超出时间预算就先保存退出，再次调用接着做"""
    from multiprocessing import Pool
    os.makedirs(OUT, exist_ok=True)
    inst = list_instances()
    items = (inst['train'] + inst['val'] + inst['test'])[k::n]
    path = os.path.join(OUT, '_pilot_p%dof%d.pkl' % (k, n))
    res = []
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            res = pickle.load(fh)
    done = set(r['name'] for r in res)
    todo = [it for it in items if it[1] not in done]
    t0 = time.time()
    pool = Pool(procs)
    try:
        for r in pool.imap_unordered(_collect_one, todo, chunksize=1):
            res.append(r)
            if time.time() - t0 > budget:
                break
    finally:
        pool.terminate()
    with open(path + '.tmp', 'wb') as fh:
        pickle.dump(res, fh, protocol=4)
    os.replace(path + '.tmp', path)
    print('pilot part %d/%d: %d/%d 例%s, %.0fs, 违规 %d' % (
        k, n, len(res), len(items), '' if len(res) == len(items) else '（未完，再跑一次）',
        time.time() - t0, sum(r['viol'] for r in res)))


def load_pilot():
    res = {}
    for f in glob.glob(os.path.join(OUT, '_pilot_p*.pkl')):
        with open(f, 'rb') as fh:
            for r in pickle.load(fh):
                res[r['name']] = r
    return res


def distill(epochs=60, seed=0):
    """用教师的 Q 值标签做监督回归（Q 值蒸馏），得到初始 Q 网络；按验证集挑最好的 epoch"""
    pil = load_pilot()
    inst = list_instances()
    tr = [pil[n] for _, n, _ in inst['train'] if n in pil]
    X = np.concatenate([r['X'] for r in tr])
    Y = np.concatenate([r['Y'] for r in tr])
    Y = Y - Y.min(axis=1, keepdims=True)          # 只学“相对最好动作差多少”，消除算例间量纲差异
    print('训练样本（决策点）%d，来自 %d 个训练算例' % (len(X), len(tr)))
    agent = Agent(rl_env.N_FEAT, len(rl_env.ACTIONS), seed=seed)
    # 网络输出“代价”（越小越好），DQN 中取 argmax，所以学 −代价
    T = -Y * 10.0
    rng = np.random.default_rng(seed)
    val = inst['val']
    best, best_p, curve = None, None, []
    t0 = time.time()
    for ep in range(epochs):
        idx = rng.permutation(len(X))
        for i in range(0, len(X), 128):
            b = idx[i:i + 128]
            q = agent.net.q(X[b])
            agent.net.update(X[b], (q - T[b]) / len(b), lr=1e-3)
        if ep % 5 == 4 or ep == epochs - 1:
            v = evaluate(agent, val)
            q = agent.net.q(X)
            acc = float(np.mean(Y[np.arange(len(X)), np.argmax(q, 1)] <= 1e-9))
            curve.append((ep + 1, acc, v))
            if best is None or v < best:
                best, best_p = v, {k: x.copy() for k, x in agent.net.p.items()}
            print('epoch %d  训练集选中教师最优动作比例 %.3f  验证 ms/CPM %.4f  (%.0fs)' % (ep + 1, acc, v, time.time() - t0),
                  flush=True)
        if time.time() - t0 > 140:
            break
    agent.net.p = best_p
    agent.tgt = {k: x.copy() for k, x in best_p.items()}
    state = {'agent': agent, 'best_val': best, 'best_params': best_p, 'curve': [],
             'distill_curve': curve, 'rng': np.random.default_rng(seed)}
    save(state)
    print('蒸馏完成，最优验证 %.4f' % best)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--train', type=float, default=0)
    ap.add_argument('--eval', action='store_true')
    ap.add_argument('--collect', type=str, default=None)
    ap.add_argument('--distill', type=int, default=0)
    ap.add_argument('--part', type=str, default=None)
    a = ap.parse_args()
    if a.collect:
        k, n = (int(x) for x in a.collect.split('/'))
        collect(k, n)
    if a.distill:
        distill(a.distill)
    if a.train > 0:
        train(a.train)
    if a.eval:
        do_eval(tuple(int(x) for x in a.part.split('/')) if a.part else None)
