# -*- coding: utf-8 -*-
"""
disturb.py —— 第 4 步：扰动下的执行仿真与重调度对比（框架 4.2 / 申请书研究内容二）

扰动（每个算例生成 100 个随机场景，四种策略用同一批场景，公平对比）：
  ① 工期波动：每道工序以 30% 概率延长 round(d × U(0.1, 0.5)) 天（至少 1 天）。
     延长量事先不知道，到计划完工时刻才发现“还没干完”，此时才知道真实完工时间。
  ② 资源中断：每个场景 1~3 次。随机挑一种资源，在 [0, 0.8×名义工期] 内随机时刻起，
     可用量减少 30%~50%，持续 3~10 天。中断发生时才知道（同时知道修复时间）。
     已开工的工序继续做（不可抢占），中断期间只是不能新开占用该资源的工序。
执行规则：工序开工时才确定位置（用 S4 找），开工后位置固定到完工。

四种策略：
  CPM顺延      传统做法：按“不考虑空间”的 LFT 计划，计划时刻到了才开工，资源/空间不够就往后顺延
  S4基线右移   先用 S4+LFT 排出考虑空间的基线计划，执行时同样按计划时刻和顺序，冲突就顺延
  LFT在线派工  不固定计划，每个时刻按 LFT 规则重新派工（等于“按规则实时重排”）
  pilot在线重排 每个决策点在数字孪生沙盒里把 10 条规则各推演到底，选最好的执行一步。
               推演时只用“当前已知的信息”：未发现的延误按名义工期算，未发生的中断不知道。

10-26 补充 3 种在线策略（速度档，候选同 act-pilot）：act-1在线重排 / 网络在线派工 / 网络前2在线重排。
  本机 run_disturb_net.bat：run_pool 只补跑缺的策略，旧 5 种结果不动（备份在 扰动实验\五策略版备份_1022）。

用法（每条命令 <170 秒，可反复调用，断点续跑）：
  python3 disturb.py --selftest
  python3 disturb.py --run j60 --part 0/2 [--mode mix|dur|res] [--budget 150]
  python3 disturb.py --merge
"""
import os
import sys
import csv
import copy
import glob
import time
import zlib
import pickle
import argparse
from collections import defaultdict
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched3d as sd
import rl_env

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, '03_算例', '紧空间_U5S6')
OUT = os.path.join(ROOT, '06_实验结果', '扰动实验')
N_SCEN = 100
P_DELAY = 0.3
DELAY_FRAC = (0.1, 0.5)
N_DISR = (1, 3)
DISR_LEN = (3, 10)
DISR_FRAC = (0.3, 0.5)
POLICIES = ['传统顺延', 'S4基线右移', 'LFT在线派工', 'pilot在线重排', 'act-pilot在线重排',
            # 10-26 补充：在线重排的速度档（候选与 act-pilot 相同，只是挑法更便宜）
            'act-1在线重排',       # 每个候选只用 LFT 推演 1 次（无网络）
            '网络在线派工',        # 选工序网络直接挑，不推演（最快）
            '网络前2在线重排']     # 网络排前 2 的候选各推演 10 条规则，挑最好
NEW_POLICIES = POLICIES[5:]
LFT = rl_env.ACTIONS.index('LFT')


# ----------------------------------------------------------------------------------------------
# 1. 带扰动的执行环境（在 rl_env.Env 上加：真实工期、资源中断、按计划执行模式）
# ----------------------------------------------------------------------------------------------
class DEnv(rl_env.Env):
    def setup(self, scen=None, plan=None):
        """scen=None 表示无扰动；plan=(plan_S, rank) 表示按计划顺延执行，None 表示按规则派工"""
        self.cap = list(self.I.R)
        self.extra = dict(scen['extra']) if scen else {}           # 隐藏信息：真实延长量
        self.pending = sorted(scen['disr']) if scen else []       # 隐藏信息：未来的中断
        self.known = []                                            # 已发生、未修复的中断 (end, k, c)
        self.revealed = set()
        self.plan = plan
        self.space_conf = 0
        self.t = 0
        self._apply_disr()
        return self.reset()

    def _apply_disr(self):
        t = self.t
        still = []
        for e in self.known:
            if e[0] <= t:
                self.cap[e[1]] += e[2]
            else:
                still.append(e)
        self.known = still
        while self.pending and self.pending[0][0] <= t:
            tau, end, k, c = self.pending.pop(0)
            if end > t:
                self.cap[k] -= c
                self.known.append((end, k, c))

    def _res_ok(self, j):
        rj = self.I.r[j]
        for k in range(self.I.K):
            if self.used[k] + rj[k] > self.cap[k]:
                return False
        return True

    def _pass(self, rule):
        if self.plan is None:
            return rl_env.Env._pass(self, rule)
        pS, rank = self.plan
        cand = sorted([j for j in self.elig if pS[j] <= self.t], key=lambda j: (pS[j], rank[j]))
        self._pass_order(cand)

    def _pass_order(self, cand):
        I = self.I
        failed = []
        for j in cand:
            if not self._res_ok(j):
                continue
            pos = None
            if I.d[j] > 0 and I.vol[j] > 0:
                l, w, h = I.dim[j]
                if not any(l >= a and w >= b and h >= c for a, b, c in failed):
                    pos = sd.find_pos_complete(l, w, h, list(self.boxes.values()), I.L, I.W, I.H)
                if pos is None:
                    failed.append((l, w, h))
                    self.space_conf += 1
                    continue
            self._start(j, pos)

    def _advance(self):
        I = self.I
        if self.remaining == 0:
            self.done = True
            return
        ts = [self.F[j] for j in self.active] + [p[0] for p in self.pending] + [e[0] for e in self.known]
        if self.plan is not None:
            pS = self.plan[0]
            ts += [pS[j] for j in self.elig]
        ts = [x for x in ts if x > self.t]
        if not ts:
            raise RuntimeError('执行停滞')
        self.t = min(ts)
        self._apply_disr()
        keep = []
        for j in self.active:
            if self.F[j] <= self.t:
                if j in self.extra and j not in self.revealed:   # 到计划完工时刻才发现延误
                    self.revealed.add(j)
                    self.F[j] = self.t + self.extra[j]
                    keep.append(j)
                    continue
                for k in range(I.K):
                    self.used[k] -= I.r[j][k]
                self.boxes.pop(j, None)
                for s in I.succ[j]:
                    self.npred[s] -= 1
                    if self.npred[s] == 0:
                        self.elig.add(s)
            else:
                keep.append(j)
        self.active = keep
        self._zero()
        if self.remaining == 0:
            self.done = True

    def clone(self):
        """沙盒副本：只带已知信息（已发现的延误、正在发生的中断），看不到未来"""
        e = DEnv.__new__(DEnv)
        e.__dict__.update(self.__dict__)
        e.S, e.F, e.P = self.S[:], self.F[:], self.P[:]
        e.npred = self.npred[:]
        e.elig = set(self.elig)
        e.active = self.active[:]
        e.used = self.used[:]
        e.boxes = dict(self.boxes)
        e.cap = self.cap[:]
        e.known = self.known[:]
        e.pending = []
        e.extra = {}
        e.revealed = set(self.revealed)
        e.plan = None
        return e


# ----------------------------------------------------------------------------------------------
# 2. 场景、计划、策略
# ----------------------------------------------------------------------------------------------
def make_scen(I, name, i, T0, mode):
    rng = np.random.default_rng(zlib.crc32(('%s#%d' % (name, i)).encode('utf-8')))
    extra, disr = {}, []
    if mode in ('mix', 'dur'):
        for j in range(I.n):
            if I.d[j] > 0 and rng.random() < P_DELAY:
                extra[j] = max(1, int(round(I.d[j] * rng.uniform(*DELAY_FRAC))))
    if mode in ('mix', 'res'):
        ks = [k for k in range(I.K) if I.R[k] > 0]
        for _ in range(int(rng.integers(N_DISR[0], N_DISR[1] + 1))):
            k = ks[int(rng.integers(len(ks)))]
            tau = int(rng.integers(0, int(0.8 * T0) + 1))
            ln = int(rng.integers(DISR_LEN[0], DISR_LEN[1] + 1))
            c = max(1, int(round(I.R[k] * rng.uniform(*DISR_FRAC))))
            disr.append((tau, tau + ln, k, c))
    return {'extra': extra, 'disr': disr}


def make_plans(I):
    plans = {}
    for pol, mode in (('传统顺延', None), ('S4基线右移', 'S4')):
        S, F, P, order, st = sd.Scheduler(I, 'LFT', mode).run()
        rank = [0] * I.n
        for i, j in enumerate(order):
            rank[j] = i
        plans[pol] = (S, rank, max(F))
    return plans


def run_policy(env, pol, scen, plans):
    if pol in ('传统顺延', 'S4基线右移'):
        S, rank, _ = plans[pol]
        env.setup(scen, (S, rank))
        while not env.done:
            env._pass(None)
            env._advance()
    elif pol == 'LFT在线派工':
        env.setup(scen, None)
        while not env.done:
            env.step(LFT)
    elif pol == 'pilot在线重排':
        env.setup(scen, None)
        while not env.done:
            v = env.rollout_values()
            env.step(int(np.argmin(v)))
    elif pol == 'act-pilot在线重排':
        import act_pilot                      # 局部导入，避免与 act_pilot 互相导入
        env.setup(scen, None)
        act_pilot.act_loop(env)
    elif pol in NEW_POLICIES:
        env.setup(scen, None)
        cand_loop(env, pol)
    else:
        raise ValueError(pol)
    return env.makespan(), env.S, env.F, env.P, env.space_conf


_NET = None


def net_model():
    """每个进程只加载一次选工序网络（torch 版，只在 selftest 里当参照用）"""
    global _NET
    if _NET is None:
        import torch
        torch.set_num_threads(1)
        import act_net as N
        _NET, _ = N.load_best(N.CKPT)
    return _NET


_NETNP = None


def net_np():
    """选工序网络的 numpy 推理版（netnp.py，与平台同一份），不需要 torch，只要 numpy"""
    global _NETNP
    if _NETNP is None:
        import act_net as N
        import netnp
        _NETNP = netnp.NetNP(N.CKPT)
    return _NETNP


def cand_loop(env, pol):
    """在已 setup 好的扰动环境上逐道决策直到完工。候选 = 10 条规则各自的首选工序（同 act-pilot）。
    与静态程序逐行对应：act-1 = act1.run_act1，网络 = act_net.run_net(topk=1/2)，
    所以无扰动时工期必须与它们完全相同（selftest 检查）。推演用 clone()，只看已知信息。"""
    import act_pilot as A
    import graph_feats as GF
    net = g = None
    if pol != 'act-1在线重排':
        net = net_np()
        g = net.graph(env)
    NA = len(rl_env.ACTIONS)
    while not env.done:
        while True:
            ok = {}
            for j in env.elig:
                f, pos = A.place(env, j)
                if f:
                    ok[j] = pos
            if not ok:
                break
            if len(ok) == 1:
                j = next(iter(ok))
                env._start(j, ok[j])
                continue
            cand = []
            for a in range(NA):
                key = env.keys[rl_env.ACTIONS[a]]
                j = min(ok, key=lambda x: key[x])
                if j not in cand:
                    cand.append(j)
            if len(cand) == 1:
                j = cand[0]
            elif pol == 'act-1在线重排':
                best = None
                for c in cand:
                    e = env.clone()
                    e._start(c, ok[c])
                    v = A.rollout_from(e, LFT)
                    if best is None or v < best[1]:
                        best = (c, v)
                j = best[0]
            else:
                s = net.score(g, GF.dyn_feats(env), env.obs().astype(np.float32), ok, cand)
                order = [cand[i] for i in np.argsort(-s)]
                if pol == '网络在线派工':
                    j = order[0]
                else:
                    best = None
                    for c in order[:2]:
                        e = env.clone()
                        e._start(c, ok[c])
                        v = min(A.rollout_from(e, a) for a in range(NA))
                        if best is None or v < best[1]:
                            best = (c, v)
                    j = best[0]
            env._start(j, ok[j])
        env._advance()
        env._to_decision(rl_env.ACTIONS[LFT])


def n_viol(I, scen, S, F, P):
    I2 = copy.copy(I)
    ex = scen['extra'] if scen else {}
    I2.d = [I.d[j] + ex.get(j, 0) for j in range(I.n)]
    v = sd.check(I2, S, F, P, space=True)
    return sum(v.values())


def list_items(set_name):
    """测试集（训练 DQN 时没用过）：每个参数组取第 8 个算例"""
    fs = sorted(glob.glob(os.path.join(DATA, set_name + '_integer', '*_8.sm')))
    return [(os.path.splitext(os.path.basename(f))[0], f) for f in fs]


# ----------------------------------------------------------------------------------------------
# 3. 主流程
# ----------------------------------------------------------------------------------------------
def run_part(set_name, part, mode, budget):
    os.makedirs(OUT, exist_ok=True)
    kk, n = (int(x) for x in part.split('/'))
    path = os.path.join(OUT, '_cache_%s_%s_p%dof%d.pkl' % (mode, set_name, kk, n))
    cache = {}
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            cache = pickle.load(fh)
    t00 = time.time()
    items = list_items(set_name)[kk::n]
    stop = False
    for name, f in items:
        if stop:
            break
        I = sd.load_instance(f)
        env = DEnv(I)
        plans = make_plans(I)
        T0 = plans['S4基线右移'][2]
        rec = cache.setdefault(name, {'set': set_name, 'n': I.n, 'cpm': I.cpm, 'T0': T0,
                                      'nom': {}, 'res': {p: {} for p in POLICIES}})
        for pol in POLICIES:
            rec['res'].setdefault(pol, {})
        for pol in POLICIES:
            if pol not in rec['nom']:
                ms, S, F, P, sc = run_policy(env, pol, None, plans)
                rec['nom'][pol] = (ms, sc, n_viol(I, None, S, F, P))
        for i in range(N_SCEN):
            scen = make_scen(I, name, i, T0, mode)
            for pol in POLICIES:
                if i in rec['res'][pol]:
                    continue
                t0 = time.time()
                ms, S, F, P, sc = run_policy(env, pol, scen, plans)
                rec['res'][pol][i] = (ms, sc, n_viol(I, scen, S, F, P), time.time() - t0)
            if time.time() - t00 > budget:
                stop = True
                break
        with open(path + '.tmp', 'wb') as fh:          # 每例存一次，中断也不丢
            pickle.dump(cache, fh, protocol=4)
        os.replace(path + '.tmp', path)
    full = sum(1 for nm, _ in items if nm in cache and is_full(cache[nm]))
    print('%s %s part %s: 完成 %d/%d 例，用时 %.0fs' % (mode, set_name, part, full, len(items), time.time() - t00))


def n_done(rec):
    """一个算例记录里已跑完的（策略×场景）数"""
    return sum(len(rec['res'].get(p, {})) for p in POLICIES)


def is_full(rec):
    return all(len(rec['res'].get(p, {})) == N_SCEN and p in rec['nom'] for p in POLICIES)


def load_recs(mode=None):
    """读所有缓存；同一算例出现在多个缓存里时保留跑得最多的那份。返回 {(mode, name): rec}"""
    out = {}
    for f in glob.glob(os.path.join(OUT, '_cache_*.pkl')):
        md = os.path.basename(f).split('_')[2]
        if mode is not None and md != mode:
            continue
        with open(f, 'rb') as fh:
            for nm, rec in pickle.load(fh).items():
                old = out.get((md, nm))
                if old is None or n_done(rec) > n_done(old):
                    out[(md, nm)] = rec
    return out


def _one_instance(task):
    """多进程用：一个算例的全部场景 × 全部策略。传入已有记录时只补跑缺的策略/场景"""
    mode, set_name, name, f, rec = task
    t0 = time.time()
    I = sd.load_instance(f)
    env = DEnv(I)
    plans = make_plans(I)
    T0 = plans['S4基线右移'][2]
    if rec is None:
        rec = {'set': set_name, 'n': I.n, 'cpm': I.cpm, 'T0': T0, 'nom': {}, 'res': {}}
    for pol in POLICIES:
        rec['res'].setdefault(pol, {})
        if pol not in rec['nom']:
            ms, S, F, P, sc = run_policy(env, pol, None, plans)
            rec['nom'][pol] = (ms, sc, n_viol(I, None, S, F, P))
    for i in range(N_SCEN):
        scen = None
        for pol in POLICIES:
            if i in rec['res'][pol]:
                continue
            if scen is None:
                scen = make_scen(I, name, i, T0, mode)
            t1 = time.time()
            ms, S, F, P, sc = run_policy(env, pol, scen, plans)
            rec['res'][pol][i] = (ms, sc, n_viol(I, scen, S, F, P), time.time() - t1)
    return mode, name, rec, time.time() - t0


def run_pool(mode, sets, workers):
    """Windows 本机多进程全量运行（不受 VM 单条命令时长限制）。
    已跑完的算例跳过；跑了一部分策略的算例（例如新增策略后）只补跑缺的部分。"""
    from multiprocessing import Pool, cpu_count
    os.makedirs(OUT, exist_ok=True)
    old = {nm: rec for (md, nm), rec in load_recs(mode).items()}
    done = {nm for nm, rec in old.items() if is_full(rec)}
    tasks = [(mode, s, nm, f, old.get(nm)) for s in sets for nm, f in list_items(s) if nm not in done]
    tasks.sort(key=lambda x: -int(x[1][1:]))            # 大算例先跑，负载更均衡
    workers = workers or max(1, cpu_count() - 1)
    n_part = sum(1 for x in tasks if x[4] is not None)
    print('待跑 %d 例（其中 %d 例只补跑缺的策略；已完成 %d 例跳过），进程数 %d' %
          (len(tasks), n_part, len(done), workers), flush=True)
    path = os.path.join(OUT, '_cache_%s_win.pkl' % mode)
    cache = {}
    if os.path.exists(path):
        with open(path, 'rb') as fh:
            cache = pickle.load(fh)
    t00 = time.time()
    from progress import Bar
    bar = Bar('disturb', len(tasks))
    bar.update(0)
    with Pool(workers) as pool:
        for k, (md, nm, rec, dt) in enumerate(pool.imap_unordered(_one_instance, tasks), 1):
            cache[nm] = rec
            with open(path + '.tmp', 'wb') as fh:
                pickle.dump(cache, fh, protocol=4)
            os.replace(path + '.tmp', path)
            bar.update(k)
            print('[%d/%d] %s 用时 %.0fs，累计 %.0f 分钟' % (k, len(tasks), nm, dt, (time.time() - t00) / 60), flush=True)
    bar.done()


def selftest():
    """无扰动时，四种策略应与已有程序的结果完全一致"""
    bad = 0
    for set_name in ('j30', 'j60'):
        for name, f in list_items(set_name)[:4]:
            I = sd.load_instance(f)
            env = DEnv(I)
            plans = make_plans(I)
            S, F, P, order, st = sd.Scheduler(I, 'LFT', None).run()
            ref_react = max(sd.reactive(I, S, order)[1])
            ref_s4 = max(sd.Scheduler(I, 'LFT', 'S4').run()[1])
            ref_pilot = rl_env.run_pilot(I)[0]
            import act_pilot
            ref_act = act_pilot.run_act_pilot(I)[0]
            import act1
            import act_net as N
            ref_a1 = act1.run_act1(I)[0]
            ref_net = N.run_net(net_model(), I, 1)[0]
            ref_top2 = N.run_net(net_model(), I, 2)[0]
            got = [run_policy(env, p, None, plans)[0] for p in POLICIES]
            ref = [ref_react, ref_s4, ref_s4, ref_pilot, ref_act, ref_a1, ref_net, ref_top2]
            ok = got == ref
            bad += not ok
            print(name, '得到', got, '应为', ref, 'OK' if ok else '不一致')
            scen = make_scen(I, name, 0, plans['S4基线右移'][2], 'mix')
            for p in POLICIES:
                ms, S2, F2, P2, sc = run_policy(env, p, scen, plans)
                print('   扰动场景0 %-10s 工期 %d  违约 %d' % (p, ms, n_viol(I, scen, S2, F2, P2)))
    print('自检不一致数:', bad)


def compare_line(lst, ours, base):
    red_m = np.mean([1 - x[ours]['mean'] / x[base]['mean'] for x in lst]) * 100
    red_s = np.mean([1 - x[ours]['std'] / x[base]['std'] for x in lst if x[base]['std'] > 0]) * 100
    win_m = sum(1 for x in lst if x[ours]['mean'] < x[base]['mean'])
    win_s = sum(1 for x in lst if x[ours]['std'] < x[base]['std'])
    return ('%s 对 %s：扰动均值平均缩短 %.1f%%（更短 %d/%d），标准差平均降低 %.1f%%（更小 %d/%d）' %
            (ours, base, red_m, win_m, len(lst), red_s, win_s, len(lst)))


CMP_SET = (('pilot在线重排', '传统顺延'), ('pilot在线重排', 'S4基线右移'),
           ('act-pilot在线重排', '传统顺延'), ('act-pilot在线重排', 'pilot在线重排'),
           ('act-1在线重排', '传统顺延'), ('网络在线派工', '传统顺延'), ('网络前2在线重排', '传统顺延'),
           ('网络在线派工', 'LFT在线派工'), ('网络前2在线重排', 'act-pilot在线重排'))
CMP_ALL = (('pilot在线重排', '传统顺延'), ('act-pilot在线重排', '传统顺延'),
           ('act-pilot在线重排', 'pilot在线重排'),
           ('act-1在线重排', '传统顺延'), ('网络在线派工', '传统顺延'), ('网络前2在线重排', '传统顺延'),
           ('网络在线派工', 'LFT在线派工'), ('act-1在线重排', '网络在线派工'),
           ('网络前2在线重排', 'act-pilot在线重排'))


def _boot_ci(x, n=2000, seed=0):
    rng = np.random.RandomState(seed)
    x = np.asarray(x, dtype=float)
    m = [x[rng.randint(0, len(x), len(x))].mean() for _ in range(n)]
    return np.percentile(m, 2.5), np.percentile(m, 97.5)


def speed_table(lst):
    """在线重排的速度–工期对照：以 act-pilot 为 0，其余策略扰动均值长多少（逐例比值平均 + 95% 自助区间）"""
    L = ['-- 在线重排速度–工期对照（以 act-pilot在线重排 为基准，逐例 扰动均值比 再平均）',
         '   注意：前 5 种策略的耗时来自 10-22 那次运行，后 3 种来自 10-26 补跑，进程数/机器负载不同，耗时只能粗比；'
         '严格的同批耗时对比看静态 612 例 FBI 全量表。']
    L.append('%-16s %10s %20s %10s %10s' % ('策略', '比act长', '95%区间', '秒/场景', '相对耗时'))
    base_sec = float(np.mean([x['act-pilot在线重排']['sec'] for x in lst]))
    for p in ('LFT在线派工', '网络在线派工', 'act-1在线重排', '网络前2在线重排', 'pilot在线重排', 'act-pilot在线重排'):
        r = [x[p]['mean'] / x['act-pilot在线重排']['mean'] - 1 for x in lst]
        lo, hi = _boot_ci(r)
        sec = float(np.mean([x[p]['sec'] for x in lst]))
        L.append('%-16s %9.2f%% %9.2f%% ~ %6.2f%% %10.3f %9.1f%%' %
                 (p, np.mean(r) * 100, lo * 100, hi * 100, sec, sec / base_sec * 100))
    return '\n'.join(L)


def merge():
    rows = []
    cache = load_recs()              # 同一算例在多个缓存里时，保留跑得最多的那份
    per = defaultdict(list)          # (mode, set) -> 逐例统计
    n_skip = 0
    for (mode, nm), rec in sorted(cache.items()):
        if not is_full(rec):
            n_skip += 1
            continue
        st = {'name': nm, 'set': rec['set'], 'mode': mode, 'n': rec['n'], 'cpm': rec['cpm']}
        for p in POLICIES:
            r = [rec['res'][p][i] for i in range(N_SCEN)]
            ms = np.array([x[0] for x in r], dtype=float)
            st[p] = {'nom': rec['nom'][p][0], 'mean': ms.mean(), 'std': ms.std(ddof=1),
                     'p90': np.percentile(ms, 90), 'sc': np.mean([x[1] for x in r]),
                     'viol': sum(x[2] for x in r) + rec['nom'][p][2], 'sec': np.mean([x[3] for x in r])}
        per[(mode, rec['set'])].append(st)
        row = {'mode': mode, 'set': rec['set'], 'instance': nm, 'n': rec['n'], 'cpm': rec['cpm']}
        for p in POLICIES:
            for k in ('nom', 'mean', 'std', 'p90', 'sc', 'viol', 'sec'):
                row['%s_%s' % (p, k)] = round(float(st[p][k]), 4)
        rows.append(row)
    if not rows:
        print('还没有跑完的算例')
        return
    with open(os.path.join(OUT, '逐例结果.csv'), 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    L = []
    L.append('扰动实验汇总（U5S6 紧空间测试集，每个参数组取第 8 个算例；每例 %d 个随机场景，各策略同一批场景）' % N_SCEN)
    L.append('扰动：mix=工期波动+资源中断同时注入；dur=只有工期波动；res=只有资源中断。参数见 disturb.py 开头。')
    L.append('工期单位：天（时间段）。标准差为每例 100 个场景的样本标准差，再对算例取平均。')
    L.append('')
    tag = {'mix': '工期波动+资源中断', 'dur': '只有工期波动', 'res': '只有资源中断'}
    for (mode, s) in sorted(per.keys(), key=lambda x: (x[0], int(x[1][1:]))):
        lst = per[(mode, s)]
        L.append('== %s  %s  （%d 例）' % (tag.get(mode, mode), s, len(lst)))
        L.append('%-14s %8s %8s %8s %8s %8s %10s %8s %8s' % ('策略', '无扰动', '扰动均值', '比计划多', '标准差', 'P90', '空间冲突/次', '违约', '秒/场景'))
        for p in POLICIES:
            g = lambda k: float(np.mean([x[p][k] for x in lst]))
            L.append('%-14s %8.2f %8.2f %8.2f %8.2f %8.2f %10.1f %8d %8.3f' %
                     (p, g('nom'), g('mean'), g('mean') - g('nom'), g('std'), g('p90'), g('sc'),
                      sum(x[p]['viol'] for x in lst), g('sec')))
        for ours, base in CMP_SET:
            L.append(compare_line(lst, ours, base))
        L.append('')
    # 全部规模合计
    for mode in sorted({m for m, _ in per}):
        lst = [x for (m, s), v in per.items() if m == mode for x in v]
        L.append('== %s  全部规模合计（%d 例）' % (tag.get(mode, mode), len(lst)))
        for p in POLICIES:
            g = lambda k: float(np.mean([x[p][k] for x in lst]))
            L.append('%-14s 无扰动 %7.2f  扰动均值 %7.2f  标准差 %5.2f  P90 %7.2f' %
                     (p, g('nom'), g('mean'), g('std'), g('p90')))
        for ours, base in CMP_ALL:
            L.append(compare_line(lst, ours, base))
        if all(p in lst[0] for p in NEW_POLICIES):
            L.append(speed_table(lst))
        L.append('')
    if n_skip:
        L.append('（另有 %d 例还没跑完全部策略，未计入）' % n_skip)
    txt = '\n'.join(L)
    with open(os.path.join(OUT, '汇总报告.txt'), 'w', encoding='utf-8') as fh:
        fh.write(txt + '\n')
    print(txt)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--run', type=str, default=None)
    ap.add_argument('--part', type=str, default='0/1')
    ap.add_argument('--mode', type=str, default='mix')
    ap.add_argument('--budget', type=float, default=150)
    ap.add_argument('--merge', action='store_true')
    ap.add_argument('--pool', type=str, default=None, help='逗号分隔的算例集，如 j30,j60,j90,j120')
    ap.add_argument('--workers', type=int, default=0)
    a = ap.parse_args()
    if a.pool:
        run_pool(a.mode, a.pool.split(','), a.workers)
    elif a.selftest:
        selftest()
    elif a.run:
        run_part(a.run, a.part, a.mode, a.budget)
    elif a.merge:
        merge()


if __name__ == '__main__':
    main()
